
export function parse(source: string): string[];
export function parse<T>(source: string, transform: (value: string) => T): T[];

