# TemaniProjectBackup

-ea -Dapp.env=UAT -Dapp.lbu=sg -Dapp.language=en -Dweb.browser.type=chrome

DEVICEFARM_DEVICE_PLATFORM_NAME=Android
