package com.onepulse.app.config;

public class PulseApiConstUtils {
    public static String PULSE_WEBSOCKET_URL = "pulse.api.url";
    //public static String REQUEST_FILE_PATH = "/Users/antonydass/Desktop/OnePulseFramework/pca-onepulse-app-tests/src/test/resources/testdata/pulseapi/";
    public static String REQUEST_FILE_PATH = "/pulseapi/";
    public static String PULSE_MYDOC_CLIENT_ID = "edZpHYv07mC9gLb3fklal4";
    public static String PULSE_MYDOC_CLIENT_SECRETID = "ttV7iJ16GjkM4YKpaFu8e5";
}
