package com.onepulse.app.utils;

//import com.automation.platform.config.Configvariable;
import com.prod.tap.config.Configvariable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class MyDocDoctorDetails {

    @Autowired
    private Configvariable configvariable;

    public void setDoctorCredentials(String docName) {
        switch (docName) {
            case "Prudential Doctor":
                configvariable.setStringVariable("prudentialdoctor@my-doc.com", "DoctorUsername");
                configvariable.setStringVariable("prudential123", "DoctorPassword");
                configvariable.setStringVariable(configvariable.envPropertyMap.get("mydoc.doc.id1"), "DoctorId");
                break;
            case "Prudential Doctor 2":
                configvariable.setStringVariable("prudentialdoctor2@my-doc.com", "DoctorUsername");
                configvariable.setStringVariable("prudential123", "DoctorPassword");
                configvariable.setStringVariable(configvariable.envPropertyMap.get("mydoc.doc.id2"), "DoctorId");
                break;
            case "Prudential Doctor 3":
                configvariable.setStringVariable("prudentialdoctor3@my-doc.com", "DoctorUsername");
                configvariable.setStringVariable("prudential123", "DoctorPassword");
                configvariable.setStringVariable(configvariable.envPropertyMap.get("mydoc.doc.id3"), "DoctorId");
                break;
            case "Prudential Doctor 4":
                configvariable.setStringVariable("prudentialdoctor4@my-doc.com", "DoctorUsername");
                configvariable.setStringVariable("prudential123", "DoctorPassword");
                configvariable.setStringVariable(configvariable.envPropertyMap.get("mydoc.doc.id4"), "DoctorId");
                break;
            case "Prudential Doctor 5s":
                configvariable.setStringVariable("prudentialdoctor5@my-doc.com", "DoctorUsername");
                configvariable.setStringVariable("prudential123", "DoctorPassword");
                configvariable.setStringVariable(configvariable.envPropertyMap.get("mydoc.doc.id5s"), "DoctorId");
                break;
            case "Prudential Doctor 6":
                configvariable.setStringVariable("prudentialdoctor6@my-doc.com", "DoctorUsername");
                configvariable.setStringVariable("prudential123", "DoctorPassword");
                configvariable.setStringVariable(configvariable.envPropertyMap.get("mydoc.doc.id6"), "DoctorId");
                break;
            case "Prudential Doctor 7":
                configvariable.setStringVariable("prudentialdoctor7@my-doc.com", "DoctorUsername");
                configvariable.setStringVariable("prudential123", "DoctorPassword");
                configvariable.setStringVariable(configvariable.envPropertyMap.get("mydoc.doc.id7"), "DoctorId");
                break;
            case "Prudential Doctor 8":
                configvariable.setStringVariable("prudentialdoctor8@my-doc.com", "DoctorUsername");
                configvariable.setStringVariable("prudential123", "DoctorPassword");
                configvariable.setStringVariable(configvariable.envPropertyMap.get("mydoc.doc.id8"), "DoctorId");
                break;
            case "Prudential Doctor 9":
                configvariable.setStringVariable("prudentialdoctor9@my-doc.com", "DoctorUsername");
                configvariable.setStringVariable("prudential123", "DoctorPassword");
                configvariable.setStringVariable(configvariable.envPropertyMap.get("mydoc.doc.id9"), "DoctorId");
                break;
            case "Prudential Doctor 10":
                configvariable.setStringVariable("prudentialdoctor10@my-doc.com", "DoctorUsername");
                configvariable.setStringVariable("prudential123", "DoctorPassword");
                configvariable.setStringVariable(configvariable.envPropertyMap.get("mydoc.doc.id10"), "DoctorId");
                break;
            case "Prudential doctor":
                configvariable.setStringVariable("prudentialdoctor@my-doc.com", "DoctorUsername");
                configvariable.setStringVariable("prudentialdoctor123", "DoctorPassword");
                configvariable.setStringVariable("34778", "DoctorId");
                break;
            case "Prudential Doc One UAT":
                configvariable.setStringVariable("prudential.doc1@my-doc.com", "DoctorUsername");
                configvariable.setStringVariable("prudential123", "DoctorPassword");
                configvariable.setStringVariable("35259", "DoctorId");
                break;
            case "Prudential Doc Two UAT":
                configvariable.setStringVariable("prudential.doc2@my-doc.com", "DoctorUsername");
                configvariable.setStringVariable("prudential123", "DoctorPassword");
                configvariable.setStringVariable("35260", "DoctorId");
                break;
            case "Prudential Doc Three UAT":
                configvariable.setStringVariable("prudential.doc3@my-doc.com", "DoctorUsername");
                configvariable.setStringVariable("prudential123", "DoctorPassword");
                configvariable.setStringVariable("35261", "DoctorId");
                break;
            case "Katey Cori":
                configvariable.setStringVariable("mark.ridley@my-doc.com", "DoctorUsername");
                configvariable.setStringVariable("mydoc123", "DoctorPassword");
                configvariable.setStringVariable("10696", "DoctorId");
                break;
            case "Laurena Sheffield":
                configvariable.setStringVariable("aris.pro@my-doc.com", "DoctorUsername");
                configvariable.setStringVariable("mydoc123", "DoctorPassword");
                configvariable.setStringVariable("19625", "DoctorId");
                break;
            default:
        }
    }

    public List<String> getDoctorName() {
        List<String> listDoctors = new ArrayList<>();
        listDoctors.add("Prudential Doctor 2");
        listDoctors.add("Prudential Doctor 3");
        listDoctors.add("Prudential Doctor 4");
        listDoctors.add("Prudential Doctor 5");
        listDoctors.add("Prudential Doctor 6");
        listDoctors.add("Prudential Doctor 7");
        listDoctors.add("Prudential Doctor 8");
        listDoctors.add("Prudential Doctor 9");
        listDoctors.add("Prudential Doctor 10");
        listDoctors.add("Prudential doctor");
        listDoctors.add("Prudential Doctor");
        listDoctors.add("Prudential Doc One UAT");
        listDoctors.add("Prudential Doc Two UAT");
        listDoctors.add("Prudential Doc Three UAT");
        listDoctors.add("Katey Cori");
        listDoctors.add("Laurena Sheffield");
        listDoctors.add("Concierge UAT");
        return listDoctors;
    }

}
