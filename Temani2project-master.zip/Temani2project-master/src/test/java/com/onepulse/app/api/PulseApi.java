package com.onepulse.app.api;

import com.onepulse.app.config.PulseApiConstUtils;
import com.prod.tap.api.WebSocketClient;
import com.prod.tap.config.Configvariable;
import com.prod.tap.exception.TapException;
import com.prod.tap.exception.TapExceptionType;
import com.prod.tap.filehandling.JsonReader;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public class PulseApi {
    private static final Logger logger = Logger.getLogger(PulseApi.class);

    @Autowired
    private Configvariable configvariable;

    @Autowired
    private WebSocketClient webSocketClient;

    @Autowired
    private JsonReader jsonReader;


    public JSONObject loginToPulse() {
        webSocketClient.setWebSocketURL(Configvariable.envPropertyMap.get(PulseApiConstUtils.PULSE_WEBSOCKET_URL));
        String response = webSocketClient.sendRequestAndCheckForResponse(PulseApiConstUtils.REQUEST_FILE_PATH + "Login.json");
        logger.info("Receiving: " + response);
        JSONObject responseObject = jsonReader.convertJsonStringToJsonObject(response);
        if (String.valueOf(responseObject.get("access_token")) == null) {
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "Not able to login to pulse using API [{}]", response);
        }
        configvariable.setStringVariable(responseObject.get("access_token").toString(), "pulse_access_token");
        return responseObject;
    }

    public void registerToPulse() {
        webSocketClient.setWebSocketURL(Configvariable.envPropertyMap.get(PulseApiConstUtils.PULSE_WEBSOCKET_URL));
        String initialRegistration = webSocketClient.sendRequestAndCheckForResponse(PulseApiConstUtils.REQUEST_FILE_PATH + "Register.json");
        logger.info("Receiving: " + initialRegistration);
        Map<String, Object> responseMapInitial = jsonReader.convertJsonStringToMap(initialRegistration);
        configvariable.setStringVariable(responseMapInitial.get("workflowId").toString(), "PULSE_WORKFLOW_ID");
//        getOTP(configvariable.expandValue("${USER_NAME}"),"Pulse - Account creation request");
        String otpRegistration = webSocketClient.sendRequestAndCheckForResponse(PulseApiConstUtils.REQUEST_FILE_PATH + "RegisterOtp.json");
        logger.info("Receiving: " + otpRegistration);
        String registrationDone = webSocketClient.sendRequestAndCheckForResponse(PulseApiConstUtils.REQUEST_FILE_PATH + "RegisterAccepttermsAndCondition.json");
        logger.info("Receiving: " + registrationDone);
        Map<String, Object> otpMap = jsonReader.convertJsonStringToMap(registrationDone);
        Map<String, String> otpStatus = (Map<String, String>) otpMap.get("status");
        configvariable.setStringVariable(otpStatus.get("message"), "PULSE_REGISTRATION_STATUS");
        if (!otpStatus.get("message").contains("User registration completed and user logged in successfully")) {
            logger.error("Pulse Registration Failed : " + otpStatus.get("message"));
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "Not able to register to pulse using API [{}]", otpStatus.get("message"));
        }
        configvariable.setStringVariable(otpMap.get("access_token").toString(), "pulse_access_token");
    }

    public JSONObject getPulseCustomerDetails(String userEmail) {
        webSocketClient.setWebSocketURL(Configvariable.envPropertyMap.get(PulseApiConstUtils.PULSE_WEBSOCKET_URL));
        String response = webSocketClient.sendRequestAndCheckForResponse(PulseApiConstUtils.REQUEST_FILE_PATH + "PulseGetCustomerById.json");
        logger.info("Receiving: " + response);
        JSONObject pulseCustomerDetail = jsonReader.convertJsonStringToJsonObject(response);
        if (!String.valueOf(pulseCustomerDetail.getJSONObject("status").get("code")).contains("0")) {
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "Customer details not present for user [{}]", configvariable.expandValue(userEmail));
        } else {
            configvariable.setStringVariable(pulseCustomerDetail.getJSONObject("body").get("id").toString(), "Pulse_Customer_Id");
        }
        return pulseCustomerDetail;
    }


    public void deletePulseCustomer(String userEmail) {
        webSocketClient.setWebSocketURL(Configvariable.envPropertyMap.get(PulseApiConstUtils.PULSE_WEBSOCKET_URL));
        String tictracUpdateResponse = webSocketClient.sendRequestAndCheckForResponse(PulseApiConstUtils.REQUEST_FILE_PATH + "PulseDeleteCustomer.json");
        logger.info("Receiving: " + tictracUpdateResponse);
        Map<String, Object> otpMap = jsonReader.convertJsonStringToMap(tictracUpdateResponse);
        Map<String, String> otpStatus = (Map<String, String>) otpMap.get("status");
        if (!otpStatus.get("message").contains("User was successfully deleted")) {
            logger.error("Not able to delete customer details using pulse API: " + otpStatus.get("message"));
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "Not able to delete customer details using pulse API [{}]", otpStatus.get("message"));
        } else {
            logger.info("Pulse customer details deleted for user " + userEmail);
        }
    }

    public void createPulseCustomerConnect() {
        webSocketClient.setWebSocketURL(Configvariable.envPropertyMap.get(PulseApiConstUtils.PULSE_WEBSOCKET_URL));
        String response = webSocketClient.sendRequestAndCheckForResponse(PulseApiConstUtils.REQUEST_FILE_PATH + "PulseCreateCustomerConnect.json");
        logger.info("Receiving: " + response);
        JSONObject responseObject = jsonReader.convertJsonStringToJsonObject(response);
        if (!String.valueOf(responseObject.getJSONObject("status").get("code")).contains("0")) {
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "Not able to create the customer connect using pulse API");
        } else {
            logger.info("Pulse customer connect is created.");
        }
    }

    public void rejectPulseCustomerConnect() {
        webSocketClient.setWebSocketURL(Configvariable.envPropertyMap.get(PulseApiConstUtils.PULSE_WEBSOCKET_URL));
        String response = webSocketClient.sendRequestAndCheckForResponse(PulseApiConstUtils.REQUEST_FILE_PATH + "PulseRejectCustomerConnect.json");
        logger.info("Receiving: " + response);
        JSONObject responseObject = jsonReader.convertJsonStringToJsonObject(response);
        if (!String.valueOf(responseObject.getJSONObject("status").get("code")).contains("0")) {
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "Not able to reject the customer connect using pulse API");
        } else {
            logger.info("Pulse customer connect is rejected.");
        }
    }

    public void acceptPulseCustomerConnect() {
        webSocketClient.setWebSocketURL(Configvariable.envPropertyMap.get(PulseApiConstUtils.PULSE_WEBSOCKET_URL));
        String response = webSocketClient.sendRequestAndCheckForResponse(PulseApiConstUtils.REQUEST_FILE_PATH + "PulseAcceptCustomerConnect.json");
        logger.info("Receiving: " + response);
        JSONObject responseObject = jsonReader.convertJsonStringToJsonObject(response);
        if (!String.valueOf(responseObject.getJSONObject("status").get("code")).contains("0")) {
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "Not able to accept the customer connect using pulse API");
        } else {
            logger.info("Pulse customer connect is accepted.");
        }
    }

    public JSONObject getPulseCustomerConnectDetails() {
        webSocketClient.setWebSocketURL(Configvariable.envPropertyMap.get(PulseApiConstUtils.PULSE_WEBSOCKET_URL));
        String response = webSocketClient.sendRequestAndCheckForResponse(PulseApiConstUtils.REQUEST_FILE_PATH + "PulseGetCustomerConnectDetailsById.json");
        logger.info("Receiving: " + response);
        JSONObject pulseAllCustomerConnectDetails = jsonReader.convertJsonStringToJsonObject(response);
        if (!String.valueOf(pulseAllCustomerConnectDetails.getJSONObject("status").get("code")).contains("0")) {
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "Customer connect details not present for user");
        } else {
            JSONArray pulseCustomerConnectArray = pulseAllCustomerConnectDetails.getJSONArray("body");
            int connectCount = pulseCustomerConnectArray.length();
            for (int i = 0; i < connectCount; i++) {
                JSONObject customerConnectResponseBody = jsonReader.convertJsonArrayToJsonObject(pulseCustomerConnectArray, i);
                configvariable.setStringVariable(customerConnectResponseBody.get("id").toString(), "Pulse_Customer_connect_Id" + (i + 1));
            }
            return pulseAllCustomerConnectDetails;
        }
    }

    public void deletePulseCustomerConnect() {
        webSocketClient.setWebSocketURL(Configvariable.envPropertyMap.get(PulseApiConstUtils.PULSE_WEBSOCKET_URL));
        String response = webSocketClient.sendRequestAndCheckForResponse(PulseApiConstUtils.REQUEST_FILE_PATH + "PulseDeleteCustomerConnect.json");
        logger.info("Receiving: " + response);
        JSONObject responseObject = jsonReader.convertJsonStringToJsonObject(response);
        if (!String.valueOf(responseObject.getJSONObject("status").get("code")).contains("0")) {
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "Not able to delete the customer connect using pulse API");
        } else {
            logger.info("Pulse customer connect is deleted.");
        }
    }

    public JSONObject findPulseCustomersByCriteria(String email) {
        webSocketClient.setWebSocketURL(Configvariable.envPropertyMap.get(PulseApiConstUtils.PULSE_WEBSOCKET_URL));
        String response = webSocketClient.sendRequestAndCheckForResponse(PulseApiConstUtils.REQUEST_FILE_PATH + "PulseFindCustomersByCriteria.json");
        logger.info("Receiving: " + response);
        JSONObject findCustomersResponseObject = jsonReader.convertJsonStringToJsonObject(response);
        if (!String.valueOf(findCustomersResponseObject.getJSONObject("status").get("code")).contains("0")) {
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "unable to find the details for email id [{}]", email);
        }
        return findCustomersResponseObject;
    }

    public void updateSpouseDetails() {
        webSocketClient.setWebSocketURL(Configvariable.envPropertyMap.get(PulseApiConstUtils.PULSE_WEBSOCKET_URL));
        String response = webSocketClient.sendRequestAndCheckForResponse(PulseApiConstUtils.REQUEST_FILE_PATH + "PulseAddSpouseDetails.json");
        logger.info("Receiving: " + response);
        JSONObject responseObject = jsonReader.convertJsonStringToJsonObject(response);
        if (!String.valueOf(responseObject.getJSONObject("status").get("code")).contains("0")) {
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "spouse details are not updated");
        }
    }

    public void updateChildDetails() {
        webSocketClient.setWebSocketURL(Configvariable.envPropertyMap.get(PulseApiConstUtils.PULSE_WEBSOCKET_URL));
        String response = webSocketClient.sendRequestAndCheckForResponse(PulseApiConstUtils.REQUEST_FILE_PATH + "PulseAddChildDetails.json");
        logger.info("Receiving: " + response);
        JSONObject responseObject = jsonReader.convertJsonStringToJsonObject(response);
        if (!String.valueOf(responseObject.getJSONObject("status").get("code")).contains("0")) {
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "child details are not updated");
        }
    }

    public void updateCustomerDetails() {
        webSocketClient.setWebSocketURL(Configvariable.envPropertyMap.get(PulseApiConstUtils.PULSE_WEBSOCKET_URL));
        String response = webSocketClient.sendRequestAndCheckForResponse(PulseApiConstUtils.REQUEST_FILE_PATH + "PulseUpdateCustomerDetails.json");
        logger.info("Receiving: " + response);
        JSONObject responseObject = jsonReader.convertJsonStringToJsonObject(response);
        if (!String.valueOf(responseObject.getJSONObject("status").get("code")).contains("0")) {
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "customer details are not updated");
        }
    }

    public void uploadProfileImage() {
        webSocketClient.setWebSocketURL(Configvariable.envPropertyMap.get(PulseApiConstUtils.PULSE_WEBSOCKET_URL));
        String response = webSocketClient.sendRequestAndCheckForResponse(PulseApiConstUtils.REQUEST_FILE_PATH + "PulseUploadProfilePicture.json");
        logger.info("Receiving: " + response);
        JSONObject responseObject = jsonReader.convertJsonStringToJsonObject(response);
        if (!String.valueOf(responseObject.getJSONObject("status").get("code")).contains("0")) {
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "profile details are not updated");
        }
    }

    public JSONObject getAllRelationDetails(String userEmail) {
        webSocketClient.setWebSocketURL(Configvariable.envPropertyMap.get(PulseApiConstUtils.PULSE_WEBSOCKET_URL));
        String response = webSocketClient.sendRequestAndCheckForResponse(PulseApiConstUtils.REQUEST_FILE_PATH + "PulseGetAllRelations.json");
        logger.info("Receiving: " + response);
        JSONObject pulseCustomerRelationsDetail = jsonReader.convertJsonStringToJsonObject(response);
        if (!String.valueOf(pulseCustomerRelationsDetail.getJSONObject("status").get("code")).contains("0")) {
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "Customer relations details not present for user [{}]", configvariable.expandValue(userEmail));
        } else {
            if (pulseCustomerRelationsDetail.getJSONObject("body").has("spouse")) {
                JSONObject pulseSpouseDetails = pulseCustomerRelationsDetail.getJSONObject("body").getJSONObject("spouse");
                configvariable.setStringVariable(pulseSpouseDetails.get("id").toString(), "pulse_spouse_id");
            } else if (pulseCustomerRelationsDetail.getJSONObject("body").has("children")) {
                JSONArray pulseChildrenArray = pulseCustomerRelationsDetail.getJSONObject("body").getJSONArray("children");
                int childrenCount = pulseChildrenArray.length();
                for (int i = 0; i < childrenCount; i++) {
                    JSONObject pulseChildrenDetails = jsonReader.convertJsonArrayToJsonObject(pulseChildrenArray, i);
                    configvariable.setStringVariable(pulseChildrenDetails.get("id").toString(), "pulse_child_id" + (i + 1));
                }
            }
            return pulseCustomerRelationsDetail;
        }
    }

    public void deleteCustomerRelation() {
        webSocketClient.setWebSocketURL(Configvariable.envPropertyMap.get(PulseApiConstUtils.PULSE_WEBSOCKET_URL));
        String response = webSocketClient.sendRequestAndCheckForResponse(PulseApiConstUtils.REQUEST_FILE_PATH + "PulseDeleteCustomerRelationDetails.json");
        logger.info("Receiving: " + response);
        JSONObject responseObject = jsonReader.convertJsonStringToJsonObject(response);
        if (!String.valueOf(responseObject.getJSONObject("status").get("code")).contains("0")) {
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "Customer relation details are not deleted");
        } else
            logger.info("Customer relation details are deleted");
    }

    public JSONObject getResources() {
        webSocketClient.setWebSocketURL(Configvariable.envPropertyMap.get(PulseApiConstUtils.PULSE_WEBSOCKET_URL));
        String response = webSocketClient.sendRequestAndCheckForResponse(PulseApiConstUtils.REQUEST_FILE_PATH + "PulseGetResourceByID.json");
        logger.info("Receiving: " + response);
        JSONObject responseObject = jsonReader.convertJsonStringToJsonObject(response);
        if (!String.valueOf(responseObject.getJSONObject("status").get("code")).contains("0")) {
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "unable to fetch the resources");
        }
        return responseObject;
    }

    public JSONObject getPulseDocumentDetails(String userEmail) {
        webSocketClient.setWebSocketURL(Configvariable.envPropertyMap.get(PulseApiConstUtils.PULSE_WEBSOCKET_URL));
        String response = webSocketClient.sendRequestAndCheckForResponse(PulseApiConstUtils.REQUEST_FILE_PATH + "PulseGetDocumentById.json");
        logger.info("Receiving: " + response);
        JSONObject pulseDocumentDetails = jsonReader.convertJsonStringToJsonObject(response);
        if (!String.valueOf(pulseDocumentDetails.getJSONObject("status").get("code")).contains("0")) {
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "Document details not present for user [{}]", configvariable.expandValue(userEmail));
        } else {
            return pulseDocumentDetails;
        }
    }

    public JSONObject loginToPulseUsingInvalidValues() {
        webSocketClient.setWebSocketURL(Configvariable.envPropertyMap.get(PulseApiConstUtils.PULSE_WEBSOCKET_URL));
        String response = webSocketClient.sendRequestAndCheckForResponse(PulseApiConstUtils.REQUEST_FILE_PATH + "Login.json");
        logger.info("Receiving: " + response);
        JSONObject loginResponse = jsonReader.convertJsonStringToJsonObject(response);
        return loginResponse;
    }

    public JSONObject registerToPulseNegative() {
        webSocketClient.setWebSocketURL(Configvariable.envPropertyMap.get(PulseApiConstUtils.PULSE_WEBSOCKET_URL));
        String negativeRegistration = webSocketClient.sendRequestAndCheckForResponse(PulseApiConstUtils.REQUEST_FILE_PATH + "Register.json");
        logger.info("Receiving: " + negativeRegistration);
        JSONObject negativeRegistrationResponse = jsonReader.convertJsonStringToJsonObject(negativeRegistration);
        return negativeRegistrationResponse;
    }

    public void disconnectFromWebSocket() {
        webSocketClient.disconnectToWebSocket();
    }


   /* public void getOTP(String emailID,String subject) {
        disconnectFromWebSocket();
        configvariable.setStringVariable(subject, "EMAIL_SUBJECT");
        try {
            Thread.sleep(25000);
            malinatorApi.readEmailFromMalinator(configvariable.expandValue(emailID));
            String otp = malinatorApi.getOTPFromEmail(configvariable.expandValue("${MAIL_ID}"));
            configvariable.setStringVariable(otp, "OTP");
            disconnectFromWebSocket();
        } catch (InterruptedException e) {
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "Not able to fetch the otp");
        }
    }*/

}