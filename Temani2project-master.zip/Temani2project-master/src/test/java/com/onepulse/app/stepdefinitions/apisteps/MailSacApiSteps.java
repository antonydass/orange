package com.onepulse.app.stepdefinitions.apisteps;

//import com.automation.platform.api.HttpClientApi;
//import com.automation.platform.config.Configvariable;
//import com.automation.platform.config.TapBeansLoad;
//import com.automation.platform.cucumberUtils.ScenarioUtils;
//import com.automation.platform.filehandling.JsonReader;
import com.onepulse.app.api.PulseMailSacApi;
import com.onepulse.app.cucumberhooks.CucumberHook;
import com.prod.tap.api.HttpClientApi;
import com.prod.tap.config.Configvariable;
import com.prod.tap.config.TapBeansLoad;
import com.prod.tap.cucumberUtils.ScenarioUtils;
import com.prod.tap.filehandling.JsonReader;
import cucumber.api.java.en.And;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

public class MailSacApiSteps {
    private static final Logger logger = LoggerFactory.getLogger(MailSacApiSteps.class);

    // private PulseMalinatorApi pulseMalinatorApi = CucumberHook.context.getBean(PulseMalinatorApi.class);
    private Configvariable configvariable = CucumberHook.context.getBean(Configvariable.class);

    private HttpClientApi httpClientApi = (HttpClientApi) TapBeansLoad.getBean(HttpClientApi.class);

    private ScenarioUtils scenarioUtils = (ScenarioUtils) TapBeansLoad.getBean(ScenarioUtils.class);

    private JsonReader jsonreader = (JsonReader) TapBeansLoad.getBean(JsonReader.class);

    private PulseMailSacApi pulseMailSacApi = (PulseMailSacApi) TapBeansLoad.getBean(PulseMailSacApi.class);
    public static String msgId;
    public static String pulseRandomMailEndPoint;


//    @And("^I set endpoint url for reading email as \"([^\"]*)\"$")
//    public void iSetEndpointUrlForReadingEmailAs(String url) throws Throwable {
//        pulseRandomMailEndPoint = this.configvariable.expandValue(url);
//        this.scenarioUtils.write("API Url is :" + pulseRandomMailEndPoint+msgId);
//        this.httpClientApi.setUrl(pulseRandomMailEndPoint);
//    }
//
//    @And("^I send request to \"([^\"]*)\" the otp with \"([^\"]*)\" stored into variable \"([^\"]*)\"$")
//    public void iSendRequestToTheOtpWithStoredIntoVariable(String method,String rawUrl,String otpVar) throws Throwable {
//        logger.info("Sending multipart " + method + " request");
//        String msgIDEndPointurl=pulseRandomMailEndPoint;
//        this.scenarioUtils.write("API Url is :" + msgIDEndPointurl);
//        this.httpClientApi.setUrl(msgIDEndPointurl);
//
//        Map<String, String> msgIDVariableMap = new HashMap<>();
//        msgIDVariableMap.put("Mailsac-Key", configvariable.expandValue("k_6cVwNoHeWFqFOBmXpYL2QwnmBA"));
//        httpClientApi.setUrl(msgIDEndPointurl);
//        httpClientApi.setSendHeaders(msgIDVariableMap);
//
//        Map<String, Object> responseMap = new HashMap<>();
//        String response=httpClientApi.executeRequestAndGetResponse("Get");
//        System.out.println("My Response" + response);
//        String response1 = response.substring(1, response.length() - 1);
//        responseMap = jsonreader.convertJsonStringToMap(response1);
//        msgId = responseMap.get("_id").toString();
//
//        String endPoint = this.configvariable.expandValue(rawUrl);
//        String newurl = endPoint+msgId;
//        this.scenarioUtils.write("API Url is :" + newurl);
//        this.httpClientApi.setUrl(newurl);
//        Map<String, String> variableMap = new HashMap<>();
//        variableMap.put("Mailsac-Key", configvariable.expandValue("k_6cVwNoHeWFqFOBmXpYL2QwnmBA"));
//        httpClientApi.setUrl(newurl);
//        httpClientApi.setSendHeaders(variableMap);
//        String response2=httpClientApi.executeRequestAndGetResponse(method);
//        this.scenarioUtils.write("Response body is :" + this.httpClientApi.getResponseBody());
//        this.httpClientApi.resetVariables();
//        httpClientApi.getResponseBody();
//        Document document = Jsoup.parse(httpClientApi.getResponseBody());
//        String otp = document.getElementsByClass("button__a").first().text();
//        logger.info("Your Pulse OTP is : " + otp );
//        configvariable.setStringVariable(otp, otpVar);
//    }
//
//


    @And("^I set endpoint url for reading email as \"([^\"]*)\"$")
    public void iSetEndpointUrlForReadingEmailAs(String url) throws Throwable {
        pulseRandomMailEndPoint = this.configvariable.expandValue(url);
        System.out.println(("Wahts is message Id " + msgId));
        this.scenarioUtils.write("API Url is :" + pulseRandomMailEndPoint + msgId);
        this.httpClientApi.setUrl(pulseRandomMailEndPoint);
        Map<String, String> authVariableMap = new HashMap<>();
        authVariableMap.put(Configvariable.envPropertyMap.get("auth.mailsac.api.key"), Configvariable.envPropertyMap.get("auth.mailsac.api.value"));
        httpClientApi.setUrl(pulseRandomMailEndPoint);
        httpClientApi.setSendHeaders(authVariableMap);

    }

    @And("^I send request to \"([^\"]*)\" the otp with \"([^\"]*)\" stored into variable \"([^\"]*)\"$")
    public void iSendRequestToTheOtpWithStoredIntoVariable(String method, String rawUrl, String otpVar) throws Throwable {
        logger.info("Sending multipart " + method + " request");
        String msgIDEndPointurl = pulseRandomMailEndPoint;
        this.scenarioUtils.write("API Url is :" + msgIDEndPointurl);
        this.httpClientApi.setUrl(msgIDEndPointurl);
        Map<String, String> msgIDVariableMap = new HashMap<>();
        msgIDVariableMap.put(Configvariable.envPropertyMap.get("auth.mailsac.api.key"), Configvariable.envPropertyMap.get("auth.mailsac.api.value"));
        httpClientApi.setUrl(msgIDEndPointurl);
        httpClientApi.setSendHeaders(msgIDVariableMap);
        Map<String, Object> responseMap = new HashMap<>();
        String response = httpClientApi.executeRequestAndGetResponse("Get");
        String response1 = response.substring(1, response.length() - 1);
        responseMap = jsonreader.convertJsonStringToMap(response1);
        msgId = responseMap.get("_id").toString();
        String endPoint = this.configvariable.expandValue(rawUrl);
        String newurl = endPoint + msgId;
        this.scenarioUtils.write("API Url is :" + newurl);
        this.httpClientApi.setUrl(newurl);
        Map<String, String> variableMap = new HashMap<>();
        variableMap.put(Configvariable.envPropertyMap.get("auth.mailsac.api.key"), Configvariable.envPropertyMap.get("auth.mailsac.api.value"));
        httpClientApi.setUrl(newurl);
        httpClientApi.setSendHeaders(variableMap);
        httpClientApi.executeRequestAndGetResponse(method);
        this.scenarioUtils.write("Response body is :" + this.httpClientApi.getResponseBody());
        this.httpClientApi.resetVariables();
        System.out.println("My Response" + httpClientApi.getResponseBody());
        Document document = Jsoup.parse(httpClientApi.getResponseBody());
        //  String otp = document.getElementsByClass("button__a").first().text();
        String otp = document.getElementsByTag("a").first().text();

        configvariable.setStringVariable(otp, otpVar);
    }


}




