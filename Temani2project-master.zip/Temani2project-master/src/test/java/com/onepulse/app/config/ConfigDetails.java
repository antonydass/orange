package com.onepulse.app.config;

public class ConfigDetails {

    public static final String APP_URL = "employee.pulse.ui.url";
    public static final String AUTH_USER = "";
    public static final String AUTH_PASS = "";
    public static final String USER_NAME = "sales.username";
    public static final String USER_PASS = "sales.otp";

    public static final String HR_APP_URL = "www.seleniumeasy.com/test/";
    public static final String HR_AGENT_REG_URL = "hr.registration.ui.url";
    public static final String HR_REG_VERIFICATION_URL = "hr.activation.ui.url";
    public static final String HR_LOGIN_URL = "hr.login.ui.url";
    public static final String HR_RESET_PASSWORD_URL = "hr.activation.ui.url";
    public static final String MAILINATOR_UI_APP = "mailinator.ui.url";
    public static final int STORAGE_WAIT_TIME = 300;
}
