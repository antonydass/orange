package com.onepulse.app.screens;

//import com.onepulse.app.api.PulseMailSacApi;
//import com.product.genericcomponents.appium.AppiumCommands;
//import com.product.genericcomponents.config.Configvariable;
//import com.product.genericcomponents.exception.TapException;
//import com.product.genericcomponents.exception.TapExceptionType;
import com.prod.tap.appium.AppiumCommands;
import com.prod.tap.config.Configvariable;
import com.prod.tap.exception.TapException;
import com.prod.tap.exception.TapExceptionType;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import java.util.List;
import java.util.Map;

@Component
public class PulseRegistrationScreen {
    @Autowired
    private AppiumCommands appiumCommands;

    @Autowired
    private Configvariable configvariable;

    @Autowired
    private TestBasePage testBasePage;

    @Autowired
    private PulseLoginScreen pulseLoginScreen;

//    @Autowired
//    private PulseMailSacApi pulseMailSacApi;

//    @Autowired
//    public Commands commands;


    public String continueWithEmailButton = "${register.email.button}";
    public String signupButton = "${login.singup.button}";
    public String registerScreenFirstName = "${firstName.reg.text.field}";
    public String registerScreenLastName = "${lastName.reg.text.field}";
    public String registerScreenEmail = "${email.reg.text.field}";
    public String registerSignUpButton = "${continue.reg.button}";
    public String clearemailid = "${clearemailid.text}";
    public String clearusername = "${clearfirsname.text}";
    public String clearpassword = "${reg.text.fields}";
    public String registerScreenPassword = "${password.reg.text.field}";
    public String NoneofAbove = "${None.of.above}";
    public String MobileNumber = "${reg.mobileNumber.text}";
    public String MobileNumberclick = "${Mobileclick.text}";
    public String datefile = "${Datepicler.file}";
    public String Datefields = "${Datepicler.files}";
    public String Continuebutton = "${continue.buttons}";
    public String DateofBirth = "${Date.of.birth}";
    public String Donebutton = "${Done.button}";
    public String Malebutton = "${male.image}";
    public String freeAssement = "${free.Assessment}";
    public String Registrationtes = "${reg.text.field}";
    public String Registartionerror = "${error.reg.text.label}";
    public String Regtextfield = "${reg.text.fields}";
    public String Babyback = "${back.babylon}";
    public String Accountscreen = "${Home.Accountbutton}";
    public String signoutbutton = "${Signout.button}";
    public String startAssessment = "${Start.Assessment.text}";
    public String getOTP = "${login.verification.otp}";
    public String Accountbutton = "${home.account.image}";
    public String Emailtexts = "${Eamilid.text}";
    public String signout = "${Signout.button}";
    public String calendarIcon = "${Date.of.birth}";
    public String continuesbutton = "${continue.buttons}";
    public String closecontinue = "${continueclose.button}";
    public String closecontinues = "${continueclose.buttons}";
    public String closecontinuess = "${continueclose.buttonss}";
    public String continuetext = "${clickcontinue.text}";
    public String maleImages = "${male.image}";
    public String maleImagess = "${male.images}";
    public String NricNumbertext = "${Nrictest.image}";
    public String freeAssessment = "${free.Assessment}";
    public String backbabylon = "${back.babylon}";
    public String homepageText = "${welcome.label}";
    public String homepagebutton = "${welcome.label}";
    public String homescreen = "${newhome.button}";
    public String faceIdEnrollButton = "${faceid.registered.enroll.button}";
    public String faceIdNotnowButton = "${faceid.registered.notnow.button}";
    public String clearmobile = "${mobiletext.number}";
    public String MySettingsIcon = "${MySettings.icons}";
    public String SelectCountry = "${countryvalue.text}";
    public String countrybutton = "${country.text}";
    public String Settingsback = "${Backsettings.text}";
    public String ReviewManagebutton = "${ReviewManage.button}";
    public String accountbutton = "${Home.Accountbutton}";
    public String ActivateIocn = "${Activateicon.button}";
    public String Activateicons = "${Activateyes.icon}";
    public String MobileNumbericon = "${mobile.numbers}";
    public String signups = "${signups.iconss}";
    public String locations = "${location.signups}";
    public String Resendbuttons = "${resendbuttons.icons}";
    public String clickResendbutton = "${codecontinue.buttons}";
    //IOS ELEMENT
    public String ActivateIocnios = "${Activateicon.button}";
    public String ActivateiconsiOS = "${Activateyes.icon}";
    public String freeAssessmentios = "${free.Assessment}";
    public String pulsematepopup = "${pulsematepop.icon}";
    public String AccountbuttonIos = "${Home.Accountbutton}";
    public String emailTextField = "${email.text.field}";
    public String signInLink = "${register.home.sign.link}";
    public String Skipicons = "${Homeskips.icons}";
    public String registrationCountryDropDown = "${country.dropdown.arrow}";
    public String registrationDropDownCountrySelection = "${registration.select.country}";
    public String password = "${password.reg.text.field}";
    public String continueButton = "${continue.reg.button}";
    public String skipButton = "${skip.reg.button}";
    public String marketingConsentCheckBox = "${marketingConsent.reg.checkBox}";
    public String resendButton = "${resend.reg.button}";
    public String showPasswordButton = "${showPassword.reg.button}";
    public String pulseRegistrationFields = "${reg.text.field}";
    public String pulseRegistrationPossword = "${reg.text.fields}";
    public String errorMessages = "${error.reg.text.label}";
    public String doneButton = "${Done.button}";
    public String mobileNumber = "${mobile.number}";
    public String wellnessScreenTitle = "${signup.wellness.plan.screen.title}";
    public String wellnessPackage = "${signup.wellness.package}";
    public String userHeight = "${wellness.your.height}";
    public String userWeight = "${wellness.your.weight}";
    private String calculateBMI = "${wellness.calculate.bmi}";
    private String lightExercise = "${wellness.lightExercise}";
    private String foodProducts = "${wellness.foodProducts}";
    private String foodAllergies = "${wellness.foodallergies.text}";
    private String welcomeToPulse = "${welcometoPulse.text}";
    private String fitbitSubscriptionOffer = "${fitSubscription.exclusiveOffer}";
    private String exclusiveOfferCloseIcon = "${exclusiveOffer.close.icon}";
    private String wellnessTrackingActivity = "${wellness.tracking.activity}";
    public String loginPageCountryDropDown = "${login.select.country}";
    public String countryDropDownSelection = "${drop.down.country.selection}";
    private String loginSignText = "${login.page.sign.text}";
    private String loginLangText = "${login.page.lang.text}";
    private String allowButton = "${alert.Allow.Button}";
    public String languageOptions = "${lang.toggle.btn.locator}";
    public String langDropDownLocator = "${lang.dropdown.locator}";
    public String selectLanguageLocator = "${lang.select.locator}";
    public String allergyOptionLocator = "${allergy.option.locator}";
    public String commonAllergyLocator = "${common.allergy.locator}";
    public String countryCodeLocator = "${country.code.locator}";
    public String fieldLabelLocator = "${reg.field.label.locator}";
    public String countryFieldValueLocator = "${text.field.label}";
    public String languageFieldValueLocator = "${text.field.label}";
    public String connectLaterBtnLocator = "${connect.later.button}";
    public String nonOfAboveLink = "${non.of.above.link}";
    public String dateOfBirths = "${Date.of.birth}";
    public String dobScreenLocator = "${dob.screen}";
    public String genderScreenLocator = "${gender.screen}";
    public String bmiScreenLocator = "${bmi.screen}";
    public String activityLevelScreenLocator = "${activityLevel.screen}";
    public String dietPreferencesScreenLocator = "${diet.preferences}";
    public String foodAllergiesScreenLocator = "${food.allergies.Screen}";
    public String connectTrackerScreenLocator = "${connect.tracker.screen.locator}";
    public String pulsePersonalisedScreenLocator = "${pulse.personalised.screen}";
    public String wellnessScreenValidationLocator = "${reg.workflow.validation.message}";
    public String skipButtonInRegistrationScreen = "${login.page.skip}";
    public String settings = "${settings.icon}";
    public String signin = "${Signins}";
    public String SignUpLink = "${signup.link}";
    public String nricNumberTextField = "${nric.number}";
    public String enterurl = "${Url.text}";
    public String hopesign = "${hopesign.icon}";


    private SoftAssert softAssert = new SoftAssert();

    public void clickRegisterButton(String buttonText) throws InterruptedException {
        Thread.sleep(12000);
        if (TestBasePage.platform.equalsIgnoreCase("iOS")) {
            if (testBasePage.isElementDisplayed(configvariable.expandValue(allowButton)))
                testBasePage.clickButton(configvariable.expandValue(allowButton));
            if (testBasePage.isElementDisplayed(configvariable.expandValue(homescreen))) {
                pulseLoginScreen.clickSignOut();
                testBasePage.isElementDisplayed(configvariable.expandValue(emailTextField));
                testBasePage.clickButton(configvariable.expandValue(signupButton));
                testBasePage.clickButton(configvariable.expandValue(continueWithEmailButton));
            } else if (testBasePage.isElementDisplayed(configvariable.expandValue(signupButton))) {
                testBasePage.clickButton(configvariable.expandValue(signupButton));
                testBasePage.clickButton(configvariable.expandValue(continueWithEmailButton));
            } else if (testBasePage.isElementDisplayed(configvariable.expandValue(continueWithEmailButton))) {
                testBasePage.clickButton(configvariable.expandValue(continueWithEmailButton));
            }
        }
        if (TestBasePage.platform.equalsIgnoreCase("Android")) {
            String locator = configvariable.expandValue(continueWithEmailButton);
          //  int iCount=0;

            testBasePage.clickButton(configvariable.expandValue(continueWithEmailButton));
          //  while(testBasePage.isElementDisplayed(locator) && iCount<3){
//            if (testBasePage.isElementDisplayed(locator)) {
          //      testBasePage.clickButton(locator);
                testBasePage.waitTime(3);
           //     iCount++;
            }
          //  }
        }

    public void clickSignIns_InSignUp(String platform) {
        if (platform.equalsIgnoreCase("android")) {
           // appiumCommands.swipe(AppiumCommands.DIRECTION.DOWN, 6000);
            testBasePage.clickButton(configvariable.expandValue(hopesign));

//        } else if (platform.equalsIgnoreCase("iOS")) {
//            testBasePage.clickButton(configvariable.expandValue(SigninsIos));
//        }
        }
    }

    public void dddd() {
        testBasePage.getURL("http://www.seleniumframework.com/Practiceform/");
    //    TestBasePage.driver.navigate().to(configvariable.expandValue(enterurl));
       // testBasePage.setTextWithOutClear(configvariable.expandValue(enterurl), url);
    }

    public void clickRegisterContinueButton() {
        String locator = configvariable.expandValue(registerSignUpButton);
        testBasePage.clickButton(locator);
    }

    public void clickOnResendBtn() {
        testBasePage.clickButton(configvariable.expandValue(resendButton));
    }


    public void enterRegistrationDetails(Map<String, String> registrationDetails) {
        for (String key : registrationDetails.keySet()) {
            String fieldName = configvariable.expandValue(key);
            switch (key) {
                case ("FirstName"):
                    testBasePage.setTextWithTab(configvariable.expandValue(registerScreenFirstName), configvariable.expandValue(registrationDetails.get(fieldName)));
                    break;
                case ("LastName"):
                    testBasePage.setTextWithTab(configvariable.expandValue(registerScreenLastName), configvariable.expandValue(registrationDetails.get(fieldName)));
                    break;
                case ("Email"):
                    testBasePage.setTextWithTab(configvariable.expandValue(registerScreenEmail), configvariable.expandValue(registrationDetails.get(fieldName)));
                    break;
                case ("Password"):
                    testBasePage.setTextWithTab(configvariable.expandValue(registerScreenPassword), configvariable.expandValue(registrationDetails.get(fieldName)));
                    break;
                default:
                    Assert.fail("Invalid field name: " + fieldName);
                    break;
            }

        }
        if (TestBasePage.platform.equalsIgnoreCase("ios")) {
            appiumCommands.pressIOSKeyBoardKey("Return");
        } else {
            appiumCommands.hideKeyboard();
        }
    }


    public void ClearEmail_id(String platform) {
        if ("Android".equalsIgnoreCase(platform)) {
            System.out.println("Entering the FirstName field");
            appiumCommands.cleartext(By.xpath(configvariable.expandValue(clearusername)));
            appiumCommands.cleartext(By.xpath(configvariable.expandValue(clearusername)));
            appiumCommands.cleartext(By.xpath(configvariable.expandValue(clearemailid)));
            appiumCommands.cleartext(By.xpath(configvariable.expandValue(clearpassword)));

        }
        if ("iOS".equalsIgnoreCase(platform)) {
            {
                appiumCommands.cleartext(By.xpath(configvariable.expandValue(clearusername)));
                appiumCommands.cleartext(By.xpath(configvariable.expandValue(clearusername)));
                appiumCommands.cleartext(By.xpath(configvariable.expandValue(clearemailid)));
            }
        }

    }

    public String getFormattedString(String locator) {
        return String.format(locator);
    }


    public void enterOTP(String platform, String emailId) {
        if (testBasePage.isElementDisplayed(configvariable.expandValue(getOTP))) {
            testBasePage.waitTime(Integer.parseInt(configvariable.expandValue("${otp.wait.time}")));
          //  String registrationOTP = pulseMailSacApi.getOTPFromEmail(emailId);
//            if ("Android".equalsIgnoreCase(platform)) {
//                testBasePage.setTextWithTab(configvariable.expandValue(getOTP), registrationOTP);
//            } else if ("iOS".equalsIgnoreCase(platform)) {
//
//                char[] otp = registrationOTP.toCharArray();
//                appiumCommands.pressIOSKeyBoardKey(Character.toString(otp[0]));
//                appiumCommands.pressIOSKeyBoardKey(Character.toString(otp[1]));
//                appiumCommands.pressIOSKeyBoardKey(Character.toString(otp[2]));
//                appiumCommands.pressIOSKeyBoardKey(Character.toString(otp[3]));
//                appiumCommands.pressIOSKeyBoardKey(Character.toString(otp[4]));
//                appiumCommands.pressIOSKeyBoardKey(Character.toString(otp[5]));
//                testBasePage.waitTime(5);
//                if (testBasePage.isElementDisplayed(configvariable.expandValue(faceIdEnrollButton)))
//                    testBasePage.clickButton(configvariable.expandValue(faceIdNotnowButton));
//            }
        }

    }


        /*if ("iOS".equalsIgnoreCase(platform)) {
            testBasePage.waitTime(6);

          //  testBasePage.clickButton(configvariable.expandValue(signups));
          //  testBasePage.waitTime(4);
            if(testBasePage.isElementDisplayed(configvariable.expandValue(getOTP))) {


                testBasePage.clickButton(configvariable.expandValue(getOTP));
                // testBasePage.clickButton(configvariable.expandValue(getOTP));
                testBasePage.ScrollUpForOTP();
                testBasePage.setTextWithTab(configvariable.expandValue(getOTP), registrationOTP);

            }
        }
    }
=======
         //   testBasePage.clickButton(configvariable.expandValue(getOTP));
            testBasePage.ScrollUpForOTP();
            testBasePage.setTextWithTab(configvariable.expandValue(getOTP), registrationOTP);
        }*/
    // }

    public void handleCarousel(String platform) {
        if ("iOS".equalsIgnoreCase(platform)) {
            int COUNT = 0;
            while (COUNT < 5) {
                try {
                    Dimension size = appiumCommands.getScreenDimension();
                    int height = size.getHeight();
                    int width = size.getWidth();
                    appiumCommands.tap(width - 40, height - (height - 42));
//                    appiumCommands.clickElementByCoordinate(iosRegistrationLocator.handleCarousel, 5);
                    Thread.sleep(1500);
                    COUNT++;
                } catch (InterruptedException e) {
                    throw new TapException(TapExceptionType.PROCESSING_FAILED, "Carousel handling failed");
                }
            }
            testBasePage.clickButton(configvariable.expandValue(skipButton));
        }
        if ("Android".equalsIgnoreCase(platform)) {

            testBasePage.clickButton(configvariable.expandValue(skipButton));
        }
    }

    public void validateRegValues(String platform, List<String> invalidRegDetails, String fieldName, String errorMsg) {
        By locator;
        String[] parts;
        By error_locator;
        if (platform.equalsIgnoreCase("iOS")) {
            testBasePage.waitTime(2);
            for (int i = 0; i < invalidRegDetails.size(); i++) {
                // appiumCommands.swipe(AppiumCommands.DIRECTION.DOWN, 6000);
                parts = invalidRegDetails.get(i).split("##");
                error_locator = By.xpath(configvariable.getFormattedString(configvariable.expandValue(errorMessages), errorMsg));
                appiumCommands.swipe(AppiumCommands.DIRECTION.DOWN, 6000);
                testBasePage.setText(configvariable.expandValue(password), parts[0]);
                // appiumCommands.isKeyBoardKeyPresent("Return");
                appiumCommands.swipe(AppiumCommands.DIRECTION.DOWN, 6000);
                testBasePage.clickButton(configvariable.expandValue(continueButton));
                testBasePage.clickButton(configvariable.expandValue(continueButton));
                Assert.assertEquals(appiumCommands.getTextFromField("value", error_locator).trim(), errorMsg);
                appiumCommands.isKeyBoardKeyPresent("Return");
            }
//            testBasePage.waitTime(10);
//            appiumCommands.waitForVisibility(androidRegistrationLocator.getPassword());
//            locator = androidRegistrationLocator.getPassword();
//            error_locator = By.xpath(configvariable.getFormattedString(androidRegistrationLocator.getErrorMessages(), errorMsg));
//            for (int i = 0; i < invalidRegDetails.size(); i++) {
//                appiumCommands.waitForVisibility(locator);
//                appiumCommands.swipe(AppiumCommands.DIRECTION.DOWN, 6000);
//                appiumCommands.findElement(locator).sendKeys(invalidRegDetails.get(i));
//              //  appiumCommands.swipe(AppiumCommands.DIRECTION.DOWN, 6000);
//                appiumCommands.findElement(androidRegistrationLocator.getContinueButton()).click();
//                appiumCommands.findElement(androidRegistrationLocator.getContinueButton()).click();
//                Assert.assertEquals(appiumCommands.getTextFromField("text", error_locator).trim(), errorMsg);
//                appiumCommands.cleartext(By.xpath(configvariable.getFormattedString(androidRegistrationLocator.getPulseRegistrationPossword(), invalidRegDetails.get(i))));


        } else if (platform.equalsIgnoreCase("android")) {
            testBasePage.waitTime(10);
            appiumCommands.waitForVisibility(By.xpath(configvariable.expandValue(password)));
            locator = By.xpath(configvariable.expandValue(password));
            error_locator = By.xpath(configvariable.getFormattedString(configvariable.expandValue(errorMessages), errorMsg));
            for (int i = 0; i < invalidRegDetails.size(); i++) {
                appiumCommands.waitForVisibility(locator);
                appiumCommands.swipe(AppiumCommands.DIRECTION.DOWN, 6000);
                appiumCommands.findElement(locator).sendKeys(invalidRegDetails.get(i));
                //testBasePage.setTextWithTab(configvariable.expandValue(password), invalidRegDetails.get(i));
                appiumCommands.swipe(AppiumCommands.DIRECTION.DOWN, 6000);
                testBasePage.clickButton(configvariable.expandValue(continueButton));
                testBasePage.waitTime(5);
                Assert.assertEquals(appiumCommands.getTextFromField("text", error_locator).trim(), errorMsg);
                appiumCommands.cleartext(By.xpath(configvariable.getFormattedString(configvariable.expandValue(pulseRegistrationPossword), invalidRegDetails.get(i))));
            }
        }
    }

    public void validatePulseRegistrationFieldValue(String platform, Map<String, String> invalidRegDetails) {
        String[] parts;
        By locator;
        By error_locator;
        if (platform.equalsIgnoreCase("iOS")) {
            for (String key : invalidRegDetails.keySet()) {
                parts = invalidRegDetails.get(key).split("##");
                switch (key) {
                    case "Phone Number":
                        locator = By.xpath(configvariable.getFormattedString(configvariable.expandValue(pulseRegistrationFields), key));
                        error_locator = By.xpath(configvariable.getFormattedString(configvariable.expandValue(errorMessages), parts[1]));
                        appiumCommands.findElement(locator).sendKeys(parts[0]);
                        testBasePage.setText(configvariable.expandValue(password), parts[0]);
                        appiumCommands.hideIOSKeyBoardUsingKeyboardLocation();
                        testBasePage.clickButton(continueButton);
                        Assert.assertEquals(appiumCommands.getTextFromField("value", error_locator).trim(), parts[1]);
                        appiumCommands.cleartext(locator);
                        appiumCommands.hideIOSKeyBoardUsingKeyboardLocation();
                        break;

                    default:
                        locator = By.xpath(configvariable.getFormattedString(configvariable.expandValue(pulseRegistrationFields), key));
                        error_locator = By.xpath(configvariable.getFormattedString(configvariable.expandValue(errorMessages), parts[1]));
                        appiumCommands.findElement(locator).sendKeys(parts[0]);
                        appiumCommands.isKeyBoardKeyPresent("Return");
                        testBasePage.clickButton(continueButton);
                        Assert.assertEquals(appiumCommands.getTextFromField("value", error_locator).trim(), parts[1]);
                        appiumCommands.cleartext(locator);
                        appiumCommands.isKeyBoardKeyPresent("Return");
                        break;
                }
            }
        } else if (platform.equalsIgnoreCase("android")) {

            for (String key : invalidRegDetails.keySet()) {
                parts = invalidRegDetails.get(key).split("##");
                locator = By.xpath(configvariable.getFormattedString(configvariable.expandValue(pulseRegistrationFields), key));
                error_locator = By.xpath(configvariable.getFormattedString(configvariable.expandValue(errorMessages), parts[1]));
                appiumCommands.findElement(locator).sendKeys(parts[0]);
                appiumCommands.swipe(AppiumCommands.DIRECTION.DOWN, 6000);
                testBasePage.clickButton(configvariable.expandValue(continueButton));
                Assert.assertEquals(appiumCommands.getTextFromField("text", error_locator).trim(), parts[1]);
                appiumCommands.cleartext(By.xpath(configvariable.getFormattedString(configvariable.expandValue(pulseRegistrationFields), parts[0])));
            }
        }
    }

    public void showPassword() {
        testBasePage.clickButton(configvariable.expandValue(showPasswordButton));

    }

    //   covid19
    public void validateValidPasswordValues(String platform, List<String> validPasswordDetails, String fieldName, String errorMsg) {
        By locator;
        String[] parts;
        By error_locator;
        if (platform.equalsIgnoreCase("iOS")) {
            locator = By.xpath(configvariable.getFormattedString(configvariable.expandValue(pulseRegistrationFields), fieldName));
            error_locator = By.xpath(configvariable.getFormattedString(configvariable.expandValue(errorMessages), errorMsg));
            for (int i = 0; i < validPasswordDetails.size(); i++) {
                parts = validPasswordDetails.get(i).split("##");
                //   appiumCommands.clearAndEnterText(locator, validPasswordDetails.get(i));
                testBasePage.setText(configvariable.expandValue(password), parts[0]);
                appiumCommands.isKeyBoardKeyPresent("Return");
                testBasePage.clickButton(configvariable.expandValue(continueButton));
                Assert.assertFalse(appiumCommands.isElementPresent(error_locator));
            }

        } else if (platform.equalsIgnoreCase("android")) {
            locator = By.xpath(configvariable.expandValue(password));
            error_locator = By.xpath(configvariable.getFormattedString(configvariable.expandValue(errorMessages), errorMsg));
            for (int i = 0; i < validPasswordDetails.size(); i++) {
                appiumCommands.findElement(locator).sendKeys(validPasswordDetails.get(i));
                testBasePage.clickButton(configvariable.expandValue(continueButton));
                testBasePage.waitTime(2);
                Assert.assertFalse(appiumCommands.isElementPresent(error_locator));
                // appiumCommands.cleartext(By.xpath(configvariable.getFormattedString(configvariable.expandValue(Regtextfield),validPasswordDetails.get(i))));
                appiumCommands.cleartext(By.xpath(configvariable.getFormattedString(configvariable.expandValue(pulseRegistrationPossword), validPasswordDetails.get(i))));
            }
        }


    }

    public void enterMobileNumber(String platform, Map<String, String> registrationDetails, String buttontexts) {
        if ("iOS".equalsIgnoreCase(platform)) {
            testBasePage.setTextWithTab(configvariable.expandValue(MobileNumber), configvariable.expandValue(registrationDetails.get("mobileNumber")));
            appiumCommands.clickElementByCoordinateforBothXY(169, 124);
        }

        if ("Android".equalsIgnoreCase(platform)) {
            String locator = configvariable.expandValue(NoneofAbove);
            if (testBasePage.isElementDisplayed(locator)) {
                testBasePage.clickButton(locator);
            }

            testBasePage.setTextWithTab(configvariable.expandValue(MobileNumber), configvariable.expandValue(registrationDetails.get("mobileNumber")));
            testBasePage.clickButton(configvariable.expandValue(MobileNumberclick));


        }
    }

    public void EditMobileNumber(String platform, Map<String, String> registrationDetails, String buttontexts) {
        if ("iOS".equalsIgnoreCase(platform)) {
            //  testBasePage.clickButton(configvariable.expandValue(MobileNumber));
            appiumCommands.cleartext(By.xpath(configvariable.expandValue(MobileNumber)));
            String locator = configvariable.getFormattedString(configvariable.expandValue(MobileNumber), buttontexts);
            appiumCommands.clearAndEnterText(By.xpath(locator), buttontexts);


            //testBasePage.setTextWithTab(configvariable.expandValue(MobileNumber), configvariable.expandValue(registrationDetails.get("mobileNumber")));
        }

        if ("Android".equalsIgnoreCase(platform)) {

            //   appiumCommands.waitForVisibility(By.xpath(NoneofAbove));

            // appiumCommands.swipe(AppiumCommands.DIRECTION.UP, 6000);

            //  if (appiumCommands.isElementDisplayed(androidRegistrationLocator.NoneofAbove())) {
            //  appiumCommands.findElement(androidRegistrationLocator.NoneofAbove()).click();
            appiumCommands.cleartext(By.xpath(configvariable.expandValue(MobileNumber)));
            testBasePage.setTextWithTab(configvariable.expandValue(MobileNumber), configvariable.expandValue(registrationDetails.get("mobileNumber")));
            // appiumCommands.findElement(androidRegistrationLocator.mobileNumber()).sendKeys(registrationDetails.get("mobileNumber"));


        }
    }

    public void Datepickup(String platform, Map<String, String> registrationDetails, String buttontexts) {
        if ("iOS".equalsIgnoreCase(platform)) {
            //  testBasePage.clickButton(configvariable.expandValue(MobileNumber));
//            appiumCommands.cleartext(By.xpath(configvariable.expandValue(MobileNumber)));
//            String locator = configvariable.getFormattedString(configvariable.expandValue(MobileNumber), buttontexts);
//            appiumCommands.clearAndEnterText(By.xpath(locator), buttontexts);


            //testBasePage.setTextWithTab(configvariable.expandValue(MobileNumber), configvariable.expandValue(registrationDetails.get("mobileNumber")));
        }

        if ("Android".equalsIgnoreCase(platform)) {


            //  if (appiumCommands.isElementDisplayed(androidRegistrationLocator.NoneofAbove())) {
            //  appiumCommands.findElement(androidRegistrationLocator.NoneofAbove()).click();
            //   appiumCommands.cleartext(By.xpath(configvariable.expandValue(MobileNumber)));
            testBasePage.waitTime(5);

            String locator = configvariable.expandValue(datefile);
//            testBasePage.scrollUpTillElementDisplayed(locator);
//            testBasePage.scrollPageDown();
//            System.out.println("Finished");

            String locators = configvariable.expandValue(Datefields);
            testBasePage.scrollUpTillElementDisplayed(locators);
            testBasePage.scrollPageDown();

            // testBasePage.clickButton(locator);

            // testBasePage.setTextWithTab(configvariable.expandValue(datefile), configvariable.expandValue(registrationDetails.get("mobileNumber")));
            // appiumCommands.findElement(androidRegistrationLocator.mobileNumber()).sendKeys(registrationDetails.get("mobileNumber"));

        }
    }

    public void continueButton() {
        testBasePage.clickButton(configvariable.expandValue(continuesbutton));


    }

    public void continuebuttons(String platform) {
        if ("iOS".equalsIgnoreCase(platform)) {
            if (testBasePage.isElementDisplayed(configvariable.expandValue(continuetext))) {

                testBasePage.clickButton(configvariable.expandValue(continuetext));
                testBasePage.clickButton(configvariable.expandValue(continuesbutton));
            } else {
                testBasePage.clickButton(configvariable.expandValue(pulsematepopup));
                appiumCommands.tap(183, 583);
            }
            //   testBasePage.clickButton(configvariable.expandValue(continuetext));
            // appiumCommands.findElement(iosRegistrationLocator.showPassword).click();
            // testBasePage.clickButton(configvariable.expandValue(continuesbutton));

        } else if ("android".equalsIgnoreCase(platform)) {
            testBasePage.waitTime(5);
            System.out.println("Entering the pop up screen   ");
            testBasePage.clickButton(configvariable.expandValue(closecontinue));
            //testBasePage.clickButton(configvariable.expandValue(closecontinues));
            //  testBasePage.clickButton(configvariable.expandValue(closecontinuess));

            System.out.println("Entering the finished  pop up screen -------->  ");
//                for(int i=0;i<6;i++) {
//                    testBasePage.waitTime(10);
//                    if (testBasePage.isElementDisplayed(configvariable.expandValue(continuesbutton))) {
//                        testBasePage.clickButton(configvariable.expandValue(continuesbutton));
//
//                    }
//                    else
//                    {
//
//                        break;
//                    }
//
//                }
        }


    }

    public void enterDateOfBirth(String platform) {
        if ("iOS".equalsIgnoreCase(platform)) {
            testBasePage.clickButton(configvariable.expandValue(calendarIcon));
        } else if ("android".equalsIgnoreCase(platform)) {
            testBasePage.clickButton(configvariable.expandValue(calendarIcon));
            testBasePage.waitTime(5);
        }
    }

    public void doneButton(String platform) {
        if ("iOS".equalsIgnoreCase(platform)) {
            testBasePage.waitTime(3);
            testBasePage.clickButton(configvariable.expandValue(Donebutton));

        } else if ("android".equalsIgnoreCase(platform)) {
            testBasePage.waitTime(3);
            testBasePage.clickButton(configvariable.expandValue(doneButton));
        }
    }

    public void maleImage(String platform) {
        if ("iOS".equalsIgnoreCase(platform)) {
            testBasePage.clickButton(configvariable.expandValue(maleImages));
        } else if ("android".equalsIgnoreCase(platform)) {
            if (testBasePage.isElementDisplayed(configvariable.expandValue(maleImagess))) {
                testBasePage.clickButton(configvariable.expandValue(maleImagess));
            } else {
                testBasePage.clickButton(configvariable.expandValue(maleImages));
            }
        }
    }

    public void enterNric(String platform, Map<String, String> registrationDetails) {
        if ("iOS".equalsIgnoreCase(platform)) {
            //appiumCommands.findElement(androidRegistrationLocator.mobileNumber()).sendKeys(registrationDetails.get("NRICNumber"));
            testBasePage.setTextWithTab(configvariable.expandValue(NricNumbertext), registrationDetails.get("NRICNumber"));
        }

        if ("Android".equalsIgnoreCase(platform)) {


            appiumCommands.findElement(By.xpath(configvariable.expandValue(mobileNumber))).sendKeys(registrationDetails.get("NRICNumber"));
            testBasePage.clickButton(configvariable.expandValue(MobileNumbericon));
            // appiumCommands.findElement(androidRegistrationLocator.getLastName()).sendKeys(registrationDetails.get("LastName"));
            // appiumCommands.findElement(androidRegistrationLocator.getEmail()).sendKeys(configvariable.expandValue(registrationDetails.get("Email")));
            // appiumCommands.findElement(androidRegistrationLocator.getPhoneNumber()).sendKeys(registrationDetails.get("PhoneNumber"));
            // appiumCommands.findElement(androidRegistrationLocator.getPassword()).sendKeys(registrationDetails.get("Password"));
        }
    }

    public void freeAssement(String platform) {
        if ("iOS".equalsIgnoreCase(platform)) {
            testBasePage.waitTime(6);
            if (testBasePage.isElementDisplayed(configvariable.expandValue(ActivateIocnios))) {
                testBasePage.clickButton(configvariable.expandValue(ActivateIocnios));
                testBasePage.clickButton(configvariable.expandValue(ActivateiconsiOS));
                testBasePage.waitTime(6);
                testBasePage.clickButton(configvariable.expandValue(freeAssessmentios));
            } else {
                testBasePage.clickButton(configvariable.expandValue(ActivateIocnios));
            }
        } else if ("android".equalsIgnoreCase(platform)) {
            testBasePage.clickButton(configvariable.expandValue(ActivateIocn));
            testBasePage.waitTime(3);
            testBasePage.clickButton(configvariable.expandValue(Activateicons));
            testBasePage.waitTime(2);
            testBasePage.clickButton(configvariable.expandValue(freeAssement));
        }
    }

    public void backbutton_babylon(String platform) {
        if ("iOS".equalsIgnoreCase(platform)) {
            testBasePage.waitTime(4);
            if (testBasePage.isElementDisplayed(configvariable.expandValue(backbabylon))) {

                testBasePage.clickButton(configvariable.expandValue(backbabylon));
            } else {
                testBasePage.clickButton(configvariable.expandValue(pulsematepopup));
                appiumCommands.tap(183, 583);
                testBasePage.clickButton(configvariable.expandValue(backbabylon));
            }

        } else if ("android".equalsIgnoreCase(platform)) {
            testBasePage.clickButton(configvariable.expandValue(backbabylon));
        }
    }

    public void accountButton() {
        testBasePage.clickButton(configvariable.expandValue(Accountbutton));
    }

    public void isHomePageDisplayedbutton(String platform) {
        if (platform.equalsIgnoreCase("android")) {
            // testBasePage.isElementDisplayed(configvariable.getStringVar(homepageText));
            testBasePage.clickButton(configvariable.expandValue(homepagebutton));
        } else if (platform.equalsIgnoreCase("iOS")) {
            testBasePage.isElementDisplayed(configvariable.getStringVar(homescreen));
        }
    }


    /*public void isHomePageDisplayed(String platform) {
        if (platform.equalsIgnoreCase("android")) {
            testBasePage.isElementDisplayed(configvariable.getStringVar(homepageText));
        } else if (platform.equalsIgnoreCase("iOS")) {
            testBasePage.isElementDisplayed(configvariable.getStringVar(homescreen));
        }

    }*/
//=======
//        } else if ("Android".equalsIgnoreCase(platform)) {
//
//            //testBasePage.waitTime(10);
//            appiumCommands.waitForVisibility(By.xpath(accountbutton));
//            if(testBasePage.isElementDisplayed(configvariable.expandValue(accountbutton)))
//            {
//                testBasePage.clickButton(configvariable.expandValue(accountbutton));
//            }
//            else {
//                testBasePage.waitTime(2);
//                testBasePage.clickButton(configvariable.expandValue(accountbutton));
//>>>>>>> 8ff041bcca5694796aa186e77f0f254acc46869a
//            }
//        }
    //  }


//    public void TermsContinue(String platform) {
//        if ("iOS".equalsIgnoreCase(platform)) {
//            appiumCommands.findElement(iosRegistrationLocator.showPassword).click();
//
//        } else if ("android".equalsIgnoreCase(platform)) {
//            appiumCommands.waitForVisibility(androidRegistrationLocator.TermsContinue());
//            appiumCommands.findElement(androidRegistrationLocator.TermsContinue()).click();
//            appiumCommands.findElement(androidRegistrationLocator.Backbuttons()).click();
//
//        }
//    }
//    public void MySettings_button(String platform) {
//        if ("iOS".equalsIgnoreCase(platform)) {
//            testBasePage.waitTime(4);
//            appiumCommands.swipe(AppiumCommands.DIRECTION.DOWN, 6000);
//
//            testBasePage.clickButton(configvariable.expandValue(signout));
//
//        } else if ("android".equalsIgnoreCase(platform)) {
//            testBasePage.waitTime(4);
//            testBasePage.clickButton(configvariable.expandValue(MySettingsIcon));
//        }
//    }


//    public void enterRegistrationDetails(String platform, Map<String, String> registrationDetails) {
//        System.out.println("Entering the FirstName field");
//        appiumCommands.waitForVisibility(By.xpath(configvariable.expandValue(registerScreenFirstName)));
//        testBasePage.setTextWithTab(configvariable.expandValue(registerScreenFirstName), registrationDetails.get("FirstName"));
//        testBasePage.setTextWithTab(configvariable.expandValue(registerScreenLastName), registrationDetails.get("LastName"));
//        testBasePage.setTextWithTab(configvariable.expandValue(registerScreenEmail), configvariable.expandValue(registrationDetails.get("Email")));
//        System.out.println("Created Email :"+ configvariable.expandValue(registrationDetails.get("Email")));
//        // appiumCommands.findElement(androidRegistrationLocator.getPhoneNumber()).sendKeys(registrationDetails.get("PhoneNumber"));
//        testBasePage.setTextWithTab(configvariable.expandValue(registerScreenPassword), registrationDetails.get("Password"));
//
//
//    }
    /* public void isHomePageDisplayedbutton(String platform) {
   /* public void isHomePageDisplayedbutton(String platform) {
>>>>>>> 76297afa18b81c01dfa48ff0a5eecec2d752b019
        if (platform.equalsIgnoreCase("android")) {
            // testBasePage.isElementDisplayed(configvariable.getStringVar(homepageText));
            testBasePage.clickButton(configvariable.expandValue(homepagebutton));
        } else if (platform.equalsIgnoreCase("iOS")) {
            testBasePage.isElementDisplayed(configvariable.getStringVar(homescreen));
        }
<<<<<<< HEAD
    }

    /*public void isHomePageDisplayed(String platform) {
=======
    }*/

//
//    public void IsReviewandManagebutton(String platform) {
//        if (platform.equalsIgnoreCase("android")) {
//            // testBasePage.isElementDisplayed(configvariable.getStringVar(homepageText));
//            testBasePage.clickButton(configvariable.expandValue(ReviewManagebutton));
//        } else if (platform.equalsIgnoreCase("iOS")) {
//            testBasePage.isElementDisplayed(configvariable.getStringVar(homescreen));
//        }
//    }

    public void isHomePageDisplayed(String platform) {
        if (platform.equalsIgnoreCase("android")) {

            testBasePage.isElementDisplayed(configvariable.expandValue(homepageText));
        } else if (platform.equalsIgnoreCase("iOS")) {
            //  if (testBasePage.isElementDisplayed(configvariable.expandValue(homescreen))) {
            //  String locator = configvariable.expandValue(homescreen);
            //if (testBasePage.isElementDisplayed(locator)) {

            testBasePage.isElementDisplayed(configvariable.expandValue(homescreen));
            // } else {

            // testBasePage.clickButton(configvariable.expandValue(Skipicons));
            //   testBasePage.isElementDisplayed(configvariable.expandValue(homescreen));
//                appiumCommands.tap(191, 625);
//                //  testBasePage.clickButton(configvariable.expandValue(pulsematepopup));
//                appiumCommands.tap(183, 583);
            //  testBasePage.clickButton(configvariable.expandValue(pulsematepopup));
            //  }
        }
    }

    public void navigateToLoginPage(String platform) throws InterruptedException {
        if (platform.equalsIgnoreCase("android")) {
            testBasePage.waitTime(5);
            appiumCommands.waitForVisibility(By.xpath(configvariable.expandValue(continueWithEmailButton)));
            testBasePage.clickButton(configvariable.expandValue(continueWithEmailButton));
            testBasePage.clickButton(configvariable.expandValue(signInLink));
            appiumCommands.waitForVisibility(By.xpath(configvariable.expandValue(emailTextField)));
        } else if (platform.equalsIgnoreCase("iOS")) {
            testBasePage.waitTime(5);
            if (!testBasePage.isElementDisplayed(configvariable.expandValue(emailTextField))) {
                if (testBasePage.isElementDisplayed(configvariable.expandValue(Accountbutton))) {
                    pulseLoginScreen.clickSignOut();
                    testBasePage.isElementDisplayed(configvariable.expandValue(emailTextField));
                } else if (testBasePage.isElementDisplayed(configvariable.expandValue(continueWithEmailButton))) {
                    testBasePage.clickButton(configvariable.expandValue(continueWithEmailButton));
                    testBasePage.clickButton(configvariable.expandValue(signInLink));
                }
            }

        }
    }

    public void selectRegistrationCountry(String platform, String countryname) {
        testBasePage.waitTime(4);
        if (platform.equalsIgnoreCase("iOS")) {
            appiumCommands.isKeyBoardKeyPresent("Return");
            testBasePage.waitTime(4);
            testBasePage.clickBasedOnElement(configvariable.expandValue(registrationCountryDropDown), 131, 0);
            testBasePage.waitTime(5);
            testBasePage.clickButton(configvariable.expandValue(countryname));
        }
    }

    public void clickLocations(String platform) {
        if ("iOS".equalsIgnoreCase(platform)) {
            testBasePage.clickButton(configvariable.expandValue(calendarIcon));

        } else if ("android".equalsIgnoreCase(platform)) {
            testBasePage.waitTime(2);
            testBasePage.clickButton(configvariable.expandValue(locations));
            // appiumCommands.findElement(androidRegistrationLocator.Date_of_Birth()).click();
        }
    }

    public void clickResetButton(String platform) {
        if ("iOS".equalsIgnoreCase(platform)) {
//            appiumCommands.hideIOSKeyBoard();
            testBasePage.clickButton(configvariable.expandValue(getOTP));
            testBasePage.clickButton(configvariable.expandValue(Resendbuttons));
            testBasePage.clickButton(configvariable.expandValue(getOTP));

        } else if ("android".equalsIgnoreCase(platform)) {
            testBasePage.waitTime(2);
            appiumCommands.hideKeyboard();
            testBasePage.clickButton(configvariable.expandValue(clickResendbutton));
            testBasePage.clickButton(configvariable.expandValue(Resendbuttons));
        }
    }

    public boolean verifyOTPScreen() {
        return testBasePage.isElementDisplayed(configvariable.expandValue(clickResendbutton));
    }

    public void selectWellnessPackage() {
        // if (testBasePage.isElementDisplayed(configvariable.expandValue(wellnessScreenTitle))) {
        testBasePage.clickButton(configvariable.expandValue(wellnessPackage));
        // }
    }

    public void verifyHeightandWeightScreenUi() {
        softAssert.assertTrue(testBasePage.isElementDisplayed(configvariable.expandValue(userHeight)), "Default height section is not displayed in the UI");
        softAssert.assertTrue(testBasePage.isElementDisplayed(configvariable.expandValue(userWeight)), "Default weight section is not displayed in the UI");
        softAssert.assertAll();
    }

    public void clickCalculateBMIButton() {
        if (testBasePage.isElementDisplayed(configvariable.expandValue(calculateBMI)))
            testBasePage.clickButton(configvariable.expandValue(calculateBMI));
        else
            softAssert.fail("calculate BMI button is not displayed");
    }

    public void clickLightExercise() {
        testBasePage.clickButton(configvariable.expandValue(lightExercise));
    }

    public void clickFoodProducts() {
        testBasePage.clickButton(configvariable.expandValue(foodProducts));
    }

    public void selectFoodAllergies(String btnText) {
        if (testBasePage.isElementDisplayed(configvariable.expandValue(foodAllergies))) {
            if (btnText.equalsIgnoreCase(configvariable.expandValue("${option.yes.text}"))) {
                testBasePage.clickButton(configvariable.getFormattedString(configvariable.expandValue(allergyOptionLocator), btnText));
                testBasePage.clickButton(configvariable.getFormattedString(configvariable.expandValue(commonAllergyLocator), configvariable.expandValue("${peanut.allergy.text}")));
            } else {
                testBasePage.clickButton(configvariable.getFormattedString(configvariable.expandValue(allergyOptionLocator), btnText));
            }
        }
    }

    public void verifytrackerConnectScreenUI() {
        Assert.assertTrue(testBasePage.isElementDisplayed(configvariable.expandValue(wellnessTrackingActivity)), "Tracking your activity is trending title is not displayed in the UI");
    }

    public void verifyWelcomeToPulseScreen() {
        Assert.assertTrue(testBasePage.isElementDisplayed(configvariable.expandValue(welcomeToPulse)), "Welcome to Pulse title is not displayed in the UI");
    }

    public void verifyFitnessExclusiveOffersScreenUI() {
        Assert.assertTrue(testBasePage.isElementDisplayed(configvariable.expandValue(fitbitSubscriptionOffer)), "Fitness exclusive offer title is not displayed in the UI");
    }

    public void closeOffersScreen() {
        testBasePage.clickButton(configvariable.expandValue(exclusiveOfferCloseIcon));
    }

    public void navigateToMyLbuLoginPage(String platform, String countryName) {
        if (platform.equalsIgnoreCase("android")) {
            appiumCommands.waitForVisibility(By.xpath(configvariable.expandValue(continueWithEmailButton)));
            testBasePage.clickButton(configvariable.expandValue(continueWithEmailButton));
            testBasePage.clickButton(configvariable.expandValue(loginPageCountryDropDown));
            String locator = configvariable.getFormattedString(configvariable.expandValue(countryDropDownSelection), countryName);
            testBasePage.clickButton(configvariable.expandValue(locator));
            testBasePage.clickButton(configvariable.expandValue(loginSignText));
            testBasePage.clickButton(configvariable.expandValue(loginLangText));
        } else if (platform.equalsIgnoreCase("iOS")) {
            if (testBasePage.isElementDisplayed(configvariable.expandValue(Accountbutton))) {
                testBasePage.clickButton(configvariable.expandValue(Accountbutton));
                pulseLoginScreen.clickSignOut();
                testBasePage.isElementDisplayed(configvariable.expandValue(emailTextField));
            } else if (testBasePage.isElementDisplayed(configvariable.expandValue(continueWithEmailButton))) {
                testBasePage.clickButton(configvariable.expandValue(continueWithEmailButton));
                testBasePage.clickButton(configvariable.expandValue(signInLink));
            }
        }
    }


    public void changeTheCountryName(String platform, String countryName) {
        if (platform.equalsIgnoreCase("android")) {
            String selectedCountryLocator = configvariable.getFormattedString(configvariable.expandValue(countryFieldValueLocator), countryName);
            if (!testBasePage.isElementDisplayed(selectedCountryLocator)) {
                testBasePage.clickButton(configvariable.expandValue(loginPageCountryDropDown));
                String locator = configvariable.getFormattedString(configvariable.expandValue(countryDropDownSelection), countryName);
                testBasePage.scrollUpTillElementDisplayed(locator);
                testBasePage.clickButton(configvariable.expandValue(locator));
            }
        } else if (platform.equalsIgnoreCase("iOS")) {
            testBasePage.waitTime(4);
            String countryLabelLocator = configvariable.expandValue(loginPageCountryDropDown);
            String locator = configvariable.getFormattedString(configvariable.expandValue(countryDropDownSelection), countryName);
            testBasePage.clickBasedOnElement(countryLabelLocator, 104, 37);
//            appiumCommands.tap(171,560);
            if(!testBasePage.isElementDisplayed(locator)){
                testBasePage.clickElementByCoordinateForBothXY(countryLabelLocator, 126, 36);
            }
            testBasePage.scrollUpTillElementDisplayed(locator);
            testBasePage.clickButton(configvariable.expandValue(locator));
        }
    }

    public boolean verifyTheLanguageOptions(String lang) {
        return testBasePage.isElementDisplayed(configvariable.getFormattedString(configvariable.expandValue(languageOptions), lang));
    }

    public void readOTP(String emailId, String varName) {
        testBasePage.waitTime(Integer.parseInt(configvariable.expandValue("${otp.wait.time}")));
    //    String otp = pulseMailSacApi.getOTPFromEmail(emailId);
    //    configvariable.setStringVariable(otp, varName);
    }

    public void selectTheLanguage(String platform, String language) {
        if (platform.equalsIgnoreCase("android")) {
            String selectedLangLocator = configvariable.getFormattedString(configvariable.expandValue(languageFieldValueLocator), language);
            if (!testBasePage.isElementDisplayed(selectedLangLocator)) {
                testBasePage.clickButton(configvariable.expandValue(langDropDownLocator));
                String locator = configvariable.getFormattedString(configvariable.expandValue(selectLanguageLocator), language);
                testBasePage.clickButton(configvariable.expandValue(locator));
            }
        } else if (platform.equalsIgnoreCase("iOS")) {
            String languageLabelLocator = configvariable.expandValue(langDropDownLocator);
           // testBasePage.clickElementByCoordinateForBothXY(languageLabelLocator, 129, 44);

            testBasePage.clickBasedOnElement(languageLabelLocator, 111, 37);
            String locator = configvariable.getFormattedString(configvariable.expandValue(selectLanguageLocator), language);
            testBasePage.scrollUpTillElementDisplayed(locator);
            testBasePage.clickButton(configvariable.expandValue(locator));
        }
    }

    public void selectTheLanguageToggle(String lang) {
        String locator = configvariable.getFormattedString(configvariable.expandValue(languageOptions), lang);
        testBasePage.clickButton(locator);
        testBasePage.waitTime(2);
    }

    public boolean verifyValidationMessage(String errorMessage) {
        String locator = configvariable.getFormattedString(configvariable.expandValue(errorMessages), errorMessage);
        return testBasePage.isElementDisplayed(locator);
    }

    public void verifyCountryCode(String platfrom) {
        String expectedCountryCode = configvariable.expandValue("${country.code}");
        String locator = configvariable.expandValue(countryCodeLocator);
        String actualCountryCode;
        if (platfrom.equalsIgnoreCase("Android")) {
            actualCountryCode = testBasePage.getElementText(locator);
        } else {
            actualCountryCode = testBasePage.getElementAttributeValue(locator, "value");
        }
        Assert.assertEquals(actualCountryCode, expectedCountryCode, "actual country code is: " + actualCountryCode);
    }

    public boolean verifyRegistrationScreenFieldLabel(String fieldName) {
        String locator = configvariable.getFormattedString(configvariable.expandValue(fieldLabelLocator), fieldName);
        return testBasePage.isElementDisplayed(locator);
    }

    public void clickOnConnectLaterBtn() {
        testBasePage.clickButton(configvariable.expandValue(connectLaterBtnLocator));
    }

    public void clickSkipButton(String platform) {
        if (platform.equalsIgnoreCase("android")) {
            testBasePage.waitTime(4);
            if (testBasePage.isElementDisplayed(configvariable.expandValue(skipButtonInRegistrationScreen))) {
                testBasePage.clickButton(configvariable.expandValue(skipButtonInRegistrationScreen));
                testBasePage.waitTime(6);
            } else {
                if (testBasePage.isElementDisplayed(configvariable.expandValue(nonOfAboveLink))) {
                    testBasePage.waitTime(6);
                    testBasePage.clickButton(configvariable.expandValue(skipButtonInRegistrationScreen));
                } else {
                    testBasePage.setTextWithTab(configvariable.expandValue(MobileNumber), configvariable.expandValue("${registration.mobile.number}"));
                    testBasePage.clickButton(configvariable.expandValue(MobileNumberclick));
                    testBasePage.clickButton(configvariable.expandValue(continuesbutton));
                    if (testBasePage.isElementDisplayed(configvariable.expandValue(wellnessScreenTitle))) {
                        testBasePage.clickButton(configvariable.expandValue(wellnessPackage));
                    }
                    testBasePage.clickButton(configvariable.expandValue(continuesbutton));
                    testBasePage.waitTime(2);
                    testBasePage.clickButton(configvariable.expandValue(dateOfBirths));
                    testBasePage.waitTime(2);
                    String locators = configvariable.expandValue(Datefields);
                    testBasePage.scrollUpTillElementDisplayed(locators);
                    testBasePage.scrollPageDown();
                    testBasePage.waitTime(3);
                    testBasePage.clickButton(configvariable.expandValue(doneButton));
                    testBasePage.clickButton(configvariable.expandValue(continuesbutton));
                    if (testBasePage.isElementDisplayed(configvariable.expandValue(maleImages))) {
                        testBasePage.clickButton(configvariable.expandValue(maleImages));
                    }
                    testBasePage.clickButton(configvariable.expandValue(continuesbutton));
                    verifyHeightandWeightScreenUi();
                    clickCalculateBMIButton();
                    testBasePage.clickButton(configvariable.expandValue(continuesbutton));
                    testBasePage.clickButton(configvariable.expandValue(lightExercise));
                    testBasePage.clickButton(configvariable.expandValue(continuesbutton));
                    testBasePage.clickButton(configvariable.expandValue(foodProducts));
                    testBasePage.clickButton(configvariable.expandValue(continuesbutton));
                    testBasePage.waitTime(2);
                    testBasePage.clickButton(configvariable.expandValue(continuesbutton));
                    verifytrackerConnectScreenUI();
                    testBasePage.clickButton(configvariable.expandValue(connectLaterBtnLocator));
                    testBasePage.waitTime(2);
                    testBasePage.clickButton(configvariable.expandValue(continuesbutton));
                    testBasePage.waitTime(2);
                    testBasePage.clickButton(configvariable.expandValue(exclusiveOfferCloseIcon));
                    if(testBasePage.isElementDisplayed(configvariable.expandValue(nricNumberTextField))) {
                        testBasePage.setTextWithTab(configvariable.expandValue(nricNumberTextField), configvariable.expandValue("${nric.number.value}"));
                        testBasePage.clickButton(configvariable.expandValue(continuesbutton));
                    }
                    testBasePage.clickButton(configvariable.expandValue(skipButtonInRegistrationScreen));

                }
            }
        } else {
            testBasePage.setTextWithTab(configvariable.expandValue(MobileNumber), configvariable.expandValue("${registration.mobile.number}"));
            appiumCommands.clickElementByCoordinateforBothXY(169, 124);
           //if(testBasePage.isElementDisplayed(configvariable.expandValue(continuesbutton)))
              //  testBasePage.hideIOSKeyBoard("Done");
            testBasePage.clickButton(configvariable.expandValue(continuesbutton));
            if (testBasePage.isElementDisplayed(configvariable.expandValue(wellnessScreenTitle))) {
                testBasePage.clickButton(configvariable.expandValue(wellnessPackage));
                testBasePage.clickButton(configvariable.expandValue(continuesbutton));
            }
            if (testBasePage.isElementDisplayed(configvariable.expandValue(dobScreenLocator))) {
                testBasePage.clickButton(configvariable.expandValue(dateOfBirths));
                testBasePage.waitTime(2);
                testBasePage.clickButton(configvariable.expandValue(doneButton));
                testBasePage.clickButton(configvariable.expandValue(continuesbutton));
            }
            if (testBasePage.isElementDisplayed(configvariable.expandValue(genderScreenLocator))) {
                testBasePage.clickButton(configvariable.expandValue(maleImages));
                testBasePage.clickButton(configvariable.expandValue(continuesbutton));
            }
            if (testBasePage.isElementDisplayed(configvariable.expandValue(calculateBMI))) {
                testBasePage.clickButton(configvariable.expandValue(calculateBMI));
                testBasePage.clickButton(configvariable.expandValue(continuesbutton));
            }
            if (testBasePage.isElementDisplayed(configvariable.expandValue(lightExercise))) {
                testBasePage.clickButton(configvariable.expandValue(lightExercise));
                testBasePage.clickButton(configvariable.expandValue(continuesbutton));
            }
            if (testBasePage.isElementDisplayed(configvariable.expandValue(foodProducts))) {
                testBasePage.clickButton(configvariable.expandValue(foodProducts));
                testBasePage.clickButton(configvariable.expandValue(continuesbutton));
            }
            if (testBasePage.isElementDisplayed(configvariable.expandValue(foodAllergiesScreenLocator))) {
                testBasePage.clickButton(configvariable.expandValue(continuesbutton));
            }
            if (testBasePage.isElementDisplayed(configvariable.expandValue(wellnessTrackingActivity))) {
                testBasePage.clickButton(configvariable.expandValue(connectLaterBtnLocator));
            }
            if (testBasePage.isElementDisplayed(configvariable.expandValue(welcomeToPulse))) {
                testBasePage.clickButton(configvariable.expandValue(continuesbutton));
            }
            if (testBasePage.isElementDisplayed(configvariable.expandValue(exclusiveOfferCloseIcon))) {
                testBasePage.clickButton(configvariable.expandValue(exclusiveOfferCloseIcon));
            }
            if (testBasePage.isElementDisplayed(configvariable.expandValue(pulsePersonalisedScreenLocator))) {
                testBasePage.clickButton(configvariable.expandValue(skipButtonInRegistrationScreen));
            }
            testBasePage.waitTime(5);
            if (testBasePage.isElementDisplayed(configvariable.expandValue(faceIdEnrollButton)))
                testBasePage.clickButton(configvariable.expandValue(faceIdNotnowButton));
        }

    }


    public boolean verifyInvalidMsg(String invalidMsg) {
        testBasePage.waitTime(3);
        String errorLocator = configvariable.getFormattedString(configvariable.expandValue(wellnessScreenValidationLocator), invalidMsg);
        return testBasePage.isElementDisplayed(errorLocator);
    }

    public void navigateToRegistrationPage() {
        //click on signin link on signup page
        testBasePage.clickButton(configvariable.expandValue(signin));
        testBasePage.waitTime(2);
        //click on signup link on signin page
        testBasePage.clickButton(configvariable.expandValue(SignUpLink));
        testBasePage.waitTime(2);
    }

    public void selectContinueWithEmailBtn() {
        String locator = configvariable.expandValue(continueWithEmailButton);
        testBasePage.clickButton(locator);
    }

    public void enterNric(String nricNumber) {
     /*   if ("iOS".equalsIgnoreCase(platform)) {
            //appiumCommands.findElement(androidRegistrationLocator.mobileNumber()).sendKeys(registrationDetails.get("NRICNumber"));
            testBasePage.setTextWithTab(configvariable.expandValue(NricNumbertext), nricNumber);
        }

        if ("Android".equalsIgnoreCase(platform)) { */
        if(testBasePage.isElementDisplayed(configvariable.expandValue(nricNumberTextField))) {
            testBasePage.setTextWithTab(configvariable.expandValue(nricNumberTextField), nricNumber);
            appiumCommands.waitForClickable(By.xpath(configvariable.expandValue(continuesbutton)));
            testBasePage.clickButton(configvariable.expandValue(continuesbutton));
        }
        // }
    }

}
