package com.onepulse.app.utils;

import com.onepulse.app.config.ConfigDetails;
import com.onepulse.app.screens.TestBasePage;
import com.prod.tap.config.Configvariable;
import com.prod.tap.cucumberUtils.ScenarioUtils;
import com.prod.tap.filehandling.FileReaderUtil;
import com.prod.tap.filehandling.JsonReader;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.InputStream;
import java.util.Map;

@Component
public class HRMalinatorUi {

    private static final Logger logger = Logger.getLogger(HRMalinatorUi.class);

    @Autowired
    private Configvariable configvariable;

    @Autowired
    private JsonReader jsonReader;

    @Autowired
    private ScenarioUtils scenarioUtils;

    @Autowired
    private TestBasePage hrTestBasePage;

    @Autowired
    private HRMalinatorApi hrMalinatorApi;


    public void navigateToMailinatorUI(String emailId) {
        String[] parts = emailId.split("@");
        String url = configvariable.getFormattedString(configvariable.getStringVar(ConfigDetails.MAILINATOR_UI_APP), parts[0]);
        scenarioUtils.write("Mailinator url is " + url);
      //  hrTestBasePage.launchMailinatorUI_web(url);
        hrTestBasePage.navigateToApplicationUrl(url);

    }

    public void clickEmailWithSubject(String subject) {
        String locator = configvariable.getFormattedString("//a[contains(text(),'%s')][1]", configvariable.expandValue(subject));
        hrTestBasePage.clickButton(locator);
        hrTestBasePage.waitTime(7);
    }

    public void readOTPFromMailBody(String otpVar) {
        hrTestBasePage.switchToFrame("msg_body");
        String locator = "//html/body";
        String body = hrTestBasePage.getText(locator);
        String emailOTP;
        if (otpVar.equalsIgnoreCase("EMP_OTP")) {
            emailOTP = getEmpOTP(body);
        } else {
            emailOTP = getOTP(body);
        }
        scenarioUtils.write("Email OTP is " + emailOTP);
        configvariable.setStringVariable(emailOTP, otpVar);
        hrTestBasePage.closeBrowser();
    }

    public String getOTP(String mailBody) {
        String otp = mailBody.split(":")[1].split("\n\n")[0];
        if (!otp.isEmpty()) {
            logger.info("Found otp {}" + otp);
            return otp;
        } else {
            logger.error("Can't find otp. Probably email format has changed.");
        }
        return null;
    }

    public void readRegistrationEmailFromMailBody(String linkName) {
        String link = linkName.split(" ")[1];
        hrTestBasePage.switchToFrame("msg_body");
        String locator = configvariable.getFormattedString("//a[contains(text(),'%s')]", link);
        String linkUrl = hrTestBasePage.getAttributeValue(locator, "href");
        scenarioUtils.write("Registration link is " + linkUrl);
        configvariable.setStringVariable(linkUrl, "hr.registration.ui.url");
    }

    public void getVerificationTokenCode(String url, Map<String, String> variables) {
        String[] parts = url.split("&");
        String token = parts[1].split("=")[1];
        String code = parts[2].split("=")[1];
        configvariable.setStringVariable(token.trim(), variables.get("token"));
        configvariable.setStringVariable(code.trim(), variables.get("code"));
    }


    public void clickEmailWithFrom(String from) {
        String locator = configvariable.getFormattedString("//td[contains(text(),'%s')][1]", configvariable.expandValue(from));
        hrTestBasePage.clickButton(locator);
        hrTestBasePage.waitTime(7);
    }

    public void readVerificationEmailFromMailBody(String linkName) {
        hrTestBasePage.switchToFrame("msg_body");
        String locator = configvariable.getFormattedString("//a[text()='%s']", linkName);
        hrTestBasePage.scrollTillElementFound(locator);
        String linkUrl = hrTestBasePage.getAttributeValue(locator, "href");
        scenarioUtils.write("Registration link is " + linkUrl);
        configvariable.setStringVariable(linkUrl, "hr.activation.ui.url");
    }

    public String getEmpOTP(String mailBody) {
        String otp = mailBody.split("Your verification code is\n")[1].split("\n")[0];
        if (!otp.isEmpty()) {
            logger.info("Found otp {}" + otp);
            return otp;
        } else {
            logger.error("Can't find otp. Probably email format has changed.");
        }
        return null;
    }

    public void readRequestNumberFromMailBody(String varName) {
        hrTestBasePage.switchToFrame("msg_body");
        String locator = "//html/body";
//        String body = hrTestBasePage.getText(locator);
        String requestNumber = null;
//       requestNumber = getRequestNumber(body);
        scenarioUtils.write("Request Number is " + requestNumber);
        configvariable.setStringVariable(requestNumber, varName);
    }

    public void clickEmailWithFromAndSubject(String from, String subject) {
        String locator = String.format("//td[contains(text(),'%s')]/following-sibling::td/a[contains(text(),'%s')]", configvariable.expandValue(from), configvariable.expandValue(subject));
        hrTestBasePage.clickButton(locator);
        hrTestBasePage.waitTime(7);
    }

    public void readHREasilyRegistrationEmailFromMailBody(String linkName) {
        hrTestBasePage.switchToFrame("msg_body");
        String locator = configvariable.getFormattedString("//a[contains(text(),'%s')]", linkName);
        hrTestBasePage.scrollTillElementFound(locator);
        String linkUrl = hrTestBasePage.getAttributeValue(locator, "href");
        scenarioUtils.write("Registration link is " + linkUrl);
        configvariable.setStringVariable(linkUrl, "hr.easily.registration.ui.url");
    }

    public void readStashRegistrationEmailFromMailBody(String linkName) {
        hrTestBasePage.switchToFrame("msg_body");
        String locator = configvariable.getFormattedString("//a[contains(text(),'%s')]", linkName);
        hrTestBasePage.scrollTillElementFound(locator);
        String linkUrl = hrTestBasePage.getAttributeValue(locator, "href");
        scenarioUtils.write("Registration link is " + linkUrl);
        configvariable.setStringVariable(linkUrl, "hr.stash.registration.ui.url");
    }

    public String getEmailFrameBody(){
        hrTestBasePage.switchToFrame("msg_body");
        return hrTestBasePage.getText("//html/body");
    }

    public boolean CheckEmailWithFromAndSubject(String from, String subject){
        String locator = String.format("//td[contains(text(),'%s')]/following-sibling::td/a[contains(text(),'%s')]", configvariable.expandValue(from), configvariable.expandValue(subject));
        return hrTestBasePage.isElementPresent(locator);
    }

    public String getEmailBodyContent(String emailAddress){
        hrTestBasePage.waitTime(20);
        navigateToMailinatorUI(configvariable.expandValue(configvariable.expandValue(emailAddress)));
        clickEmailWithFromAndSubject("${EMAIL_FROM}", "${EMAIL_SUBJECT}");
        return getEmailFrameBody();
    }

    public boolean isEmailBodyMatchingWithTemplateFile(String fileName){
        InputStream initialStream = getClass().getResourceAsStream(configvariable.expandValue(fileName));
        String fileToCompare =null;
        String fileFromCompare =null;
        String fileToCompare1 = FileReaderUtil.convertFileToString(initialStream);
        String fileFromCompare1 = getEmailBodyContent("${EMAIL_TO}");
        if(fileName.contains("OTP")){
            fileToCompare = fileToCompare1.split(":")[0].trim();
            fileFromCompare = fileFromCompare1.split(":")[0].trim();
        }else{
            fileToCompare = fileToCompare1;
            fileFromCompare = fileFromCompare1;
        }
        scenarioUtils.write("Expected email content "+ configvariable.expandValue(fileToCompare));
        scenarioUtils.write("Actual email content "+ fileFromCompare);
        String[] expectedArray =configvariable.expandValue(fileToCompare).split("\n");
        String[] actualArray = fileFromCompare.split("\n");
        boolean match=false;
        for(int iCount=0; iCount<expectedArray.length;iCount++){
            String val=expectedArray[iCount];
            if(!val.isEmpty() ){
                if(val.equals(actualArray[iCount])){
                    match=true;
                }else{
                    match=false;
                    break;
                }
            }
        }

        return match;

    }

}
