package com.onepulse.app.api;

//import com.prudential.tap.api.HttpClientApi;

import com.prod.tap.config.Configvariable;
import com.prod.tap.cucumberUtils.ScenarioUtils;
import com.prod.tap.filehandling.JsonReader;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Component
public class PulseMailSacApi {
    private static final Logger logger = Logger.getLogger(PulseMailSacApi.class);

    @Autowired
    private Configvariable configvariable;

    @Autowired
    private JsonReader jsonReader;

//    @Autowired
//    private HttpClientApi httpClientApi;

    @Autowired
    private ScenarioUtils scenarioUtils;

    private static final String SUPPORTED_DOMAIN = "mailsac.com";
    public static String MAILSAC_URL_GETID = "https://mailsac.com/api/addresses/%s/messages";
    public static String MAILSAC_URL_GETMESSAGE = "https://mailsac.com/api/dirty/%s/%s";


    public Map<String, String> setHeader() {
        Map<String, String> variableMap = new HashMap<>();
        variableMap.put(configvariable.expandValue("${auth.mailsac.api.key}"), configvariable.expandValue("${auth.mailsac.api.value}"));
        return variableMap;

    }

//    public String getMessageIdFromMailsacEmail(String emailAddress) {
//        Map<String, Object> responseMap = new HashMap<>();
//        String[] parts = emailAddress.split("@");
//        if (parts.length != 2) {
//            logger.error("Wrong format of email");
//        }
//
//        if (!parts[1].equalsIgnoreCase(SUPPORTED_DOMAIN)) {
//            logger.error("Unsupported email domain for Email OTP reader");
//        }
//
////        String url = String.format(MAILSAC_URL_GETID, emailAddress);
////        httpClientApi.createHttpClient1();
////        scenarioUtils.write("API Url is :" + url);
////        httpClientApi.setUrl(url);
////        httpClientApi.setSendHeaders(setHeader());
////        logger.info("Sending get request");
////        String response = httpClientApi.executeRequestAndGetResponse("get");
////        String response1 = response.substring(1, response.length() - 1);
////        responseMap = jsonReader.convertJsonStringToMap(response1);
////        String msgId = responseMap.get("_id").toString();
////        if (responseMap.get("_id") == null) {
////            throw new TapException(TapExceptionType.PROCESSING_FAILED, "Not able to fetch email from mailsac [{}]", new Object[]{response});
////        } else {
////            logger.info("mailSac ID is : " + msgId);
////            configvariable.setStringVariable(msgId, "MSG_ID");
////            return msgId;
////
////        }
//    }


//    public String readEmailFormat(String emailAddress, String mailId) {
//        String url = String.format(MAILSAC_URL_GETMESSAGE, emailAddress, mailId);
////        httpClientApi.createHttpClient1();
////        scenarioUtils.write("API Url is :" + url);
////        httpClientApi.setUrl(url);
////        httpClientApi.setSendHeaders(setHeader());
////        logger.info("Sending get request");
////        String response = httpClientApi.executeRequestAndGetResponse("get");
////        if (response == null) {
////            logger.error("Unable to read email from mailinator = " + mailId);
////            throw new TapException(TapExceptionType.PROCESSING_FAILED, "Unable to read email from mailinator [{}]", new Object[]{mailId});
////        } else {
////            httpClientApi.closeHttpClent();
////            return response;
////        }
//    }


//    public String getOTPFromEmail(String mailId) {
//        getMessageIdFromMailsacEmail(mailId);
//        String responseBody = readEmailFormat(mailId, configvariable.getStringVar("MSG_ID"));
//        Document doc = Jsoup.parse(responseBody);
//        Elements h3s = doc.getElementsByTag("a");
//        if (h3s != null && h3s.size() == 1) {
//            String otp = h3s.get(0).text();
//            logger.info("Found otp {}" + otp);
//            return otp;
//        } else if (h3s.size() == 2) {
//            String otp = h3s.get(0).text();
//            logger.info("Found otp {}" + otp);
//            return otp;
//        } else {
//            logger.error("Can't find otp. Probably email format has changed.");
//        }
//
//        return null;
//
//    }

//    public int getEmailCount(String emailAddress) {
//        Map<String, Object> responseMap = new HashMap<>();
//        String[] parts = emailAddress.split("@");
//        if (parts.length != 2) {
//            logger.error("Wrong format of email");
//        }
//
//        if (!parts[1].equalsIgnoreCase(SUPPORTED_DOMAIN)) {
//            logger.error("Unsupported email domain for Email OTP reader");
//        }

//        String url = String.format(MAILSAC_URL_GETID, emailAddress);
//        httpClientApi.createHttpClient1();
//        scenarioUtils.write("API Url is :" + url);
//        Map<String, String> authVariableMap = new HashMap<>();
//        authVariableMap.put(Configvariable.envPropertyMap.get("auth.mailsac.api.key"), Configvariable.envPropertyMap.get("auth.mailsac.api.value"));
//        httpClientApi.setUrl(url);
//        httpClientApi.setSendHeaders(authVariableMap);
//        logger.info("Sending get request");
//        String response = httpClientApi.executeRequestAndGetResponse("get");
//        System.out.println("MailSac API response " + response);
//        if (response == null)
//            return 0;
//        else {
//            JSONArray array = new JSONArray(response);
//            return array.length();
//        }
//    }


}
