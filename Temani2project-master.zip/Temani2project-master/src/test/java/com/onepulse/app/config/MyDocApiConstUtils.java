package com.onepulse.app.config;

public class MyDocApiConstUtils {

        public static String LocalBase_URL = "http://localhost:3000";
        public static String Local_EndPoint = "/posts";
        public static String MYDOC_CLIENT_ID = "7f5c866f-14f2-4d74-af5d-28a3bcf646b9";
        public static String MYDOC_CLIENT_SECRETID = "420e13ff-c69f-4fa5-940b-212f37acfbda";
        public static String MYDOC_BASE_URL = "mydoc.api.url";
        public static String MYDOC_PATIENT_VERIFY = "/api/v2/verifications";
        public static String MYDOC_LOGIN_ENDPOINT = "/oauth/access_token";
        public static String MYDOC_CREATE_PATIENT_ENDPOINT = "/api/v2/accounts/patients";
        public static String MYDOC_GROUPID = "612";
        public static String MYDOC_PATIENT_ACCESS_TOKEN = "/oauth/access_token";
        public static String Login1_path ="${Login1.path}";
        public static String local_userEndpoints = "/users";
        public static String local_comentsEndpoints = "/comments";
        public static String GihubLocalBase_URL = "https://github.com";
        public static String Github_Local_EndPoint = "/manivannanpannerselvam?tab=repositories";
        public static String github_localendpoint = "/torvalds/linux";
        public static String SecondRepo_EndPoint = "/torvalds/libdc-for-dirk";
        public static String DEVICEFARM_DEVICE_PLATFORM_NAME = "web";
        public static String app_env = "UAT";
        public static String app_lbu = "sg";
        public static String app_language = "en";
        //To be picked Up--
       // public static String MYDOC_APPOINTMENTS_ENDPOINT = "/api/v2/accounts/${DoctorId}/appointments";
      //  ttps://api.prudential-pulse-uat.my-doc.com//api/v2/testing/appointments/15424/accept
        /*public static String MYDOC_APPOINTMENTS_ENDPOINT = "/api/v2/accounts/${DoctorId}/appointments";
        public static String MYDOC_ACCEPT_REJECT_ENDPOINT = "/api/v2/doctors/${DoctorId}/appointments/${appointment_Id}";
        public static String MYDOC_SEARCH_PATIENT_ENDPOINT = "/api/v2/accounts/${DoctorId}/patients?search=${FIRST_NAME}&page=1";
        public static String MYDOC_CREATE_EPISODE_ENDPOINT = "/api/v2/accounts/episodes";
        public static String MYDOC_SEND_MESSAGE_ENDPOINT = "/api/v2/messages/save";
        public static String MYDOC_CREATE_EMC_ENDPOINT = "/api/v2/accounts/emc";
        public static String MYDOC_SEND_EMC_ENDPOINT = "/api/v2/accounts/emc/${EMC_ID}/send";
        public static String MYDOC_CREATE_CASENOTE_ENDPOINT = "/api/v2/casenotes";
        public static String MYDOC_CLOSE_CASENOTE_ENDPOINT = "/api/v2/accounts/episodes/${EPISODE_ID}/close";
        public static String MYDOC_GET_MESSAGE_ENDPOINT = "/api/v2/accounts/episodes/${EPISODE_ID}/messages";
        public static String MYDOC_CREATE_APPOINTMENT_ENDPOINT = "/api/v2/doctors/${DoctorId}/appointments";
        public static String MYDOC_ADD_NRIC_PATIENT_ENDPOINT = "/api/v2/accounts/identities/attach";
        public static String MYDOC_GET_ACCT_ENDPOINT = "/api/v2/accounts/${PATIENT_ID}";
        public static String MYDOC_GET_ACCTGROUPS = "/api/v2/accounts/${PATIENT_ID}/groups";
        public static String MYDOC_CREATE_GET__EMERGENCYCONTACTS_ENDPOINT = "/api/v2/accounts/emergencyContacts";
        public static String MYDOC_GET_GROUPS = "/api/v2/public/groups/${MYDOC_GROUPID}";
        public static String MYDOC_AVAILABLE_PROFESSIONALS_ENDPOINT = "/api/v2/groups/"+MYDOC_GROUPID+"/availableProfessional";
        public static String MYDOC_UPDATE_DELETE_EMERGENCYCONTACTS_ENDPOINT = "/api/v2/accounts/emergencyContacts/${MYDOC_EMERGENCY_CONTACT_ID}";*/


       // https://api.prudential-pulse-uat.my-doc.com//api/v2/testing/appointments/15424/accept

        public static String MYDOC_APPOINTMENTS_ENDPOINT = "/api/v2/accounts/${DoctorId}/appointments";
       // public static String MYDOC_APPOINTMENTS_ENDPOINT = "//api/v2/accounts/testing/15424/accept";
        public static String MYDOC_ACCEPT_REJECT_ENDPOINT = "/api/v2/testing/appointments/${appointment_Id}/accept";
        public static String MYDOC_SEARCH_PATIENT_ENDPOINT = "/api/v2/accounts/${DoctorId}/patients?search=${FIRST_NAME}&page=1";
        public static String MYDOC_CREATE_EPISODE_ENDPOINT = "/api/v2/accounts/episodes";
        public static String MYDOC_SEND_MESSAGE_ENDPOINT = "/api/v2/messages/save";
        public static String MYDOC_CREATE_EMC_ENDPOINT = "/api/v2/accounts/emc";
        public static String MYDOC_SEND_EMC_ENDPOINT = "/api/v2/accounts/emc/${EMC_ID}/send";
        public static String MYDOC_CREATE_CASENOTE_ENDPOINT = "/api/v2/casenotes";
        public static String MYDOC_CLOSE_CASENOTE_ENDPOINT = "/api/v2/accounts/episodes/${EPISODE_ID}/close";
        public static String MYDOC_GET_MESSAGE_ENDPOINT = "/api/v2/accounts/episodes/${EPISODE_ID}/messages";
        public static String MYDOC_CREATE_APPOINTMENT_ENDPOINT = "/api/v2/doctors/${DoctorId}/appointments";
        public static String MYDOC_ADD_NRIC_PATIENT_ENDPOINT = "/api/v2/accounts/identities/attach";
        public static String MYDOC_GET_ACCT_ENDPOINT = "/api/v2/accounts/${PATIENT_ID}";
        public static String MYDOC_GET_ACCTGROUPS = "/api/v2/accounts/${PATIENT_ID}/groups";
        public static String MYDOC_CREATE_GET__EMERGENCYCONTACTS_ENDPOINT = "/api/v2/accounts/emergencyContacts";
        public static String MYDOC_GET_GROUPS = "/api/v2/public/groups/${MYDOC_GROUPID}";
        public static String MYDOC_AVAILABLE_PROFESSIONALS_ENDPOINT = "/api/v2/groups/"+MYDOC_GROUPID+"/availableProfessional";
        public static String MYDOC_UPDATE_DELETE_EMERGENCYCONTACTS_ENDPOINT = "/api/v2/accounts/emergencyContacts/${MYDOC_EMERGENCY_CONTACT_ID}";


}
