package com.onepulse.app.locators.ios.mydoc;

import org.openqa.selenium.By;
import org.springframework.stereotype.Component;

@Component
public class IOSMyDocPaymentDetailsLocator {
//    public By paymentDetailWhatIsThisFor = By.xpath("//XCUIElementTypeStaticText[@name='The SGD 27 fee covers a video consultation of up to 15 minutes.']");
    //covid19
    public By paymentDetailWhatIsThisFor = By.xpath("//XCUIElementTypeStaticText[@name='The SGD 15 fee covers a video consultation of up to 15 minutes.']");
    public By paymentDetailDoesIncludeMedication = By.xpath("//XCUIElementTypeStaticText[@name='The cost of medication is not included.']");
    public By paymentDetailWhenIWillCharged = By.xpath("//XCUIElementTypeStaticText[@name='The amount will be charged to your card after the video consultation concludes.']");
    public By enterCardDetailsButton = By.xpath("(//XCUIElementTypeOther[@name='Enter Card Details'])[3]");
    public By accessAddedCard = By.xpath("//XCUIElementTypeStaticText[@name=\"Ending With 1111\"]");
    public By addNewCard = By.xpath("//XCUIElementTypeStaticText[@name='Add new cards']");
    public By confirmPaymentMethodButton = By.xpath("//XCUIElementTypeButton[@name='CONFIRM PAYMENT METHOD']");
    public By keyBoardDoneButton = By.xpath("//XCUIElementTypeButton[@name='Done']");
    public By CardNumber = By.xpath("//XCUIElementTypeOther[@name='Secure Credit Card Frame - Credit Card Number']/XCUIElementTypeTextField[1]");
    public By expirationDate = By.xpath("//XCUIElementTypeOther[@name='Secure Credit Card Frame - Expiration Date']/XCUIElementTypeTextField");
    public static String addedCardType = "//XCUIElementTypeStaticText[@name='%s']";
}
