package com.onepulse.app.locators.ios.mydoc;

import org.openqa.selenium.By;
import org.springframework.stereotype.Component;

@Component
public class IOSMyDocHealthOptionsLocator {
    public By needADoc = By.xpath("//XCUIElementTypeOther[@name='Need a doctor? Get a video consultation.']");
    public By howHealthy = By.xpath("//XCUIElementTypeOther[@name='How Healthy are you? Take this health assessment test.']");
    public By feelingUnwell = By.xpath("//XCUIElementTypeOther[@name='Feeling Unwell? Find out what your symptoms could mean.']");

}
