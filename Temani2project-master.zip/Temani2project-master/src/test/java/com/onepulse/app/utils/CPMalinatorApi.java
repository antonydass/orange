package com.onepulse.app.utils;


import com.onepulse.app.screens.TestBasePage;
import com.prod.tap.api.TapMalinatorApi;
import com.prod.tap.config.Configvariable;
import com.prod.tap.cucumberUtils.ScenarioUtils;
import com.prod.tap.filehandling.JsonReader;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

@Component
public class CPMalinatorApi {
    private static final Logger logger = LoggerFactory.getLogger(CPMalinatorApi.class);

    @Autowired
    private Configvariable configvariable;

    @Autowired
    private JsonReader jsonReader;

    @Autowired
    private TapMalinatorApi tapMalinatorApi;

    @Autowired
    private ScenarioUtils scenarioUtils;

    @Autowired
    private TestBasePage cpTestBasePage;


    public String getOTPFromEmail(String mailId) {
        tapMalinatorApi.getMessageIdFromMailinatorEmail(mailId);
        String responseBody = tapMalinatorApi.readEmailFormat(configvariable.getStringVar("MSG_ID"));
        Map<String, Object> resMap = jsonReader.convertJsonStringToMap(responseBody);
        HashMap<Object, Object> dataObject = (HashMap<Object, Object>) resMap.get("data");
        ArrayList<Object> partsObject = (ArrayList<Object>) dataObject.get("parts");
        HashMap<String, String> bodyObject = (HashMap<String, String>) partsObject.get(0);
        String mailBody = bodyObject.get("body");
        Document doc = Jsoup.parse(mailBody);
        Elements h3s = doc.getElementsByTag("h3");
        if (h3s != null && h3s.size() == 1) {
            String otp = h3s.get(0).text();
            logger.info("Found otp {}" + otp);
            return otp;
        } else {
            logger.error("Can't find otp. Probably email format has changed.");
        }

        return null;

    }

    public void navigateToMailinatorUI(String emailId) {
        String[] parts = emailId.split("@");
        String url = configvariable.getFormattedString(configvariable.getStringVar("mailinator.ui.url"), parts[0]);
        scenarioUtils.write("Mailinator url is " + url);
        cpTestBasePage.launchMailinatorUI(url);
    }

    public void clickEmailWithSubject(String subject) {
        //  String locator = configvariable.getFormattedString("//a[contains(text(),'%s')][1]", configvariable.expandValue(subject));
        //  String locator = configvariable.getFormattedString(".//a[contains(text(),'LOGIN')]/following::a[6]", configvariable.expandValue(subject));

        String locator = configvariable.getFormattedString("(//a[contains(text(),'%s')])[1]", configvariable.expandValue(subject));

        cpTestBasePage.clickButton(locator);
        cpTestBasePage.waitTime(7);
    }

    public void readOTPFromMailBody(String otpVar) {
        cpTestBasePage.switchToFrame("msg_body");
        String locator = "//html/body";
        String body = cpTestBasePage.getText(locator);
        String emailOTP = getOTP(body);
        scenarioUtils.write("Email OTP is " + emailOTP);
        configvariable.setStringVariable(emailOTP, otpVar);
        cpTestBasePage.closeBrowser();
    }

    public String getOTP(String mailBody) {
        String otp = mailBody.split("Your verification code is\n")[1].split("\n")[0];
        if (!otp.isEmpty()) {
            logger.info("Found otp {}" + otp);
            return otp;
        } else {
            logger.error("Can't find otp. Probably email format has changed.");
        }
        return null;
    }


}
