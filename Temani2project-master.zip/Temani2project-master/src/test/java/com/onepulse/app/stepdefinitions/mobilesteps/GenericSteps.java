package com.onepulse.app.stepdefinitions.mobilesteps;

public class GenericSteps {
   // private Configvariable configvariable = CucumberHook.context.getBean(Configvariable.class);
    //private AppiumCommands appiumCommands = CucumberHook.context.getBean(AppiumCommands.class);


    /*@And("I assign \"([^\"]*)\" to variable \"([^\"]*)\"")
    public void assignValueToVariable(String value, String Variable) {
        configvariable.assignValueToVar(value, Variable);
    }*/

    /*@When("I generate random number and assign to variable \"([^\"]*)\"")
    public void generateRandomNumberAndAssignToVariable(String varName) {
        Random rand = new Random();
        int random_num = rand.nextInt(1000);
        String num = Integer.toString(random_num);
        configvariable.setStringVariable(num + configvariable.generateRandomNumber("ddMMHMs"), varName);
    }*/

    /*@When("I assign value to following variables")
    public void assignValueToVariables(DataTable userDetails) {
        Map<String, String> variableMap;
        variableMap = userDetails.asMap(String.class, String.class);
        configvariable.assignValueToVarMap(variableMap);
    }

    @When("I relaunch app")
    public void relaunchApp() {
        if ("iOS".equalsIgnoreCase(BaseSteps.platform)) {
            appiumCommands.relaunchApp();
        } else if ("Android".equalsIgnoreCase(BaseSteps.platform)) {
            appiumCommands.relaunchAndroidApp(Configvariable.envPropertyMap.get("pulse.android.app.package"), Configvariable.envPropertyMap.get("pulse.android.app.activity"));
        }
    }

    @When("I calculate age of the user is (.*) in \"([^\"]*)\" format from current date and assign to variable \"([^\"]*)\"")
    public void calculateAge(int age, String format, String varName) {
        configvariable.setStringVariable(configvariable.minusYearFromCurrentDate(age, format), varName);
    }

    @When("I generate time in format \"([^\"]*)\" and assign to variable \"([^\"]*)\"")
    public void generateDateAndTime(String format, String varName) {
        configvariable.setStringVariable(configvariable.generateRandomNumber(format), varName);
    }

    @When("I scroll up the screen")
    public void scrollUpScreen() {
        Dimension size = appiumCommands.getDriver().manage().window().getSize();
        if ("iOS".equalsIgnoreCase(BaseSteps.platform)) {
            appiumCommands.scrollElement(5000, (size.width / 2), size.height, 0, 0, -350, -100);
            //appiumCommands.scrollUPElement(350);
        } else if ("Android".equalsIgnoreCase(BaseSteps.platform)) {
            appiumCommands.scrollElement(5000, (size.width / 2), size.height, 0, 0, -650, -100);
            //appiumCommands.scrollUPElement(650);
        }
    }

    @When("I fetch the logs from device and check following regex patterns is present")
    public void iFetchDataLogsFromDevice(DataTable patterns) throws IOException {
        List<String> patternList;
        patternList = patterns.asList(String.class);
        if ("iOS".equalsIgnoreCase(BaseSteps.platform)) {
        } else if ("Android".equalsIgnoreCase(BaseSteps.platform)) {
//            String command = "adb -d logcat " + Configvariable.envPropertyMap.get("pulse.android.app.package") + ":V > " + filePath;
            List<LogEntry> logEntries = appiumCommands.getDriver().manage().logs().get("logcat").filter(Level.ALL);
            File logFile = new File("devicelog/androidLog.txt");
            if (logFile.exists()) {
                logFile.delete();
            }
            logFile.getParentFile().mkdirs();
            PrintWriter log_file_writer = new PrintWriter(logFile);

            for (String pattern : patternList) {
                File patternFile = new File("devicelog/" + pattern + ".txt");
                if (patternFile.exists()) {
                    patternFile.delete();
                }
                patternFile.getParentFile().mkdirs();
                PrintWriter log_file_pattern_writer = new PrintWriter(patternFile);
                for (LogEntry logEntry : logEntries) {
                    log_file_writer.println(logEntry);
                    if (logEntry.getMessage().contains(pattern) && logEntry.getMessage().contains(Configvariable.envPropertyMap.get("pulse.android.app.package"))) {
                        log_file_pattern_writer.println(logEntry);
                    }
                }
                log_file_pattern_writer.flush();
            }

            log_file_writer.flush();

        }
    }*/


}
