package com.onepulse.app.utils;


import com.prod.tap.api.TapMalinatorApi;
import com.prod.tap.config.Configvariable;
import com.prod.tap.filehandling.JsonReader;
import org.apache.log4j.Logger;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

@Component
public class HRMalinatorApi {

    private static final Logger logger = Logger.getLogger(HRMalinatorApi.class);

    @Autowired
    private Configvariable configvariable;

    @Autowired
    private JsonReader jsonReader;

    @Autowired
    private TapMalinatorApi tapMalinatorApi;


    public void getTokenAndCodeFromVerificationEmail(String emailAddress, Map<String, String> variables) {
        tapMalinatorApi.getMessageIdFromMailinatorEmail(emailAddress);
        String responseBody = tapMalinatorApi.readEmailFormat(configvariable.getStringVar("MSG_ID"));
        Map<String, Object> resMap = jsonReader.convertJsonStringToMap(responseBody);
        HashMap<Object, Object> dataObject = (HashMap<Object, Object>) resMap.get("data");
        ArrayList<Object> partsObject = (ArrayList<Object>) dataObject.get("parts");
        HashMap<String, String> bodyObject = (HashMap<String, String>) partsObject.get(0);
        String mailBody = bodyObject.get("body");
        Document doc = Jsoup.parse(mailBody);
        Elements buttons = doc.getElementsByTag("a");
        if (buttons != null && buttons.size() == 1) {
            String verificationLink = buttons.get(0).attributes().get("href");
            logger.info("Found verification link {}" + verificationLink);
//            String[] parts = verificationLink.split("&");
//            String token = parts[1].split("=")[1];
//            String code = parts[2].split("=")[1];
//            configvariable.setStringVariable(token.trim(), variables.get("token"));
//            configvariable.setStringVariable(code.trim(), variables.get("code"));
            configvariable.setStringVariable(verificationLink.trim(), "hr.activation.ui.url");

        } else {
            logger.error("Can't find element with tag 'a'. Probably email format has changed.");
        }

    }

    public String getOTPFromEmail(String mailId) {
        tapMalinatorApi.getMessageIdFromMailinatorEmail(mailId);
        String responseBody = tapMalinatorApi.readEmailFormat(configvariable.getStringVar("MSG_ID"));
        Map<String, Object> resMap = jsonReader.convertJsonStringToMap(responseBody);
        HashMap<Object, Object> dataObject = (HashMap<Object, Object>) resMap.get("data");
        ArrayList<Object> partsObject = (ArrayList<Object>) dataObject.get("parts");
        HashMap<String, String> bodyObject = (HashMap<String, String>) partsObject.get(0);
        String mailBody = bodyObject.get("body");
        String otp = mailBody.split(":")[1].split("\r\n")[0];
        if (!otp.isEmpty()) {
            logger.info("Found otp {}" + otp);
            return otp;
        } else {
            logger.error("Can't find otp. Probably email format has changed.");
        }
        return null;

    }

    public void getJWTTokenFromRegistrationEmail(String emailAddress) {
        tapMalinatorApi.getMessageIdFromMailinatorEmail(emailAddress);
        String responseBody = tapMalinatorApi.readEmailFormat(configvariable.getStringVar("MSG_ID"));
        Map<String, Object> resMap = jsonReader.convertJsonStringToMap(responseBody);
        HashMap<Object, Object> dataObject = (HashMap<Object, Object>) resMap.get("data");
        ArrayList<Object> partsObject = (ArrayList<Object>) dataObject.get("parts");
        HashMap<String, String> bodyObject = (HashMap<String, String>) partsObject.get(0);
        String mailBody = bodyObject.get("body");
        Document doc = Jsoup.parse(mailBody);
        Elements buttons = doc.getElementsByTag("a");
        if (buttons != null && buttons.size() == 1) {
            String registrationLink = buttons.get(0).attributes().get("href");
            logger.info("Found Registration link {}" + registrationLink);
//            String[] parts = registrationLink.split("register/");
//            String token = parts[2];
//            configvariable.setStringVariable(token.trim(), "JWT_HR_TOKEN");
            configvariable.setStringVariable(registrationLink.trim(), "hr.registration.ui.url");
        } else {
            logger.error("Can't find element with tag 'a'. Probably email format has changed.");
        }

    }


    public String getHRStashRegistrationLink(String emailAddress) {
        String stashRegistrationLink = "";
        tapMalinatorApi.getMessageIdFromMailinatorEmail(emailAddress);
        String responseBody = tapMalinatorApi.readEmailFormat(configvariable.getStringVar("MSG_ID"));
        Map<String, Object> resMap = jsonReader.convertJsonStringToMap(responseBody);
        HashMap<Object, Object> dataObject = (HashMap<Object, Object>) resMap.get("data");
        ArrayList<Object> partsObject = (ArrayList<Object>) dataObject.get("parts");
        HashMap<String, String> bodyObject = (HashMap<String, String>) partsObject.get(0);
        String mailBody = bodyObject.get("body");
        Document doc = Jsoup.parse(mailBody);
        Elements buttons = doc.getElementsByTag("span");
        if (buttons != null) {
            stashRegistrationLink = buttons.get(7).ownText();
            logger.info("Found Stash Registration link {}" + stashRegistrationLink);
        } else {
            logger.error("Can't find element with tag 'span'. Probably email format has changed.");
        }

        return stashRegistrationLink;

    }

    public String getHREasilyRegistrationLink(String emailAddress) {
        String hrEasilyRegistrationLink = "";
        tapMalinatorApi.getMessageIdFromMailinatorEmail(emailAddress);
        String responseBody = tapMalinatorApi.readEmailFormat(configvariable.getStringVar("MSG_ID"));
        Map<String, Object> resMap = jsonReader.convertJsonStringToMap(responseBody);
        HashMap<Object, Object> dataObject = (HashMap<Object, Object>) resMap.get("data");
        ArrayList<Object> partsObject = (ArrayList<Object>) dataObject.get("parts");
        HashMap<String, String> bodyObject = (HashMap<String, String>) partsObject.get(0);
        String mailBody = bodyObject.get("body");
        Document doc = Jsoup.parse(mailBody);
        Elements buttons = doc.getElementsByTag("a");
        if (buttons != null) {
            hrEasilyRegistrationLink = buttons.get(10).attributes().get("href");
            logger.info("Found Stash Registration link {}" + hrEasilyRegistrationLink);
        } else {
            logger.error("Can't find element with tag 'span'. Probably email format has changed.");
        }

        return hrEasilyRegistrationLink;

    }
}
