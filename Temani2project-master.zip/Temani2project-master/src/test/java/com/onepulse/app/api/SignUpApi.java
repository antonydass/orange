package com.onepulse.app.api;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.prod.tap.api.RestAPIMethods;
import com.prod.tap.api.WebSocketClient;
import com.prod.tap.config.Configvariable;
import com.prod.tap.exception.TapException;
import com.prod.tap.exception.TapExceptionType;
import com.prod.tap.filehandling.JsonReader;
import okhttp3.*;
import okhttp3.Request.Builder;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.testng.Assert;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.TimeUnit;

@Component
public class SignUpApi {
    private final Logger logger = Logger.getLogger(SignUpApi.class);

    @Autowired
    private RestAPIMethods restAPIMethods;

    @Autowired
    private Configvariable configvariable;

    @Autowired
    private WebSocketClient webSocketClient;

    @Autowired
    private JsonReader jsonReader;


   Response response = null;
    JsonNode jsonNode = null;

    private static final OkHttpClient client = new OkHttpClient.Builder().
            connectTimeout(180, TimeUnit.SECONDS)
            .readTimeout(180, TimeUnit.SECONDS)
            .writeTimeout(180, TimeUnit.SECONDS).build();

    public static Response sendPostRequest(String graphqlPayload, String uri, Map<String, String> headers) {
        RequestBody body = RequestBody.create(MediaType.get("application/json; charset=utf-8"), graphqlPayload);
        Request request = addHeaders(headers).url(uri).post(body).build();
        Response res = null;
        try {
            res = client.newCall(request).execute();
        } catch (IOException var7) {
            var7.printStackTrace();
        }
        return res;
    }

    public static Response sendGetRequest(String graphqlPayload, String uri, Map<String, String> headers) {
        RequestBody body = RequestBody.create(MediaType.get("application/json; charset=utf-8"), graphqlPayload);
        Request request = addHeaders(headers).url(uri).build();
        Response res = null;
        try {
            res = client.newCall(request).execute();
        } catch (IOException var7) {
            var7.printStackTrace();
        }
        return res;
    }

    public static Response sendPutRequest(String graphqlPayload, String uri, Map<String, String> headers) {
        RequestBody body = RequestBody.create(MediaType.get("application/json; charset=utf-8"), graphqlPayload);
        Request request = addHeaders(headers).url(uri).put(body).build();
        Response res = null;
        try {
            res = client.newCall(request).execute();
        } catch (IOException var7) {
            var7.printStackTrace();
        }
        return res;
    }


    public static Builder addHeaders(Map<String, String> sendHeaders) {
        Builder builder = new Builder();
        if (sendHeaders != null) {
            Iterator var2 = sendHeaders.keySet().iterator();

            while(var2.hasNext()) {
                String key = (String)var2.next();
                builder.addHeader(key, (String)sendHeaders.get(key));
            }
        }

        return builder;
    }
    private static String convertInputStreamToString(InputStream inputStream) {
        StringBuilder sb = new StringBuilder();

        try {
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
            Throwable var3 = null;

            try {
                String line;
                try {
                    while((line = bufferedReader.readLine()) != null) {
                        sb.append(line).append("\n");
                    }
                } catch (Throwable var13) {
                    var3 = var13;
                    throw var13;
                }
            } finally {
                if (bufferedReader != null) {
                    if (var3 != null) {
                        try {
                            bufferedReader.close();
                        } catch (Throwable var12) {
                            var3.addSuppressed(var12);
                        }
                    } else {
                        bufferedReader.close();
                    }
                }

            }
        } catch (IOException var15) {
            throw new TapException(TapExceptionType.IO_ERROR, "Unable to convert file to string", new Object[0]);
        }

        return sb.toString();
    }
    public static JsonNode getJsonNodeFromResponse(Response response) {
        JsonNode jsonNode = null;
        String jsonData = "";

        try {
            jsonData = response.body().string();
            jsonNode = (new ObjectMapper()).readTree(jsonData);
            return jsonNode;
        } catch (Exception var4) {
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "Not able to convert response json data into json node [{}]", new Object[]{jsonData});
        }
    }

    public Response sendPostrequestAPiWithHeader(InputStream inputStream, Map sendHeader,String baseUrl, String endPoint) throws Exception {
        Response response = null;
        String readFile = convertInputStreamToString(inputStream);
        String readexpand = this.configvariable.expandValue(readFile);
        logger.info("Sending..."+readexpand);
        String UrlTemp = this.configvariable.expandValue(baseUrl);
        String endPointUrl=this.configvariable.expandValue(endPoint);
        response=sendPostRequest(readexpand, String.format(UrlTemp, endPointUrl), sendHeader);
        logger.info("Recieving..."+response);

        return response;
    }

    public Response sendGetRequestAPiWithHeader(InputStream inputStream, Map sendHeader,String baseUrl, String endPoint) throws Exception {
        Response response = null;
        String readFile = convertInputStreamToString(inputStream);
        String readexpand = this.configvariable.expandValue(readFile);
        logger.info("Sending..."+readexpand);
        String UrlTemp = this.configvariable.expandValue(baseUrl);
        String endPointUrl=this.configvariable.expandValue(endPoint);
        response=sendGetRequest(readexpand, String.format(UrlTemp, endPointUrl), sendHeader);
        logger.info("Recieving..."+response);

        return response;
    }

    public void simpleLoginSignUp(String baseUrl, String endPoint) throws Exception {
        InputStream initialStream = getClass().getResourceAsStream("/testdata/simplelogin/signup.json");
        Map<String, String> headers = new HashMap<>();
        headers.put("accept", "application/json");
        headers.put("content-Type", "application/json");
        restAPIMethods.setHeaderParams(headers);
        response = sendPostrequestAPiWithHeader(initialStream,headers,configvariable.expandValue(baseUrl),configvariable.expandValue(endPoint));
        jsonNode=getJsonNodeFromResponse(response);
        logger.info("Received response" + jsonNode);
        Assert.assertEquals(response.code(), 200, "Api response code is correct");
        logger.info("Successfully Logged in" + jsonNode.get("message").toString());
        }

    public void storeInventory(String baseUrl, String endPoint) throws Exception {
        InputStream initialStream = getClass().getResourceAsStream("/testdata/simplelogin/inventory.json");
        Map<String, String> headers = new HashMap<>();
        headers.put("accept", "application/json");
        headers.put("content-Type", "application/json");
        restAPIMethods.setHeaderParams(headers);
        logger.info("Received response" + configvariable.expandValue(baseUrl)+configvariable.expandValue(endPoint));
        response = sendGetRequestAPiWithHeader(initialStream,headers,configvariable.expandValue(baseUrl),configvariable.expandValue(endPoint));
        jsonNode=getJsonNodeFromResponse(response);
        logger.info("Received response" + jsonNode);
        Assert.assertEquals(response.code(), 200, "Api response code is correct");
        logger.info("Successfully Logged in" + jsonNode.get("sold").toString());
    }
}