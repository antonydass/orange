package com.onepulse.app.locators.ios.mydoc;

import org.openqa.selenium.By;
import org.springframework.stereotype.Component;

@Component
public class IOSMyDocStartOfJourneyLocator {
    public By preDocConsYes = By.xpath("//XCUIElementTypeOther[@name=\'Yes\']");
    public By botWelcomeMsg = By.xpath("//XCUIElementTypeStaticText[contains(@name,'Before we can connect you to a doctor we need to check')]");
    public By botPredefinedDeseases = By.xpath("//XCUIElementTypeStaticText[contains(@name,'Are you experiencing any of the following')]");
    public String botWelcomeSymptoms = "//XCUIElementTypeOther[contains(@name,\"%s\")]";
    public By backToHome = By.xpath("(//XCUIElementTypeOther[@name='home'])[1]/XCUIElementTypeOther[1]");
}

