package com.onepulse.app.stepdefinitions.mobilesteps;//package com.onepulse.app.stepdefinitions.mobilesteps;
//
////import com.pru.corporate.pulse.screens.CPTestBasePage;
////import com.pru.corporate.pulse.utils.CPMalinatorApi;
//import com.onepulse.app.screens.TestBasePage;
//import com.onepulse.app.utils.CPMalinatorApi;
//import com.prudential.tap.config.Configvariable;
//import com.prudential.tap.config.TapBeansLoad;
//import cucumber.api.java.en.Given;
//import org.openqa.selenium.WebDriver;
//
//public class CPEmailReadingSteps {
//
//    private CPMalinatorApi cpMalinatorApi = (CPMalinatorApi) TapBeansLoad.getBean(CPMalinatorApi.class);
//    private CPMailsacApi cpMailsacApi = (CPMailsacApi) TapBeansLoad.getBean(CPMailsacApi.class);
//
//    private Configvariable configvariable = (Configvariable) TapBeansLoad.getBean(Configvariable.class);
//    private TestBasePage cpTestBasePage = (TestBasePage) TapBeansLoad.getBean(TestBasePage.class);
//
//
//    @Given("^I read employee OTP email from \"([^\"]*)\" in Mailinator and get the otp into \"([^\"]*)\" in employee application$")
//    public void readEmpOTPFromMailinator(String mailinatorEmailId, String otpVar) {
////        String emailOTP = cpMalinatorApi.getOTPFromEmail(configvariable.expandValue(mailinatorEmailId));
////        configvariable.setStringVariable(emailOTP, otpVar);
//        cpTestBasePage.waitTime(20);
//        WebDriver driver = cpTestBasePage.getDriver();
//        cpMalinatorApi.navigateToMailinatorUI(configvariable.expandValue(mailinatorEmailId));
//        cpMalinatorApi.clickEmailWithSubject("${EMAIL_SUBJECT}");
//        cpMalinatorApi.readOTPFromMailBody("EMAIL_OTP");
//        cpTestBasePage.setDriver(driver);
//        String emailOTP =configvariable.getStringVar("EMAIL_OTP");
//        configvariable.setStringVariable(emailOTP, otpVar);
//    }
//
//    @Given("^I read employee OTP email from \"([^\"]*)\" in Mailsac and get the otp into \"([^\"]*)\" in employee application$")
//    public void readEmailOTPFromMailsac(String mailsacEmailId, String otpVar) {
//        String emailOTP = cpMailsacApi.getOTPFromEmail(configvariable.expandValue(mailsacEmailId));
//        configvariable.setStringVariable(emailOTP, otpVar);
//    }
//
//}
//
//
