package com.onepulse.app.api;

import com.onepulse.app.config.PulseApiConstUtils;
import com.prod.tap.api.WebSocketClient;
import com.prod.tap.config.Configvariable;
import com.prod.tap.exception.TapException;
import com.prod.tap.exception.TapExceptionType;
import com.prod.tap.filehandling.JsonReader;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public class PulseMyDocApi {
    private static final Logger logger = Logger.getLogger(PulseMyDocApi.class);
    @Autowired
    private Configvariable configvariable;

    @Autowired
    private WebSocketClient webSocketClient;

    @Autowired
    private JsonReader jsonReader;

    public void registerToMyDocUsingPulseAPI() {
        webSocketClient.setWebSocketURL(Configvariable.envPropertyMap.get(PulseApiConstUtils.PULSE_WEBSOCKET_URL));
        String initialRegistrationResponse = webSocketClient.sendRequestAndCheckForResponse(PulseApiConstUtils.REQUEST_FILE_PATH + "PulseMyDocRegister.json");
        logger.info("Receiving: " + initialRegistrationResponse);
        Map<String, Object> responseMapInitial = jsonReader.convertJsonStringToMap(initialRegistrationResponse);
        configvariable.setStringVariable(responseMapInitial.get("workflowId").toString(), "PULSE_MYDOC_WORKFLOW_ID");
        String otpResponse = webSocketClient.sendRequestAndCheckForResponse(PulseApiConstUtils.REQUEST_FILE_PATH + "PulseMyDocRegisterOtp.json");
        logger.info("Receiving: " + otpResponse);
        String partnerResponse = webSocketClient.sendRequestAndCheckForResponse(PulseApiConstUtils.REQUEST_FILE_PATH + "PulseMyDocPartnerRegisterConfirmation.json");
        logger.info("Receiving: " + partnerResponse);
        Map<String, Object> otpMap = jsonReader.convertJsonStringToMap(partnerResponse);
        Map<String, String> otpStatus = (Map<String, String>) otpMap.get("status");

        if (!otpStatus.get("message").contains("Patient is successfully registered")) {
            logger.error("Pulse MyDoc Registration Failed : " + otpStatus.get("message"));
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "Not able to register to pulse MyDoc using API [{}]", otpStatus.get("message"));
        } else {
            logger.info("Pulse MyDoc Registration success : " + otpStatus.get("message"));
        }
        configvariable.setStringVariable(otpStatus.get("message"), "PULSE_MYDOC_REGISTRATION_STATUS");
    }

    public JSONObject getFindDoctorsByCriteria() {
        webSocketClient.setWebSocketURL(Configvariable.envPropertyMap.get(PulseApiConstUtils.PULSE_WEBSOCKET_URL));
        String response = webSocketClient.sendRequestAndCheckForResponse(PulseApiConstUtils.REQUEST_FILE_PATH + "PulseMyDocFindDocByCriteria.json");
        logger.info("Receiving: " + response);
        JSONObject pulseDoctorAvail = jsonReader.convertJsonStringToJsonObject(response);
        if (!String.valueOf(pulseDoctorAvail.getJSONObject("status").get("code")).contains("0")) {
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "Not able to fetch doctors availability using pulse mydoc api");
        } else {
            return pulseDoctorAvail;
        }
    }

    public void initiatePayment() {
        webSocketClient.setWebSocketURL(Configvariable.envPropertyMap.get(PulseApiConstUtils.PULSE_WEBSOCKET_URL));
        String response = webSocketClient.sendRequestAndCheckForResponse(PulseApiConstUtils.REQUEST_FILE_PATH + "PulseMyDocInitiatePayment.json");
        logger.info("Receiving: " + response);
    }

    public void paymmentCheckout() {
        webSocketClient.setWebSocketURL(Configvariable.envPropertyMap.get(PulseApiConstUtils.PULSE_WEBSOCKET_URL));
        String response = webSocketClient.sendRequestAndCheckForResponse(PulseApiConstUtils.REQUEST_FILE_PATH + "PulseMyDocPaymentCheckout.json");
        logger.info("Receiving: " + response);
        JSONObject initiatePayment = jsonReader.convertJsonStringToJsonObject(response);
        String status = String.valueOf(initiatePayment.getJSONObject("status").get("code"));
        if (!"0".equals(status)) {
            logger.error("Not able to do payment checkout for MyDoc using pulse API: " + status);
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "Not able to do payment checkout for MyDoc using pulse API [{}]", status);
        } else {
            configvariable.setStringVariable(initiatePayment.getJSONObject("body").get("orderRef").toString(), "PAYMENT_ORDER");
            logger.info("Pulse MyDoc Payment checkout done");
        }
    }

    public JSONObject getDocumentEmergencyDetails() {
        webSocketClient.setWebSocketURL(Configvariable.envPropertyMap.get(PulseApiConstUtils.PULSE_WEBSOCKET_URL));
        String response = webSocketClient.sendRequestAndCheckForResponse(PulseApiConstUtils.REQUEST_FILE_PATH + "PulseMyDocGetDocumentEmergencyCondition.json");
        logger.info("Receiving: " + response);
        JSONObject pulseEmerCond = jsonReader.convertJsonStringToJsonObject(response);
        if (!String.valueOf(pulseEmerCond.getJSONObject("status").get("code")).contains("0")) {
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "Not able to get emergency condition questions using pulse MyDoc api");
        } else {
            return pulseEmerCond;
        }
    }

    public void updateEmergencyStatus() {
        webSocketClient.setWebSocketURL(Configvariable.envPropertyMap.get(PulseApiConstUtils.PULSE_WEBSOCKET_URL));
        String response = webSocketClient.sendRequestAndCheckForResponse(PulseApiConstUtils.REQUEST_FILE_PATH + "PulseMyDocUpdateDocumentEmergencyStatus.json");
        logger.info("Receiving: " + response);
        JSONObject initiatePayment = jsonReader.convertJsonStringToJsonObject(response);
        String status = String.valueOf(initiatePayment.getJSONObject("status").get("code"));
        if (!"0".equals(status)) {
            logger.error("Not able to update Emergency Condition status for MyDoc using pulse API: " + status);
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "Not able to update Emergency Condition status for MyDoc using pulse API [{}]", status);
        } else {
            logger.info("Pulse update Emergency Condition status done");
        }
    }

    public void sendAppointmentRequest() {
        webSocketClient.setWebSocketURL(Configvariable.envPropertyMap.get(PulseApiConstUtils.PULSE_WEBSOCKET_URL));
        String response = webSocketClient.sendRequestAndCheckForResponse(PulseApiConstUtils.REQUEST_FILE_PATH + "PulseMyDocSubmitRequestToDoctor.json");
        logger.info("Receiving: " + response);
        JSONObject initiatePayment = jsonReader.convertJsonStringToJsonObject(response);
        String status = String.valueOf(initiatePayment.getJSONObject("status").get("code"));
        if (!"0".equals(status)) {
            logger.error("Not able to send appointment request to MyDoc using pulse API: " + status);
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "Not able to send appointment request to MyDoc using pulse API [{}]", status);
        } else {
            logger.info("Pulse able to send appointment request to MyDoc");
        }
    }

    public void createAppointment() {
        webSocketClient.setWebSocketURL(Configvariable.envPropertyMap.get(PulseApiConstUtils.PULSE_WEBSOCKET_URL));
        String response = webSocketClient.sendRequestAndCheckForResponse(PulseApiConstUtils.REQUEST_FILE_PATH + "PulseMyDocCreateDoctorAppointment.json");
        logger.info("Receiving: " + response);
        JSONObject initiatePayment = jsonReader.convertJsonStringToJsonObject(response);
        String status = String.valueOf(initiatePayment.getJSONObject("status").get("code"));
        if (!"0".equals(status)) {
            logger.error("Not able to send appointment request to MyDoc using pulse API: " + status);
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "Not able to send appointment request to MyDoc using pulse API [{}]", status);
        } else {
            configvariable.setStringVariable(initiatePayment.getJSONObject("body").get("id").toString(), "PULSE_APPOINTMENT_ID");
            logger.info("Pulse able to send appointment request to MyDoc");
        }
    }

    public void preConsultationQuestions() {
        webSocketClient.setWebSocketURL(Configvariable.envPropertyMap.get(PulseApiConstUtils.PULSE_WEBSOCKET_URL));
        String response = webSocketClient.sendRequestAndCheckForResponse(PulseApiConstUtils.REQUEST_FILE_PATH + "PulseMyDocUpdateDocPreConsultQuestion.json");
        logger.info("Receiving: " + response);
        JSONObject preConsultation = jsonReader.convertJsonStringToJsonObject(response);
        String status = String.valueOf(preConsultation.getJSONObject("status").get("code"));
        if (!"0".equals(status)) {
            logger.error("Not able to start pre consultation Questions and Answers: " + status);
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "Not able to start pre consultation Questions and Answers to MyDoc using pulse API [{}]", status);
        } else {
            configvariable.setStringVariable(preConsultation.getJSONObject("body").get("doctorId").toString(), "PULSE_DOCTOR_ID");
            configvariable.setStringVariable(preConsultation.getJSONObject("body").get("episodeId").toString(), "PULSE_EPISODE_ID");
            logger.info("Pulse able to start pre-consultation Questions and Answers to MyDoc");
        }
    }

    public JSONObject getConversationMessage() {
        webSocketClient.setWebSocketURL(Configvariable.envPropertyMap.get(PulseApiConstUtils.PULSE_WEBSOCKET_URL));
        String response = webSocketClient.sendRequestAndCheckForResponse(PulseApiConstUtils.REQUEST_FILE_PATH + "PulseMyDocGetConverMessage.json");
        logger.info("Receiving: " + response);
        JSONObject pulseGetConverseMessage = jsonReader.convertJsonStringToJsonObject(response);
        if (!String.valueOf(pulseGetConverseMessage.getJSONObject("status").get("code")).contains("0")) {
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "Not able to get conversation message using pulse mydoc api");
        } else {
            configvariable.setStringVariable(pulseGetConverseMessage.getJSONArray("body").getJSONObject(0).get("sender").toString(), "PULSE_DOCTOR_NAME");
            return pulseGetConverseMessage;
        }
    }

    public JSONObject findDocumentByCriteria() {
        webSocketClient.setWebSocketURL(Configvariable.envPropertyMap.get(PulseApiConstUtils.PULSE_WEBSOCKET_URL));
        String response = webSocketClient.sendRequestAndCheckForResponse(PulseApiConstUtils.REQUEST_FILE_PATH + "PulseMyDocFindDocsByCriteria.json");
        logger.info("Receiving: " + response);
        JSONObject pulseDoctorAvail = jsonReader.convertJsonStringToJsonObject(response);
        if (!String.valueOf(pulseDoctorAvail.getJSONObject("status").get("code")).contains("0")) {
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "Not able to find documents by criteria using pulse mydoc api");
        } else {
            return pulseDoctorAvail;
        }
    }

    public void loginAsPartner() {
        webSocketClient.setWebSocketURL(Configvariable.envPropertyMap.get(PulseApiConstUtils.PULSE_WEBSOCKET_URL));
        String response = webSocketClient.sendRequestAndCheckForResponse(PulseApiConstUtils.REQUEST_FILE_PATH + "PulseMyDocLoginAsPartner.json");
        logger.info("Receiving: " + response);
        JSONObject preConsultation = jsonReader.convertJsonStringToJsonObject(response);
        String status = String.valueOf(preConsultation.getJSONObject("status").get("code"));
        if (!"0".equals(status)) {
            logger.error("Not able to login to pulse as MyDoc Partner " + status);
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "Not able to login to pulse as MyDoc Partner using pulse API [{}]", status);
        } else {
            configvariable.setStringVariable(preConsultation.get("access_token").toString(), "PULSE_MYDOC_ACCESS_TOKEN");
            logger.info("Able to login to Pulse as MyDoc Partner");
        }
    }

    public void sendNotificationAsPartner() {
        webSocketClient.setWebSocketURL(Configvariable.envPropertyMap.get(PulseApiConstUtils.PULSE_WEBSOCKET_URL));
        String response = webSocketClient.sendRequestAndCheckForResponse(PulseApiConstUtils.REQUEST_FILE_PATH + "PulseMySendMessageNotification.json");
        logger.info("Receiving: " + response);
        JSONObject preConsultation = jsonReader.convertJsonStringToJsonObject(response);
        String status = String.valueOf(preConsultation.getJSONObject("status").get("code"));
        if (!"0".equals(status)) {
            logger.error("Not able to send notification to pulse as MyDoc Partner " + status);
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "Not able to send notification to pulse as MyDoc Partner using pulse API [{}]", status);
        } else {
            logger.info("Able to send notification to Pulse as MyDoc Partner");

        }
    }
}