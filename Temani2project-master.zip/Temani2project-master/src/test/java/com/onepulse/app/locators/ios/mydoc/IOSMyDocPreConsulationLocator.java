package com.onepulse.app.locators.ios.mydoc;

import org.openqa.selenium.By;
import org.springframework.stereotype.Component;

@Component
public class IOSMyDocPreConsulationLocator {

    public By preConsulationPage = By.xpath("(//XCUIElementTypeOther[contains(@name,'What concerns or questions do you have for the doctor?')])[4]");
    public By textBox = By.className("XCUIElementTypeTextField");
    public By sendButton = By.xpath("//XCUIElementTypeTextField/following::XCUIElementTypeOther[1]");
    public By imageButton = By.xpath("//XCUIElementTypeTextField/preceding::XCUIElementTypeOther[1]");
    public By noButton = By.xpath("//XCUIElementTypeOther[@name='No']");
    public By yesButton = By.xpath("//XCUIElementTypeOther[@name='Yes']");
    public By submitBtn = By.xpath("(//XCUIElementTypeOther[@name='Submit'])[2]");
    public By docConfimationText = By.xpath("//XCUIElementTypeScrollView/XCUIElementTypeOther[contains(@name,'We will notify you when your doctor confirms the request')]");
    public By backButton = By.xpath("(//XCUIElementTypeOther[@name='home'])[1]/XCUIElementTypeOther[1]");
    public By homeButton = By.xpath("(//XCUIElementTypeOther[@name='home'])[2]");
    public By closeImageButton = By.xpath("(//XCUIElementTypeOther[@name='home'])[2]/following::XCUIElementTypeOther[4]");
}
