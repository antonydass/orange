package com.onepulse.app.screens;

import com.onepulse.app.locators.ios.IOSManageProfileLocator;
//import com.product.genericcomponents.appium.AppiumCommands;
//import com.product.genericcomponents.config.Configvariable;
import com.prod.tap.appium.AppiumCommands;
import com.prod.tap.config.Configvariable;
import org.openqa.selenium.By;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import java.util.List;
import java.util.Map;

@Component
public class PulseLoginScreen {

    @Autowired
    private IOSManageProfileLocator iosManageProfileLocator;

    @Autowired
    private Configvariable configVariable;

    @Autowired
    private AppiumCommands appiumCommands;

    @Autowired
    private Configvariable configvariable;

    @Autowired
    private TestBasePage testBasePage;


    private SoftAssert softAssert = new SoftAssert();
    public String emailTextFields = "${email.text.fields}";
    public String emailTextField = "${email.text.field}";
    public String passwordTextField = "${password.text.field}";
    public String signInButton = "${login.button}";
    public String otpScreenLocator = "otpScreen.reg.text.label";
    public String otpTextField = "otp.reg.text.field";
    public String invalidOTPLabel = "${invalid.otp.message.label}";
    public String forgotPassword = "${forgot.password.link}";
    public String sendButton = "${send.button}";
    public String otpSendButton = "${otp.popup.send.button}";
    public String home = "${homepage.account.button}";
    public String healthpageText = "health.label";
    public String healthCheckLink = "${health.check.image}";
    public String crossButtonOnHealthCheck = "close.health.check.button";
    public String skipButtonOnLandingPage = "skip.label";
    public String languageLabel = "language.label";
    public String pruServicesButton = "pru.services.button";
    public String covid19Text = "text.field.label";
    public String errorMessages = "${text.field.label}";
    public String continueWithEmailButton = "${home.continue.email.button}";
    public String signInLink = "${register.home.sign.link}";
    public String homepageText = "${welcome.label}";
    public String genderText = "${gender.text.box}";
    public String DobText = "dob.text.box";
    public String firstNameText = "${firstName.text.field}";
    public String lastNameText = "${lastName.text.field}";
    public String phoneNumberText = "${phoneNumber.edit.profile.text.field}";
    public String addressText = "${address.edit.profile.text.field}";
    public String postalCodeText = "${postalCode.edit.profile.text.field}";
    public String inValidEmailMsg = "${invalid.email.message.label}";
    public String otpTextFields = "${verification.text.field}";
    public String resetPasswordCode = "${reset.pass.code.text.field}";
    public String emailField = "${forgot.email.text.field}";
    public String homescreen = "newhome.button";
    // private String pixelProfileImage = "${pixel.profile.image}";
    public String resetpasswordText = "${reset.pass.text.label}";
    public String signOutButton = "${sign.out.button}";
    public String meButton = "${home.account.image}";
    public String homeButton = "${home.button}";
    public String healthButton = "${health.button}";
    public String editProfileButton = "${edit.profile.link}";
    public String carouselHeader = "${carousel.label}";
    public String locationaAllowButton = "launch.camera.allow";
    public String skipButton = "${login.page.skip}";
    public String secondpassword = "${secondforgot.email.text.field}";
    public String SecondInvalidmessage = "${Againinvalid.email.message.labels}";
    public String Invalidalertmobilemessage = "${Invalid.phone.alerttext}";
    public String InvalidGenderTextmessage = "${Gender.AlertText}";
    public String InvalidNRICNumber = "${NRIC.text}";
    public String InvalidEamilid = "${Invalid.EMailid}";
    public String Signins = "${Signins}";
    public String continuewithgoogle = "${continuewithgoogle.text}";
    public String Emailtexts = "${Eamilid.text}";
    public String NextGmail = "${GmailNext.text}";
    public String passwordNext = "${Passwordnext.text}";
    public String passwordNexts = "${passwordNexts.text}";
    public String Agreebuttontext = "${Acceptnext.text}";
    public String Acceptbuttontext = "${Acceptfile.text}";
    public String Morebutton = "${Morebutton.text}";
    public String chooseAccount = "${ChooseAccount.text}";
    public String facebookAccount = "${Facebook.button}";
    public String Facebookusername = "${Facebook.text}";
    public String Facebookpassword = "${Facebookpassword.text}";
    public String Facebooklogin = "${FacebookLogin.button}";
    public String Facebookproceed = "${Facebook.proceed.text}";
    public String nonOfAboveLink = "${non.of.above.link}";
    public String pulseSkipButton = "${pulse.notify.you.skip}";
    public String shareWhatsappIcon = "${homepage.share.whatsapp.button}";
    public String shareContactsIcon = "${homepage.share.contacts.icon}";
    public String contactsAllowButton = "${profile.camera.allow}";
    private String locationAlertMsg = "${location.permission.alert.message}";
    private String contactsAccessAllowButton = "${contacts.permissions.alert.allow.button}";
    public String contactSkipButton = "${reg.button.skip}";
    public String shareWeChatIcon = "${homepage.share.wechat.icon}";
    public String shareLineIcon = "${homepage.share.line.icon}";
    public String shareViberIcon = "${homepage.share.viber.icon}";
    public String carouselHeaderTxt = "${text}";
    public String resetConfirmationMessage = "${text}";
    public String buttonLocator = "${label.button}";
    public String Popuptexts = "${pulsepopup.text}";
    public String popupstart = "${pulsepopupstart.text}";
    public String rewardsTabs = "${rewards.Tab.text}";
    public String continueGmail = "${ContinueGmail.icon}";
    public String ContinuebuttonsGmail = "${continuebuttonGmail.icon}";
    public String pulseSGGmailName = "${PulseGmail.icon}";
    public String SigninsIos = "${Signins.icon}";
    public String forgotPasswordIos = "${forgot.password.link}";
    public String emailFieldIos = "${forgot.email.text.field}";
    public String enteremailFields = "${enteremailid.text}";
    public String clearFacebookusername = "${Facebookclearname.text}";
    public String Facebookproceeds = "${Facebook.continue.text}";
    public String AddAccount = "${AddAccount.icon}";
    public String homepageShareIcon = "${home.page.share.icon}";
    public String MobileNumber = "${reg.mobileNumber.text}";
    public String MobileNumberclick = "${Mobileclick.text}";
    public String Dateofbirths = "${Date.of.birth}";
    public String continuesbutton = "${continue.buttons}";
    public String closecontinue = "${continueclose.button}";
    public String closecontinues = "${continueclose.buttons}";
    public String closecontinuess = "${continueclose.buttonss}";
    public String continuetext = "${clickcontinue.text}";
    public String maleImages = "${male.image}";
    public String maleImagess = "${male.images}";
    public String wellnessPackage = "${signup.wellness.package}";
    public String userHeight = "${wellness.your.height}";
    public String userWeight = "${wellness.your.weight}";
    private String calculateBMI = "${wellness.calculate.bmi}";
    private String lightExercise = "${wellness.lightExercise}";
    private String foodProducts = "${wellness.foodProducts}";
    private String foodAllergies = "${wellness.foodallergies.text}";
    private String welcomeToPulse = "${welcometoPulse.text}";
    private String fitbitSubscriptionOffer = "${fitSubscription.exclusiveOffer}";
    private String exclusiveOfferCloseIcon = "${exclusiveOffer.close.icon}";
    private String wellnessTrackingActivity = "${wellness.tracking.activity}";
    public String wellnessScreenTitle = "${signup.wellness.plan.screen.title}";
    public String datefile = "${Datepicler.file}";
    public String Datefields = "${Datepicler.files}";
    public String doneButton = "${Done.button}";
    public String signupButton = "${login.singup.button}";
    public String joinThisChallengeLink = "${join.ThisChallenge.Link}";
    public String carouselTxt = "${carousel.text}";
    public String emailText = "${email.reg.text.field}";
    public String passwordText = "${password.reg.text.field}";
    public String homeAccountImage = "${home.account.image}";
    public String signout = "${Signout.button}";
    public String myChallenges = "${challenges.tile}";
    public String myChallengesSG = "${challenges.tile.sg}";
    public String topPicksText = "${topPicksText}";
    public String googlecontine = "${googlecontinue.text}";
    public String EnterEmailname = "${EnterEmailName.text}";
    public String EnterNext = "${EnterNext.icons}";
    public String EnterPassword = "${Enterpassword.icons}";
    public String EnterPasswords = "${Enterpassword.icons}";
    public String AnotherAccount = "${AnotherAccount.icons}";
    public String allowButton = "${alert.Allow.Button}";
    public String Facebookcontinue = "${Facebookcontinue.button}";

    //### iOS Specific #########
    public String allowButtoniOS = "";
    //##########################################
    public String buttonLogin = "${login.button}";
    public String staticText = "${page.label.text}";
    public String menuLocator = "${menu.icon}";
    public String languageLocator = "${Language}";
    // public String rewardsTabs = "${rewards.Tab.text}";
    public String Accountbutton = "${Home.Accountbutton}";
    public String shareMessengerIcon = "${homepage.share.messenger.icon}";
    public String whatsappBackButton = "${whatsapp.back.button}";
    public String notNowPopUpText = "${not.now.pop.up}";
    public String continuenewsbutton = "${continuebutton.text}";
    public String emailname = "${emailname.text}";
    public String continuelogin = "${continuelogin.text}";
    private String enableTouchId = "${enrollTouchID.button}";


    public void enterLoginCredentials(String platform, String userName, String password) {
        testBasePage.waitTime(14);
        testBasePage.isElementDisplayed(configVariable.expandValue(emailTextField));
        if(platform.equalsIgnoreCase("ios"))
        testBasePage.clearTextField(configVariable.expandValue(emailTextField));
        testBasePage.setTextWithTab(configVariable.expandValue(emailTextField), userName);
        // appiumCommands.clearAndEnterText(configVariable.expandValue(emailTextField), userName);
        if (platform.equalsIgnoreCase("iOS")) {
            appiumCommands.hideIOSKeyBoard();
            appiumCommands.isKeyBoardKeyPresent("return");
        }

        testBasePage.setTextWithTab(configVariable.expandValue(passwordTextField), password);
        if (platform.equalsIgnoreCase("iOS")) {
            appiumCommands.hideIOSKeyBoard();
            appiumCommands.isKeyBoardKeyPresent("Return");
        } else {
            appiumCommands.hideKeyboard();

        }
    }


    public void clickSignIn(String platform) {
        String otp = null;
        if (platform.equalsIgnoreCase("android")) {
            testBasePage.clickButton(configVariable.expandValue(signInButton));

        } else if (platform.equalsIgnoreCase("iOS")) {
            testBasePage.clickButton(configVariable.expandValue(signInButton));
        }


    }

    public String invalidOTPVerification(String platform) {
        String invalidOTP = null;
        if (platform.equalsIgnoreCase("android")) {
            invalidOTP = testBasePage.getElementText(configVariable.expandValue(invalidOTPLabel));
            return invalidOTP;

        } else if (platform.equalsIgnoreCase("iOS")) {
            invalidOTP = testBasePage.getElementText(configVariable.expandValue(invalidOTPLabel));
            return invalidOTP;
        }
        return invalidOTP;
    }

    public void clickForgotPassword() {
        testBasePage.clickButton(configVariable.expandValue(forgotPassword));
    }

    public void clickSendButton() {
        String sendLabel = TestBasePage.platform.equalsIgnoreCase("android") ? sendButton : otpSendButton;
        testBasePage.clickButton(configVariable.expandValue(sendLabel));
    }

    public void clickOnHealthCheckCrossButton(String platform) {
        if (platform.equalsIgnoreCase("android")) {
            testBasePage.clickButton(configVariable.getStringVar(crossButtonOnHealthCheck));
            testBasePage.isElementDisplayed(configVariable.getStringVar(crossButtonOnHealthCheck));

        } else if (platform.equalsIgnoreCase("iOS")) {
            testBasePage.clickButtonUsingJs(configVariable.getStringVar(crossButtonOnHealthCheck));
            testBasePage.isElementDisplayed(crossButtonOnHealthCheck);
        }

    }

    public void clickNewsCarouselLink(String platform, String carousel) {
        if (platform.equalsIgnoreCase("android")) {
            String locator = configvariable.getFormattedString(carouselHeaderTxt, carousel);
            testBasePage.isElementDisplayed(configVariable.getStringVar(locator));
            testBasePage.clickButton(configVariable.getStringVar(locator));
            testBasePage.isElementDisplayed(configvariable.getStringVar(healthCheckLink));

        }

    }

    public void enterEmailForgotPassword(String platform, String Email) {
        if (platform.equalsIgnoreCase("android")) {
            testBasePage.waitTime(2);
            if (testBasePage.isElementDisplayed(configVariable.expandValue(emailField))) {
                testBasePage.setTextWithTab(configVariable.expandValue(emailField), Email);
            } else {
                appiumCommands.cleartext(By.xpath(configVariable.expandValue(secondpassword)));
                testBasePage.setTextWithTab(configVariable.expandValue(emailField), Email);
            }
        } else if (platform.equalsIgnoreCase("iOS")) {
            if (testBasePage.isElementDisplayed(configVariable.expandValue(emailFieldIos))) {
                testBasePage.clickButton(configVariable.expandValue(emailFieldIos));
                testBasePage.setTextWithTab(configVariable.expandValue(enteremailFields), Email);
                appiumCommands.hideIOSKeyBoard();
                appiumCommands.isKeyBoardKeyPresent("Return");
            } else {
                appiumCommands.cleartext(By.xpath(configVariable.expandValue(secondpassword)));
                testBasePage.setTextWithTab(configVariable.expandValue(enteremailFields), Email);
                appiumCommands.hideIOSKeyBoard();
                appiumCommands.isKeyBoardKeyPresent("Return");
            }
        }

    }

    public boolean verifyInvalidEmailMsg(String platform, String invalidMsg) {
        boolean inValidMsgPresent = false;
        String errorLocator;
        if (platform.equalsIgnoreCase("android")) {
            errorLocator = configVariable.getFormattedString(configVariable.expandValue(inValidEmailMsg), invalidMsg);
            inValidMsgPresent = testBasePage.isElementDisplayed(errorLocator);

        } else if (platform.equalsIgnoreCase("iOS")) {
            errorLocator = configVariable.getFormattedString(configVariable.expandValue(inValidEmailMsg), invalidMsg);
            inValidMsgPresent = testBasePage.isElementDisplayed(errorLocator);
        }
        return inValidMsgPresent;
    }

    public void enterPasswordResetOTP(String otp) {
        testBasePage.setTextWithOutClear(configVariable.expandValue(resetPasswordCode), otp);
    }


    public String getWelcomePageText(String platform) {
        String welcometext = "";
        if (platform.equalsIgnoreCase("android")) {
            testBasePage.isElementDisplayed(configVariable.getStringVar(homepageText));
            welcometext = testBasePage.getElementText(configVariable.getStringVar(homepageText));

        } else if (platform.equalsIgnoreCase("iOS")) {
            welcometext = testBasePage.getElementText(configVariable.getStringVar(homepageText));
        }
        return welcometext;
    }

    public String getHealthPageText(String platform) {
        String healthtext = "";
        if (platform.equalsIgnoreCase("android")) {
            healthtext = testBasePage.getElementText(configVariable.getStringVar(homepageText));

        } else if (platform.equalsIgnoreCase("iOS")) {
            healthtext = testBasePage.getElementText(configVariable.getStringVar(homepageText));
        }
        return healthtext;
    }


    public String getResetPasswordText(String platform) {
        String resetPassword = "";
        if (platform.equalsIgnoreCase("android")) {
            resetPassword = testBasePage.getElementText(configVariable.expandValue(resetpasswordText));

        } else if (platform.equalsIgnoreCase("iOS")) {
            resetPassword = testBasePage.getElementAttributeValue(configVariable.expandValue(resetpasswordText), "value");
        }
        return resetPassword;
    }

    public String getResetConfirmationText(String platform) {
        String resetPassword = "";
        if (platform.equalsIgnoreCase("android")) {
            resetPassword = testBasePage.getElementText(configVariable.getStringVar(resetConfirmationMessage));

        } else if (platform.equalsIgnoreCase("iOS")) {
            resetPassword = testBasePage.getElementText(configVariable.getStringVar(resetConfirmationMessage));
        }
        return resetPassword;
    }

    public void clickSignOut() {
        testBasePage.waitTime(3);
        appiumCommands.waitForClickable(By.xpath(configVariable.expandValue(homeButton)));
        testBasePage.clickButton(configVariable.expandValue(homeButton));
        int iCount = 0;
        while (!testBasePage.isElementDisplayed(configVariable.expandValue(meButton)) && iCount < 5) {
            appiumCommands.waitForTime(2000);
            iCount++;
        }

        if (testBasePage.isElementDisplayed(configVariable.expandValue(meButton))) {
            testBasePage.clickButton(configVariable.expandValue(meButton));
            testBasePage.waitTime(3);
        }
        appiumCommands.swipe(AppiumCommands.DIRECTION.DOWN, 6000);
        testBasePage.clickButton(configVariable.expandValue(signOutButton));
    }

    public Boolean navBarPresence(String platform) {
        Boolean flag = false;
        By homePageXpath = By.xpath(configVariable.getStringVar(homepageText));
        By homeButtonXpath = By.xpath(configVariable.getStringVar(homeButton));
        By meButtonXpath = By.xpath(configVariable.getStringVar(meButton));
        By healthButtonXpath = By.xpath(configVariable.getStringVar(healthButton));
        By editProfileXpath = By.xpath(configVariable.getStringVar(editProfileButton));
        if (platform.equalsIgnoreCase("iOS")) {
            if (appiumCommands.waitForVisibility(homePageXpath)) {
                flag = (
                        appiumCommands.waitForClickable(homeButtonXpath)
                                && appiumCommands.waitForClickable(healthButtonXpath)
                                && appiumCommands.waitForClickable(meButtonXpath)
                );
            }

            appiumCommands.waitForVisibility(meButtonXpath);
            testBasePage.clickButtonUsingJs(configVariable.getStringVar(meButton));

            if (appiumCommands.waitForVisibility(editProfileXpath)) {
                flag = (
                        appiumCommands.waitForClickable(homeButtonXpath)
                                && appiumCommands.waitForClickable(healthButtonXpath)
                                && appiumCommands.waitForClickable(meButtonXpath)
                );
            }
        } else if (platform.equalsIgnoreCase("ANDROID")) {

            if (appiumCommands.waitForVisibility(homePageXpath)) {
                flag = (
                        appiumCommands.waitForClickable(homeButtonXpath)
                                && appiumCommands.waitForClickable(healthButtonXpath)
                                && appiumCommands.waitForClickable(meButtonXpath)
                );
            }

            appiumCommands.waitForVisibility(meButtonXpath);
            testBasePage.clickButton(configVariable.getStringVar(meButton));

            if (appiumCommands.waitForVisibility(editProfileXpath)) {
                flag = (
                        appiumCommands.waitForClickable(homeButtonXpath)
                                && appiumCommands.waitForClickable(healthButtonXpath)
                                && appiumCommands.waitForClickable(meButtonXpath)
                );
            }
        }

        return flag;
    }

    public void verifyChallengesTxt(String platform, String carouselHeaderTxt) {
        String locator = null;
        String elementVisible = null;
        if ("Android".equalsIgnoreCase(platform)) {
            locator = configvariable.getFormattedString(configvariable.getStringVar(carouselHeader), carouselHeaderTxt);
            for (int i = 0; i < 5; i++) {
                // elementVisible = appiumCommands.findElement(locator).getAttribute("visible").toString();
                if (!testBasePage.isElementDisplayed(configVariable.getStringVar(locator))) {
                    appiumCommands.swipe(AppiumCommands.DIRECTION.DOWN, 6000);
                } else {
                    Assert.assertTrue(testBasePage.isElementDisplayed(configVariable.getStringVar(locator)));
                    break;
                }
            }
        } else if ("iOS".equalsIgnoreCase(platform) && (carouselHeaderTxt.equalsIgnoreCase("Challenges") || carouselHeaderTxt.equalsIgnoreCase("News & Updates"))) {
            By iOSLocator = By.xpath(configvariable.getFormattedString(carouselHeader, carouselHeaderTxt));
            for (int i = 0; i < 5; i++) {
                elementVisible = appiumCommands.findElement(iOSLocator).getAttribute("visible").toString();
                if (!appiumCommands.isElementDisplayed(iOSLocator) || elementVisible.equalsIgnoreCase("false")) {
                    appiumCommands.swipe(AppiumCommands.DIRECTION.DOWN, 6000);
                } else {
                    Assert.assertTrue(appiumCommands.isElementDisplayed(iOSLocator));
                    break;
                }
            }
        }
    }

    public void clickOnJoinChanllengeButton(String platform, String btnTxt) {
        String locator = null;
        if (platform.equalsIgnoreCase("ANDROID")) {
            locator = configvariable.getFormattedString(carouselHeaderTxt, btnTxt);
            testBasePage.clickButton(locator);
        } else if (platform.equalsIgnoreCase("iOS")) {
            locator = configVariable.expandValue(joinThisChallengeLink);
            testBasePage.clickElementByCoordinateForBothXY(locator, 0, 230);
        }
    }

    public void closeApp() {
        appiumCommands.closeApp();
    }

    public void verifyTitlesOnNews(String platform, Map<String, String> newsTitlesDetail) {
        By locator = null;
        int challengimgX = 0;
        int challengimgY = 0;
        if ("Android".equalsIgnoreCase(platform)) {
            appiumCommands.swipe(AppiumCommands.DIRECTION.DOWN, 3000);
            locator = By.xpath(configvariable.getFormattedString(configvariable.expandValue(carouselTxt), newsTitlesDetail.get("existing_customer")));
            appiumCommands.isElementDisplayed(locator);
            challengimgX = appiumCommands.findElement(locator).getLocation().getX();
            challengimgY = appiumCommands.findElement(locator).getLocation().getY();
            appiumCommands.scrollElement(6000, challengimgX, challengimgY, 850, 0, 0, 0);

            locator = By.xpath(configvariable.getFormattedString(configvariable.expandValue(carouselTxt), newsTitlesDetail.get("rewards")));
            appiumCommands.isElementDisplayed(locator);
            challengimgX = appiumCommands.findElement(locator).getLocation().getX();
            challengimgY = appiumCommands.findElement(locator).getLocation().getY();
            appiumCommands.scrollElement(6000, challengimgX, challengimgY, 850, 0, 0, 0);

            locator = By.xpath(configvariable.getFormattedString(configvariable.expandValue(carouselTxt), newsTitlesDetail.get("Health_assesment")));
            appiumCommands.isElementDisplayed(locator);

        } else if ("ios".equalsIgnoreCase(platform)) {
            appiumCommands.swipe(AppiumCommands.DIRECTION.DOWN, 6000);
            locator = By.xpath(configvariable.getFormattedString(configvariable.expandValue(carouselTxt), newsTitlesDetail.get("existing_customer")));
            appiumCommands.isElementDisplayed(locator);
            challengimgX = appiumCommands.findElement(locator).getLocation().getX();
            challengimgY = appiumCommands.findElement(locator).getLocation().getY();
            appiumCommands.scrollElement(6000, challengimgX, challengimgY, 850, 0, 0, 0);
            locator = By.xpath(configvariable.getFormattedString(configvariable.expandValue(carouselTxt), newsTitlesDetail.get("rewards")));
            appiumCommands.isElementDisplayed(locator);
            challengimgX = appiumCommands.findElement(locator).getLocation().getX();
            challengimgY = appiumCommands.findElement(locator).getLocation().getY();
            appiumCommands.scrollElement(6000, challengimgX, challengimgY, 850, 0, 0, 0);
            locator = By.xpath(configvariable.getFormattedString(configvariable.expandValue(carouselTxt), newsTitlesDetail.get("Health_assesment")));
            appiumCommands.isElementDisplayed(locator);
        }
    }

    public boolean isJoinThisChallengeButtonPresent(String platform, String btnTxt) {
        String locator = null;
        boolean locatorPresent = false;
        if (platform.equalsIgnoreCase("Android")) {
            locator = configvariable.getFormattedString(configvariable.expandValue(carouselHeader), btnTxt);
            locatorPresent = testBasePage.isElementDisplayed(locator);
        } else if (platform.equalsIgnoreCase("iOS")) {
            locator = configvariable.expandValue(joinThisChallengeLink);
            locatorPresent = testBasePage.isElementDisplayed(locator);
        }
        return locatorPresent;
    }

  /*  public void clickSkipButtonOnLandingPage(String platform) {
        if (platform.equalsIgnoreCase("android")) {
            appiumCommands.findElement(androidLoginLocator.getSkipButtonOnLandingPage()).click();
        } else if (platform.equalsIgnoreCase("iOS")) {
            appiumCommands.findElement(iosLoginLocator.crossButtonOnHealthCheck).click();
        }

    }

    public void selectLanguageFromIDApp(String platform) {
        if (platform.equalsIgnoreCase("android")) {
            appiumCommands.findElement(androidLoginLocator.getLanguageLabel()).click();
        } else if (platform.equalsIgnoreCase("iOS")) {
            appiumCommands.findElement(iosLoginLocator.crossButtonOnHealthCheck).click();
        }

    }*/

  /*  public boolean isPruServicesButtonPresent(String platform) {
        boolean isPresent = false;
        if (platform.equalsIgnoreCase("android")) {
            isPresent = appiumCommands.isElementPresent(androidLoginLocator.getPruServicesButton());
        } else if (platform.equalsIgnoreCase("iOS")) {
            isPresent = appiumCommands.isElementPresent(iosLoginLocator.crossButtonOnHealthCheck);
        }
        return isPresent;

    }*/

    public void handleSignInButton(String platform) {
        testBasePage.clickButton(configvariable.expandValue(signInButton));
    }


    //covid19
    public void verifyChallengesTxtIsNotDisplayed(String platform, String carouselHeaderTxt) {
        By locator = null;
        String elementVisible = null;
        if ("Android".equalsIgnoreCase(platform)) {
            locator = By.xpath(configvariable.getFormattedString(configvariable.expandValue(carouselHeader), carouselHeaderTxt));
            Assert.assertFalse(appiumCommands.isElementDisplayed(locator));
        } else if ("iOS".equalsIgnoreCase(platform)) {
            locator = By.xpath(configvariable.getFormattedString(carouselHeader, carouselHeaderTxt));
            Assert.assertFalse(appiumCommands.isElementDisplayed(locator));
        }
    }

    public void verifyCovid19TextIsDisplayed(String platform, String text) {
        By locator = null;
        if ("Android".equalsIgnoreCase(platform)) {
            locator = By.xpath(configvariable.getFormattedString(configvariable.expandValue(covid19Text), text));
            Assert.assertTrue(appiumCommands.isElementDisplayed(locator));
        } else if ("iOS".equalsIgnoreCase(platform)) {
            locator = By.xpath(configvariable.getFormattedString(iosManageProfileLocator.screenText, text));
            Assert.assertTrue(appiumCommands.isElementDisplayed(locator));
        }
    }

    public void verifyInvalidPasswordMessage(String platform, List<String> passwordDetails) {
        String[] parts;
        String error_locator;
        if (platform.equalsIgnoreCase("iOS")) {
            for (int i = 0; i < passwordDetails.size(); i++) {
                parts = passwordDetails.get(i).split("##");
                error_locator = configvariable.getFormattedString(configVariable.expandValue(errorMessages), configvariable.expandValue(parts[1]));
                testBasePage.setTextWithTab(configVariable.expandValue(passwordTextField), parts[0]);
                appiumCommands.isKeyBoardKeyPresent("Return");
                testBasePage.clickButton(configvariable.expandValue(signInButton));
                Assert.assertTrue(testBasePage.isElementDisplayed(error_locator), configvariable.expandValue(parts[1]));
                appiumCommands.isKeyBoardKeyPresent("Return");
            }
        } else if (platform.equalsIgnoreCase("android")) {
            for (int i = 0; i < passwordDetails.size(); i++) {
                parts = passwordDetails.get(i).split("##");
                error_locator = configvariable.getFormattedString(configVariable.expandValue(errorMessages), configvariable.expandValue(parts[1]));
                testBasePage.setTextWithTab(configVariable.expandValue(passwordTextField), parts[0]);
                testBasePage.clickButton(configvariable.expandValue(signInButton));
                testBasePage.waitTime(2);
                Assert.assertTrue(testBasePage.isElementDisplayed(error_locator), configvariable.expandValue(parts[1]));
            }
        }
    }

    /*public void navigateToLoginPage(String platform) throws InterruptedException {
        if (platform.equalsIgnoreCase("android")) {
            testBasePage.waitTime(4);
            appiumCommands.swipe(AppiumCommands.DIRECTION.DOWN, 6000);
            testBasePage.waitTime(1);
            testBasePage.clickButton(configVariable.expandValue(signInLink));
        } else if (platform.equalsIgnoreCase("iOS")) {
            if (testBasePage.isElementDisplayed(configvariable.expandValue(Accountbutton))) {
                pulseLoginScreen.clickSignOut();
                testBasePage.isElementDisplayed(configvariable.expandValue(emailTextField));
            } else if (testBasePage.isElementDisplayed(configvariable.expandValue(continueWithEmailButton))) {
                testBasePage.isElementDisplayed(configvariable.expandValue(continueWithEmailButton));
                testBasePage.clickButton(configVariable.expandValue(signInLink));
            }
        }
    }*/


    public String verifyHomePageText(String platform) {
        String Homepagetext = "";
        if (platform.equalsIgnoreCase("android")) {
            testBasePage.isElementDisplayed(configVariable.getStringVar(homepageText));
            Homepagetext = testBasePage.getElementText(configVariable.getStringVar(homepageText));
        } else if (platform.equalsIgnoreCase("iOS")) {
            testBasePage.isElementDisplayed(configVariable.getStringVar(homepageText));
            Homepagetext = testBasePage.getText(configVariable.getStringVar(homepageText));
        }
        return Homepagetext;
    }


    public boolean isHomeTabDisplayed() {
        if (testBasePage.isElementDisplayed(configVariable.expandValue(enableTouchId))) {
            testBasePage.clickButton(configVariable.expandValue(enableTouchId));
        }
        return testBasePage.isElementDisplayed(configVariable.expandValue(homepageText));
    }

    public void clickSkipsButton() {
        testBasePage.waitTime(3);
        if (testBasePage.isElementDisplayed(configVariable.expandValue(skipButton))) {
            testBasePage.clickButton(configVariable.expandValue(skipButton));
        }
    }

    public void isHomePageDisplayed() {
        testBasePage.isElementDisplayed(configVariable.expandValue(homepageText));
    }

    public void clickWhatsappIcon(String platform) {
        int iCount = 0;
        while(testBasePage.isElementDisplayed(configVariable.expandValue(homepageShareIcon))&&iCount<2) {
            testBasePage.clickButton(configVariable.expandValue(homepageShareIcon));
            testBasePage.waitTime(2);
            iCount++;
        }
        testBasePage.clickButton(configVariable.expandValue(shareWhatsappIcon));
        testBasePage.waitTime(5);
        if (platform.equalsIgnoreCase("android")) {
            appiumCommands.runADBShellCommand("adb shell input keyevent 4");
            testBasePage.waitTime(3);
        }
//        else if (platform.equalsIgnoreCase("iOS")) {
//            testBasePage.scrollPageDown();
//            testBasePage.waitTime(5);
//            testBasePage.scrollPageDown();
//            testBasePage.clickButton(configVariable.expandValue(shareWhatsappIcon));
//        }
    }

    public void clickContactsIcon() {
        testBasePage.clickButton(configVariable.expandValue(homepageShareIcon));
        testBasePage.waitTime(5);
        testBasePage.clickButton(configVariable.expandValue(shareContactsIcon));
        if (testBasePage.isElementDisplayed(configVariable.expandValue(contactsAllowButton))) {
            testBasePage.clickButton(configVariable.expandValue(contactsAllowButton));
        } else if (testBasePage.isElementDisplayed(configvariable.expandValue(locationAlertMsg)))
            testBasePage.clickButton(configvariable.expandValue(contactsAccessAllowButton));
        testBasePage.clickButton(configVariable.expandValue(contactSkipButton));
    }

    public void clickWeChatIcon() {
        appiumCommands.waitForClickable(By.xpath(homepageShareIcon));
        testBasePage.clickButton(configVariable.expandValue(homepageShareIcon));
        testBasePage.clickButton(configVariable.expandValue(shareWeChatIcon));
    }

    public void clickLineIcon() {
        appiumCommands.waitForClickable(By.xpath(homepageShareIcon));
        testBasePage.clickButton(configVariable.expandValue(homepageShareIcon));
        testBasePage.clickButton(configVariable.expandValue(shareLineIcon));
    }

    public void clickViberIcon() {
        appiumCommands.waitForClickable(By.xpath(homepageShareIcon));
        testBasePage.clickButton(configVariable.expandValue(homepageShareIcon));
        testBasePage.clickButton(configVariable.expandValue(shareViberIcon));
    }

    public void clickSkipButton() {

        if (testBasePage.isElementDisplayed(configVariable.expandValue(nonOfAboveLink)) & TestBasePage.platform.equalsIgnoreCase("android"))
            testBasePage.clickButton(configVariable.expandValue(nonOfAboveLink));

        testBasePage.clickButton(configVariable.expandValue(skipButton));
    }

    public void EnterPasswordRegister(String platform, String password) {
        testBasePage.setTextWithTab(configVariable.expandValue(passwordTextField), password);
        if (platform.equalsIgnoreCase("iOS")) {
            appiumCommands.hideIOSKeyBoard();
            appiumCommands.isKeyBoardKeyPresent("Return");
        } else {
            appiumCommands.hideKeyboard();
        }


    }

    public boolean verifyAgainInvalidMobilelMsg(String invalidMsg) {
        String errorLocator = configVariable.getFormattedString(configVariable.expandValue(Invalidalertmobilemessage), invalidMsg);
        return testBasePage.isElementDisplayed(errorLocator);
    }

    public boolean verifyAgainInvalidGenderlMsg(String invalidMsg) {
        String errorLocator = configVariable.getFormattedString(configVariable.expandValue(InvalidGenderTextmessage), invalidMsg);
        return testBasePage.isElementDisplayed(errorLocator);
    }

    public String verifyAgainInvalidnriclMsg(String platform, String invalidMsg) {
        String inValidMsg = null;
        String errorLocator;
        if (platform.equalsIgnoreCase("android")) {
            errorLocator = configVariable.getFormattedString(configVariable.expandValue(InvalidNRICNumber), invalidMsg);
            //   errorLocator = configVariable.getFormattedString(inValidEmailMsg, invalidMsg);
            inValidMsg = testBasePage.getElementText(errorLocator);
            return inValidMsg;

        } else if (platform.equalsIgnoreCase("iOS")) {
            errorLocator = configVariable.getFormattedString(configVariable.expandValue(InvalidNRICNumber), invalidMsg);
            String inValidMsgs = testBasePage.getElementText(errorLocator);

            inValidMsg = inValidMsgs.substring(12, 36);
            //  inValidMsg =  testBasePage.getElementText(errorLocator);
            return inValidMsg;
        }
        return inValidMsg;
    }

    public String verifyInvalidEmailidlMsg(String platform, String invalidMsg) {
        String inValidMsg = null;
        String errorLocator;
        if (platform.equalsIgnoreCase("android")) {
            errorLocator = configVariable.getFormattedString(configVariable.expandValue(InvalidEamilid), invalidMsg);
            //   errorLocator = configVariable.getFormattedString(inValidEmailMsg, invalidMsg);
            inValidMsg = testBasePage.getElementText(errorLocator);
            return inValidMsg;

        } else if (platform.equalsIgnoreCase("iOS")) {
            errorLocator = configVariable.getFormattedString(configVariable.expandValue(InvalidEamilid), invalidMsg);
            inValidMsg = testBasePage.getElementText(errorLocator);
            return inValidMsg;
        }
        return inValidMsg;
    }

    public void clickSignIns_InSignUp(String platform) {
        if (platform.equalsIgnoreCase("android")) {
            appiumCommands.swipe(AppiumCommands.DIRECTION.DOWN, 6000);
            testBasePage.clickButton(configVariable.expandValue(Signins));

        } else if (platform.equalsIgnoreCase("iOS")) {
            testBasePage.clickButton(configVariable.expandValue(SigninsIos));
        }

    }

    public void clickNext_Button(String platform) throws InterruptedException {
        if (platform.equalsIgnoreCase("android")) {
            Thread.sleep(9000);
            appiumCommands.swipe(AppiumCommands.DIRECTION.DOWN, 6000);
            testBasePage.clickButton(configVariable.expandValue(NextGmail));

        } else if (platform.equalsIgnoreCase("iOS")) {
            testBasePage.clickButtonUsingJs(configVariable.expandValue(forgotPassword));
        }

    }

    public void clickFacebookt_Button(String platform, String buttontext) throws InterruptedException {
        if ("android".equalsIgnoreCase(platform)) {
            testBasePage.waitTime(5);
            System.out.println("Entering");
            String locator = configvariable.getFormattedString(configvariable.expandValue(facebookAccount), buttontext);
//            if (testBasePage.isElementDisplayed(locator)) {
//                // (appiumCommands.isElementDisplayed(androidRegistrationLocator.getRegisterWithEmailButton())) {
//                //  appiumCommands.findElement(androidManageProfileLocator.getLocationaAllowButton()).click();
//                //       appiumCommands.findElement(androidRegistrationLocator.getRegisterWithEmailButton()).click();
//                System.out.println("Click the button");
//                testBasePage.clickButton(configvariable.expandValue(facebookAccount));
//
//            }
            if (testBasePage.isElementDisplayed(locator)) {
                System.out.println("Entering else launch");
                appiumCommands.waitForVisibility(By.xpath(facebookAccount));
                testBasePage.clickButton(configvariable.expandValue(facebookAccount));
            }
            //testBasePage.clickButton(configvariable.expandValue(continueWithEmailButton));
            // appiumCommands.findElement(androidRegistrationLocator.getRegisterWithEmailButton()).click();

        } else if ("iOS".equalsIgnoreCase(platform)) {

            if (testBasePage.isElementDisplayed(configvariable.expandValue(allowButton)))
                testBasePage.clickButton(configvariable.expandValue(allowButton));
            if (testBasePage.isElementDisplayed(configvariable.expandValue(homeButton))) {
                clickSignOut();
                testBasePage.isElementDisplayed(configvariable.expandValue(emailTextField));
                testBasePage.clickButton(configvariable.expandValue(signupButton));
                testBasePage.waitTime(3);
                //   testBasePage.clickButton(configvariable.expandValue(facebookAccount));
            } else if (testBasePage.isElementDisplayed(configvariable.expandValue(signupButton))) {
                testBasePage.clickButton(configvariable.expandValue(signupButton));
                testBasePage.waitTime(3);
                testBasePage.clickButton(configvariable.expandValue(facebookAccount));
                testBasePage.waitTime(3);
                //   appiumCommands.tap(284, 509);
            } else if (testBasePage.isElementDisplayed(configvariable.expandValue(facebookAccount))) {
                testBasePage.clickButton(configvariable.expandValue(facebookAccount));
                testBasePage.waitTime(3);
                // appiumCommands.tap(284, 509);
            }

        }
    }

    public String verifyAgainInvalidEmailMsg(String platform, String invalidMsg) {
        String inValidMsg = null;
        String errorLocator;
        if (platform.equalsIgnoreCase("android")) {
            errorLocator = configVariable.getFormattedString(configVariable.expandValue(SecondInvalidmessage), invalidMsg);
            //   errorLocator = configVariable.getFormattedString(inValidEmailMsg, invalidMsg);
            inValidMsg = testBasePage.getElementText(errorLocator);
            return inValidMsg;

        } else if (platform.equalsIgnoreCase("iOS")) {
            errorLocator = configVariable.getFormattedString(inValidEmailMsg, invalidMsg);
            inValidMsg = testBasePage.getElementAttributeValue(errorLocator, "value");
            return inValidMsg;
        }
        return inValidMsg;
    }

    public void clickcontinuewithGoogle_Button(String platform, String buttontext) throws InterruptedException {
        if ("android".equalsIgnoreCase(platform)) {
            testBasePage.waitTime(5);
            System.out.println("Entering lanucj");
            String locator = configvariable.getFormattedString(configvariable.expandValue(continuewithgoogle), buttontext);
            if (testBasePage.isElementDisplayed(locator)) {
                // (appiumCommands.isElementDisplayed(androidRegistrationLocator.getRegisterWithEmailButton())) {
                //  appiumCommands.findElement(androidManageProfileLocator.getLocationaAllowButton()).click();
                //       appiumCommands.findElement(androidRegistrationLocator.getRegisterWithEmailButton()).click();
                System.out.println("Click the button");
                testBasePage.clickButton(configvariable.expandValue(continuewithgoogle));

            } else if (!testBasePage.isElementDisplayed(locator)) {
                System.out.println("Entering else launch");
                appiumCommands.waitForVisibility(By.xpath(continuewithgoogle));
                testBasePage.clickButton(configvariable.expandValue(continuewithgoogle));
            }
            //testBasePage.clickButton(configvariable.expandValue(continueWithEmailButton));
            // appiumCommands.findElement(androidRegistrationLocator.getRegisterWithEmailButton()).click();

        } else if ("iOS".equalsIgnoreCase(platform)) {
            testBasePage.waitTime(5);
            if (TestBasePage.platform.equalsIgnoreCase("iOS")) {
                if (testBasePage.isElementDisplayed(configvariable.expandValue(allowButton)))
                    testBasePage.clickButton(configvariable.expandValue(allowButton));
                if (testBasePage.isElementDisplayed(configvariable.expandValue(homeButton))) {
                    clickSignOut();
                    testBasePage.isElementDisplayed(configvariable.expandValue(emailTextField));
                    testBasePage.clickButton(configvariable.expandValue(signupButton));
                    testBasePage.waitTime(3);
                    testBasePage.clickButton(configvariable.expandValue(continueGmail));
                } else if (testBasePage.isElementDisplayed(configvariable.expandValue(signupButton))) {
                    testBasePage.clickButton(configvariable.expandValue(signupButton));
                    testBasePage.waitTime(3);
                    testBasePage.clickButton(configvariable.expandValue(continueGmail));
                    testBasePage.waitTime(3);
                    appiumCommands.tap(284, 509);
                } else if (testBasePage.isElementDisplayed(configvariable.expandValue(continueGmail))) {
                    testBasePage.clickButton(configvariable.expandValue(continueGmail));
                    testBasePage.waitTime(3);
                    appiumCommands.tap(284, 509);
                }
            }

        }
    }


    public void EnterEmail_Id(String platform, Map<String, String> registrationDetails, String buttontexts) {
        if ("iOS".equalsIgnoreCase(platform)) {
            testBasePage.waitTime(4);

            if (testBasePage.isElementDisplayed(configVariable.expandValue(emailname))) {
                testBasePage.clickButton(configvariable.expandValue(emailname));
            } else if (testBasePage.isElementDisplayed(configVariable.expandValue(EnterEmailname))) {
                testBasePage.clickButton(configvariable.expandValue(EnterEmailname));
                testBasePage.setTextWithTab(configvariable.expandValue(EnterEmailname), configvariable.expandValue(registrationDetails.get("Emailid")));
                ;
                testBasePage.clickButton(configvariable.expandValue(EnterNext));
                testBasePage.waitTime(8);
                testBasePage.clickButton(configvariable.expandValue(EnterPassword));
                testBasePage.setTextWithTab(configvariable.expandValue(EnterPassword), configvariable.expandValue(registrationDetails.get("Password")));
                testBasePage.clickButton(configvariable.expandValue(EnterNext));
            } else if (testBasePage.isElementDisplayed(configVariable.expandValue(AnotherAccount))) {
                testBasePage.clickButton(configvariable.expandValue(AnotherAccount));
                testBasePage.clickButton(configvariable.expandValue(EnterEmailname));
                testBasePage.setTextWithTab(configvariable.expandValue(EnterEmailname), configvariable.expandValue(registrationDetails.get("Emailid")));

                testBasePage.clickButton(configvariable.expandValue(EnterNext));
                testBasePage.waitTime(8);
                testBasePage.clickButton(configvariable.expandValue(EnterPassword));
                testBasePage.setTextWithTab(configvariable.expandValue(EnterPassword), configvariable.expandValue(registrationDetails.get("Password")));
                testBasePage.clickButton(configvariable.expandValue(EnterNext));
            }

        }

        if ("Android".equalsIgnoreCase(platform)) {
            System.out.println("Enter the Mobile number screen");
            testBasePage.waitTime(7);
            String locator = configvariable.getFormattedString(configvariable.expandValue(Emailtexts), buttontexts);
            String locator1 = configvariable.expandValue(chooseAccount);
            if (testBasePage.isElementDisplayed(locator)) {
                System.out.println("Inside Loop");
                testBasePage.setTextWithTab(configvariable.expandValue(Emailtexts), configvariable.expandValue(registrationDetails.get("Emailid")));
                appiumCommands.swipe(AppiumCommands.DIRECTION.DOWN, 6000);
                testBasePage.clickButton(configVariable.expandValue(NextGmail));
                testBasePage.waitTime(3);
                testBasePage.setTextWithTab(configvariable.expandValue(Emailtexts), configvariable.expandValue(registrationDetails.get("Password")));
                testBasePage.waitTime(2);
                String locators = configvariable.expandValue(passwordNexts);
                if (testBasePage.isElementDisplayed(locators)) {

                    testBasePage.clickButton(configvariable.expandValue(passwordNexts));
                } else {
                    testBasePage.clickButton(configvariable.expandValue(passwordNext));
                }
                testBasePage.waitTime(6);
                testBasePage.clickButton(configvariable.expandValue(Agreebuttontext));
                testBasePage.waitTime(6);
                if (testBasePage.isElementDisplayed(Morebutton)) {
                    testBasePage.clickButton(configvariable.expandValue(Morebutton));
                }
                testBasePage.clickButton(configvariable.expandValue(Acceptbuttontext));
                // appiumCommands.findElement(androidRegistrationLocator.mobileNumber()).sendKeys(registrationDetails.get("mobileNumber"));
            } else if (testBasePage.isElementDisplayed(locator1)) {
                System.out.println("Outside Loop");
                testBasePage.clickButton(configvariable.expandValue(chooseAccount));
            } else {
                testBasePage.clickButton(configvariable.expandValue(AddAccount));
                System.out.println("Inside Loop");
                testBasePage.waitTime(7);
                testBasePage.setTextWithTab(configvariable.expandValue(Emailtexts), configvariable.expandValue(registrationDetails.get("Emailid")));
                appiumCommands.swipe(AppiumCommands.DIRECTION.DOWN, 6000);
                testBasePage.clickButton(configVariable.expandValue(NextGmail));
                testBasePage.waitTime(3);
                testBasePage.setTextWithTab(configvariable.expandValue(Emailtexts), configvariable.expandValue(registrationDetails.get("Password")));
                testBasePage.waitTime(2);
                String locators = configvariable.expandValue(passwordNexts);
                if (testBasePage.isElementDisplayed(locators)) {

                    testBasePage.clickButton(configvariable.expandValue(passwordNexts));
                } else {
                    testBasePage.clickButton(configvariable.expandValue(passwordNext));
                }
                testBasePage.waitTime(6);
                testBasePage.clickButton(configvariable.expandValue(Agreebuttontext));
                testBasePage.waitTime(6);
                testBasePage.clickButton(configvariable.expandValue(Morebutton));
                testBasePage.clickButton(configvariable.expandValue(Acceptbuttontext));
            }


        }
    }

    public void EnterFacebookLogin(String platform, Map<String, String> registrationDetails, String buttontexts) {
        if ("iOS".equalsIgnoreCase(platform)) {
            testBasePage.waitTime(7);
            //   appiumCommands.waitForVisibility(By.xpath(NoneofAbove));
            String locator = configvariable.getFormattedString(configvariable.expandValue(Facebookproceed), buttontexts);
            // appiumCommands.swipe(AppiumCommands.DIRECTION.UP, 6000);
            if (!testBasePage.isElementDisplayed(locator)) {
                System.out.println("Inside Loop");
                //  if (appiumCommands.isElementDisplayed(androidRegistrationLocator.NoneofAbove())) {
                //  appiumCommands.findElement(androidRegistrationLocator.NoneofAbove()).click();
                // testBasePage.clickButton(configvariable.expandValue(Emailtexts));
                // appiumCommands.cleartext(By.xpath(configvariable.expandValue(MobileNumber)));
                appiumCommands.cleartext(By.xpath(configVariable.expandValue(clearFacebookusername)));
                testBasePage.setTextWithTab(configvariable.expandValue(Facebookusername), configvariable.expandValue(registrationDetails.get("Emailid")));
                testBasePage.waitTime(3);
                testBasePage.setTextWithTab(configvariable.expandValue(Facebookpassword), configvariable.expandValue(registrationDetails.get("Password")));
                testBasePage.clickButton(configvariable.expandValue(Facebooklogin));
                testBasePage.waitTime(4);
                if (testBasePage.isElementDisplayed(configvariable.expandValue(Facebookproceed))) {

                    testBasePage.clickButton(configvariable.expandValue(Facebookproceed));
                } else {

                    testBasePage.clickButton(configvariable.expandValue(Facebookproceeds));

                }
            } else {
                if (testBasePage.isElementDisplayed(configvariable.expandValue(Facebookproceed))) {

                    testBasePage.clickButton(configvariable.expandValue(Facebookproceed));

                } else {
                    testBasePage.clickButton(configvariable.expandValue(Facebookproceeds));

                }
//
            }
        }

        if ("Android".equalsIgnoreCase(platform)) {
            System.out.println("Enter the Mobile number screen");
            testBasePage.waitTime(7);
            //   appiumCommands.waitForVisibility(By.xpath(NoneofAbove));
            String locator = configvariable.getFormattedString(configvariable.expandValue(Facebookproceed), buttontexts);
            // appiumCommands.swipe(AppiumCommands.DIRECTION.UP, 6000);
            if (!testBasePage.isElementDisplayed(locator)) {
                System.out.println("Inside Loop");
                //  if (appiumCommands.isElementDisplayed(androidRegistrationLocator.NoneofAbove())) {
                //  appiumCommands.findElement(androidRegistrationLocator.NoneofAbove()).click();
                // testBasePage.clickButton(configvariable.expandValue(Emailtexts));
                // appiumCommands.cleartext(By.xpath(configvariable.expandValue(MobileNumber)));
                appiumCommands.cleartext(By.xpath(configVariable.expandValue(Facebookusername)));
                testBasePage.setTextWithTab(configvariable.expandValue(Facebookusername), configvariable.expandValue(registrationDetails.get("Emailid")));
                testBasePage.setTextWithTab(configvariable.expandValue(Facebookpassword), configvariable.expandValue(registrationDetails.get("Password")));
                testBasePage.clickButton(configvariable.expandValue(Facebooklogin));
                testBasePage.waitTime(8);
                testBasePage.clickButton(configvariable.expandValue(Facebookproceed));
//                testBasePage.waitTime(6);
//                testBasePage.clickButton(configvariable.expandValue(Morebutton));
//                testBasePage.clickButton(configvariable.expandValue(Acceptbuttontext));
                // appiumCommands.findElement(androidRegistrationLocator.mobileNumber()).sendKeys(registrationDetails.get("mobileNumber"));
            } else {
                System.out.println("Outside Loop");
                testBasePage.clickButton(configvariable.expandValue(Facebookproceed));
//                //  appiumCommands.cleartext(By.xpath(configvariable.expandValue(Emailtexts)));
//                // testBasePage.setTextWithTab(configvariable.expandValue(Emailtexts), configvariable.expandValue(registrationDetails.get("Emailid")));
//                //appiumCommands.findElement(androidRegistrationLocator.mobileNumber()).sendKeys(registrationDetails.get("mobileNumber"));
            }


        }
    }

    public void EnterPassword_Id(String platform, Map<String, String> registrationDetails, String buttontexts) {
        if ("iOS".equalsIgnoreCase(platform)) {
            testBasePage.setTextWithTab(configvariable.expandValue(firstNameText), registrationDetails.get("FirstName"));
            testBasePage.setTextWithTab(configvariable.expandValue(lastNameText), registrationDetails.get("LastName"));
            testBasePage.setTextWithTab(configvariable.expandValue(emailText), registrationDetails.get("Email"));
            testBasePage.setTextWithTab(configvariable.expandValue(passwordText), registrationDetails.get("Password"));
        }

        if ("Android".equalsIgnoreCase(platform)) {
            System.out.println("Enter the Mobile number screen");
            testBasePage.waitTime(9);
            //   appiumCommands.waitForVisibility(By.xpath(NoneofAbove));
            String locator = configvariable.getFormattedString(configvariable.expandValue(Emailtexts), buttontexts);
            // appiumCommands.swipe(AppiumCommands.DIRECTION.UP, 6000);
            if (testBasePage.isElementDisplayed(locator)) {
                System.out.println("Inside Loop");
                //  if (appiumCommands.isElementDisplayed(androidRegistrationLocator.NoneofAbove())) {
                //  appiumCommands.findElement(androidRegistrationLocator.NoneofAbove()).click();
                // testBasePage.clickButton(configvariable.expandValue(Emailtexts));
                // appiumCommands.cleartext(By.xpath(configvariable.expandValue(MobileNumber)));
                testBasePage.setTextWithTab(configvariable.expandValue(Emailtexts), configvariable.expandValue(registrationDetails.get("Password")));
                testBasePage.clickButton(configvariable.expandValue(passwordNext));
                testBasePage.waitTime(6);
                testBasePage.clickButton(configvariable.expandValue(Agreebuttontext));
                testBasePage.waitTime(6);
                testBasePage.clickButton(configvariable.expandValue(Morebutton));
                testBasePage.clickButton(configvariable.expandValue(Acceptbuttontext));

                // appiumCommands.findElement(androidRegistrationLocator.mobileNumber()).sendKeys(registrationDetails.get("mobileNumber"));
            } else {
                System.out.println("Outside Loop");
                //  appiumCommands.cleartext(By.xpath(configvariable.expandValue(Emailtexts)));

                testBasePage.setTextWithTab(configvariable.expandValue(Emailtexts), configvariable.expandValue(registrationDetails.get("Password")));
                //appiumCommands.findElement(androidRegistrationLocator.mobileNumber()).sendKeys(registrationDetails.get("mobileNumber"));
            }


        }

    }

    public void enterEmailId(String userName) {
        testBasePage.setTextWithTab(configvariable.expandValue(emailTextFields), userName);
    }

    public void clickSubmitButton() {
        appiumCommands.swipe(AppiumCommands.DIRECTION.DOWN, 3000);
        testBasePage.clickButton(configvariable.getFormattedString(configvariable.expandValue(buttonLocator), configvariable.expandValue("${submit.button.text}")));
    }

    public void clickButton(String buttonText) {
        //  cpTestBasePage.clickButton(configvariable.getFormattedString(configvariable.expandValue(buttonLocator), buttonText));

        String locator = configvariable.getFormattedString(configvariable.expandValue(buttonLocator), buttonText);
        if (testBasePage.isElementDisplayed(locator)) {
            testBasePage.clickButton(locator);
        } else {
            testBasePage.scrollPageDown();
            if (testBasePage.isElementDisplayed(locator)) {
                testBasePage.clickButton(locator);
            } else if (!testBasePage.isElementDisplayed(locator)) {
                //  testBasePage.scrollUpTillElementDisplayed(buttonText, 0, 0, -650, -100);
                testBasePage.clickButton(locator);
            }
        }

    }

    public void enterOTP(String otp) {
        char[] carr = otp.toCharArray();
        testBasePage.setTextWithTab(configvariable.getFormattedString(configvariable.expandValue(otpTextField), "1"), Character.toString(carr[0]));
        appiumCommands.hideKeyboard();
        testBasePage.setTextWithTab(configvariable.getFormattedString(configvariable.expandValue(otpTextField), "2"), Character.toString(carr[1]));
//        appiumCommands.hideKeyboard();
        testBasePage.setTextWithTab(configvariable.getFormattedString(configvariable.expandValue(otpTextField), "3"), Character.toString(carr[2]));
//        appiumCommands.hideKeyboard();
        testBasePage.setTextWithTab(configvariable.getFormattedString(configvariable.expandValue(otpTextField), "4"), Character.toString(carr[3]));
//        appiumCommands.hideKeyboard();
        testBasePage.setTextWithTab(configvariable.getFormattedString(configvariable.expandValue(otpTextField), "5"), Character.toString(carr[4]));
//        appiumCommands.hideKeyboard();
        testBasePage.setTextWithTab(configvariable.getFormattedString(configvariable.expandValue(otpTextField), "6"), Character.toString(carr[5]));
        appiumCommands.hideKeyboard();

    }

    public void clickMessengerIcon() {
        testBasePage.waitTime(5);
        testBasePage.clickButton(configVariable.expandValue(homepageShareIcon));
        testBasePage.clickButton(configVariable.expandValue(shareMessengerIcon));
    }

    public void relaunchOPapp() {
        testBasePage.relaunchApp();
    }

    public void verifyHeightandWeightScreenUi() {
        softAssert.assertTrue(testBasePage.isElementDisplayed(configvariable.expandValue(userHeight)), "Default height section is not displayed in the UI");
        softAssert.assertTrue(testBasePage.isElementDisplayed(configvariable.expandValue(userWeight)), "Default weight section is not displayed in the UI");
        softAssert.assertAll();
    }

    public void clickCalculateBMIButton() {
        if (testBasePage.isElementDisplayed(configvariable.expandValue(calculateBMI)))
            testBasePage.clickButton(configvariable.expandValue(calculateBMI));
        else
            softAssert.fail("calculate BMI button is not displayed");
    }

    public void verifytrackerConnectScreenUI() {
        softAssert.assertTrue(testBasePage.isElementDisplayed(configvariable.expandValue(wellnessTrackingActivity)), "Tracking your activity is trending title is not displayed in the UI");
        softAssert.assertAll();
    }

    public void clickOnAccountButton() {
        testBasePage.waitTime(2);
        int iCount = 0;
        while (testBasePage.isElementDisplayed(configVariable.expandValue(homeAccountImage)) && iCount < 3) {
            testBasePage.clickButton(configVariable.expandValue(homeAccountImage));
            testBasePage.waitTime(2);
            iCount++;
        }
    }

    public void logoutOfAppIfLoggedIn() {
        if (TestBasePage.platform.equalsIgnoreCase("ios") && testBasePage.isElementDisplayed(configVariable.expandValue(homepageText))) {
            clickOnAccountButton();
            Signout_button(TestBasePage.platform);
        }

    }

    public void Signout_button(String platform) {
        testBasePage.waitTime(4);
        appiumCommands.swipe(AppiumCommands.DIRECTION.DOWN, 6000);
        if (platform.equalsIgnoreCase("android")) {
            int iCount = 0;
            while (testBasePage.isElementDisplayed(configvariable.expandValue(signout)) && iCount < 3) {
                testBasePage.clickButton(configvariable.expandValue(signout));
                testBasePage.waitTime(2);
                iCount++;
            }
        } else if (platform.equalsIgnoreCase("iOS")) {
            testBasePage.clickButton(configvariable.expandValue(signout));
        }
    }

    public void clickMyChallengesTile(String platform) {
        String lbu = System.getProperty("app.lbu");
        if (lbu.equalsIgnoreCase("my")) {
            String locator = configvariable.expandValue(myChallenges);
            if (platform.equalsIgnoreCase("android")) {
                int iCount = 0;
                while (testBasePage.isElementDisplayed(locator) && iCount < 3) {
                    testBasePage.clickButton(locator);
                    testBasePage.waitTime(3);
                    iCount++;
                }

            } else if (TestBasePage.platform.equalsIgnoreCase("ios")) {
                testBasePage.waitTime(5);
                testBasePage.clickElementByCoordinateForBothXY(configvariable.expandValue(myChallenges), 60, 30);
            }
        }
        if (lbu.equalsIgnoreCase("sg")) {
            String locator = configvariable.expandValue(myChallengesSG);
            if (platform.equalsIgnoreCase("android")) {
                int iCount = 0;
                while (testBasePage.isElementDisplayed(locator) && iCount < 3) {
                    testBasePage.clickButton(locator);
                    testBasePage.waitTime(3);
                    iCount++;
                }

            } else if (TestBasePage.platform.equalsIgnoreCase("ios")) {
                testBasePage.waitTime(5);
                testBasePage.clickElementByCoordinateForBothXY(configvariable.expandValue(myChallenges), 60, 30);
            }
        }

    }
    public void clicknewcontinuebuttons(String platform) throws InterruptedException {
        if (platform.equalsIgnoreCase("iOS")) {
            testBasePage.waitTime(3);
            if (testBasePage.isElementDisplayed(configVariable.expandValue(googlecontine))) {
                appiumCommands.tap(284, 509);
            }
            //  testBasePage.clickButton(configVariable.expandValue(googlecontine));
        }

    }

    public void clickContinueFacebook(String platform) throws InterruptedException {
        if (platform.equalsIgnoreCase("iOS")) {
            testBasePage.waitTime(8);
            //    if(testBasePage.isElementDisplayed(configVariable.expandValue(Facebookcontinue))) {
            //    appiumCommands.tap(284, 509);
            testBasePage.clickButton(configVariable.expandValue(Facebookcontinue));
            //  }
            //  else {
            //    testBasePage.clickButton(configVariable.expandValue(Facebookcontinue));
            // }

        }

    }

    public void navigateToUrl(String url) {
        //     WebDriver driver = testBasePage.getDriver();
        System.out.println(configVariable.expandValue(url));
        testBasePage.navigateToApplicationUrl(configVariable.expandValue(url));
    }


}
