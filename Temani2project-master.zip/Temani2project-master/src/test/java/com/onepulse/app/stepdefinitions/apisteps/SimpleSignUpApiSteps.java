package com.onepulse.app.stepdefinitions.apisteps;

import com.onepulse.app.api.SignUpApi;
import com.onepulse.app.cucumberhooks.CucumberHook;
import com.prod.tap.api.HttpClientApi;
import com.prod.tap.config.Configvariable;
import com.prod.tap.config.TapBeansLoad;
import com.prod.tap.cucumberUtils.ScenarioUtils;
import com.prod.tap.filehandling.JsonReader;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import org.apache.log4j.Logger;

public class SimpleSignUpApiSteps {
    private Configvariable configvariable = CucumberHook.context.getBean(Configvariable.class);
    private static final Logger logger = Logger.getLogger(SimpleSignUpApiSteps.class);
    private HttpClientApi httpClientApi = (HttpClientApi) TapBeansLoad.getBean(HttpClientApi.class);
    private ScenarioUtils scenarioUtils = (ScenarioUtils) TapBeansLoad.getBean(ScenarioUtils.class);
    private JsonReader jsonreader = (JsonReader)TapBeansLoad.getBean(JsonReader.class);
    private SignUpApi signUpApi = CucumberHook.context.getBean(SignUpApi.class);



    @Then("^I verify store inventory \"([^\"]*)\" order api \"([^\"]*)\"$")
    public void iVerifyStoreInventoryOrderApi(String BaseUrl, String endPoint) throws Throwable {
        this.scenarioUtils.write("Base Url :" + configvariable.expandValue(BaseUrl));
        this.scenarioUtils.write("End Point Url :" + configvariable.expandValue(endPoint));
        signUpApi.storeInventory(BaseUrl,endPoint);
    }

    @Given("^I sign up the simple login app \"([^\"]*)\" using \"([^\"]*)\" end point$")
    public void iSignUpTheSimpleLoginAppUsingEndPoint(String BaseUrl, String endPoint) throws Throwable {
        this.scenarioUtils.write("Base Url :" + configvariable.expandValue(BaseUrl));
        this.scenarioUtils.write("End Point Url :" + configvariable.expandValue(endPoint));
        signUpApi.simpleLoginSignUp(BaseUrl,endPoint);
    }
}
