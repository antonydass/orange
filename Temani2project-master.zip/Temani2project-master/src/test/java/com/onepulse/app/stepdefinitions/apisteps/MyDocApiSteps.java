package com.onepulse.app.stepdefinitions.apisteps;


//import com.onepulse.app.api.MyDocApi;
import com.onepulse.app.api.MyDocApi;
import com.onepulse.app.cucumberhooks.CucumberHook;
import com.onepulse.app.utils.MyDocDoctorDetails;
import com.prod.tap.config.Configvariable;
import cucumber.api.DataTable;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.response.Response;
import org.testng.Assert;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class MyDocApiSteps {
    private MyDocApi myDocApi = CucumberHook.context.getBean(MyDocApi.class);
    private Configvariable configvariable = CucumberHook.context.getBean(Configvariable.class);

    private MyDocDoctorDetails myDocDoctorDetails = CucumberHook.context.getBean(MyDocDoctorDetails.class);

    private Response createEpisodeDetails = null;
    private Response createAppointmentDetails = null;
    private Response acceptAppointmentDetails = null;
    private Response rejectAppointmentDetails = null;
    private Response getAppointmentDetails = null;
    private Response getAccountDetails = null;
    private Response getAcctGroupDetails = null;
    private Response updateAcctDetails = null;
    private Response createCaseNoteDetails = null;
    private Response getGroupDetails = null;
    private Response createEMCDetails = null;
    private Response sendEMCDetails = null;
    private Response getEpisodeChatMessages = null;
    private Response getAvailableDoctorDetails = null;
    private Response createEmergencyContactDetails = null;
    private Response updateEmergencyContactDetails = null;
    private Response getEmergencyContactDetails = null;
    private Response deleteEmergencyContactDetails = null;

    @When("I login to MyDoc using api with doctor credentials")
    public void loginToMyDocWithDoctorCredential() {
        myDocApi.loginToMyDoc(configvariable.getStringVar("DoctorUsername"), configvariable.getStringVar("DoctorPassword"));
    }

    @When("Doctor accepts the appointment for the patient \"([^\"]*)\"")
    public void doctorAcceptAppointment(String patientEmail) {
        myDocApi.getApppointmentIdForPatient();
        acceptAppointmentDetails = myDocApi.doctorAcceptAppointment();
    }


    @When("I login to MyDoc using api with concierge credentials as below")
    public void loginToMyDocWithConciergeCredential(DataTable conciergeDetails) {
        Map<String, String> conciergeDetailsMap;
        conciergeDetailsMap = conciergeDetails.asMap(String.class, String.class);
        configvariable.assignValueToVarMap(conciergeDetailsMap);
        myDocApi.loginToMyDoc(configvariable.getStringVar("CONCIERGE_EMAIL"), configvariable.getStringVar("CONCIERGE_PASSWORD"));
    }

    @When("I get MyDoc Patient ID using API for patient \"([^\"]*)\" into variable \"([^\"]*)\"")
    public void getPatientIdMyMuyDocAPI(String patientEmail, String patient_id) {
        configvariable.setStringVariable(myDocApi.getPatientID(patientEmail), patient_id);
    }

    @When("I create episode using MyDoc API")
    public void createEpisodeUsingMyDocAPI(DataTable userDetails) {
        Map<String, String> conciergeDetailsMap;
        conciergeDetailsMap = userDetails.asMap(String.class, String.class);
        createEpisodeDetails = myDocApi.createEpisode(configvariable.expandValue(conciergeDetailsMap.get("patient_id")), configvariable.expandValue(conciergeDetailsMap.get("myDoc_UserId")));
    }

    @When("I verify following details are present in response of create episode API")
    public void verifyCreateEpisodeResponse(DataTable dt) {
        List<Map<String, String>> rows = dt.asMaps(String.class, String.class);
        Map<String, String> createEpisodeDetailsMap = rows.get(0);
        String actualVal = null;
        int docIndex = 0;
        int patientIndex = 0;
        int totalMembers = ((ArrayList) createEpisodeDetails.jsonPath().get("data.members")).size();
        for (int iCount = 0; iCount < totalMembers; iCount++) {
            if (createEpisodeDetails.jsonPath().get("data." + "members[" + iCount + "].id").toString() != null && createEpisodeDetails.jsonPath().get("data." + "members[" + iCount + "].id").toString().equals(configvariable.expandValue("${DoctorId}"))) {
                docIndex = iCount;
                break;
            }
        }
        for (int iCount = 0; iCount < totalMembers; iCount++) {
            if (createEpisodeDetails.jsonPath().get("data." + "members[" + iCount + "].id").toString() != null && createEpisodeDetails.jsonPath().get("data." + "members[" + iCount + "].id").toString().equals(configvariable.expandValue("${PATIENT_ID}"))) {
                patientIndex = iCount;
                break;
            }
        }
        for (String key : createEpisodeDetailsMap.keySet()) {
            if (key.contains("data")) {
                String[] parts = key.split("->");
                if (parts[1].contains("members") && parts[2].contains("doctor")) {
                    actualVal = createEpisodeDetails.jsonPath().get("data." + parts[1] + "[" + docIndex + "]" + "." + parts[3]).toString();
                } else if (parts[1].contains("members") && parts[2].contains("patient")) {
                    actualVal = createEpisodeDetails.jsonPath().get("data." + parts[1] + "[" + patientIndex + "]" + "." + parts[3]).toString();
                } else if (parts.length == 2) {
                    actualVal = createEpisodeDetails.jsonPath().get("data." + parts[1]).toString();
                }
                Assert.assertEquals(actualVal, configvariable.expandValue(createEpisodeDetailsMap.get(key)), configvariable.expandValue(createEpisodeDetailsMap.get(key)) + " value is present in response");
            } else if (key.contains("code")) {
                actualVal = createEpisodeDetails.jsonPath().get("code").toString();
                Assert.assertEquals(actualVal, configvariable.expandValue(createEpisodeDetailsMap.get(key)), configvariable.expandValue(createEpisodeDetailsMap.get(key)) + " value is present in response");
            } else if (key.contains("message")) {
                actualVal = createEpisodeDetails.jsonPath().get("message").toString();
                Assert.assertEquals(actualVal, configvariable.expandValue(createEpisodeDetailsMap.get(key)), configvariable.expandValue(createEpisodeDetailsMap.get(key)) + " value is present in response");
            }
        }

    }

    @When("I send message \"([^\"]*)\" to patient using MyDoc API")
    public void sendMessageToPatientUsingMyDocAPI(String message) {
        myDocApi.sendEpisodeMessage(configvariable.expandValue(message));
    }

    @When("I create eMC for patient using MyDoc API")
    public void createEMCForPatient() {
        createEMCDetails = myDocApi.createEmc();
    }

    @When("I send eMC to the patient using MyDoc API")
    public void sendEMCToPatient() {
        sendEMCDetails = myDocApi.sendEmc();
    }

    @When("I create case note for patient using below details with MyDoc API")
    public void createCaseNoteForPatient(DataTable caseDetails) {
        Map<String, String> variableMap;
        variableMap = caseDetails.asMap(String.class, String.class);
        configvariable.assignValueToVarMap(variableMap);
        createCaseNoteDetails = myDocApi.createCaseNoteForPatient();
    }

    @When("I close the consultation using MyDoc Api")
    public void closeConsultationForPatient() {
        myDocApi.closeConsultationForPatient();
    }

    @When("Doctor rejects the appointment for the patient \"([^\"]*)\"")
    public void doctoRejectAppointment(String patientEmail) {
        //  myDocApi.getApppointmentIdForPatient(configvariable.expandValue(patientEmail));
        rejectAppointmentDetails = myDocApi.doctorRejectAppointment();
    }

    @When("I create the appointment using MyDoc Api")
    public void createDoctorAppointment() {
        LocalDateTime now = LocalDateTime.now().plusHours(1);
        String formattedDate = configvariable.formatDateAndTime("yyyy-MM-dd", now);
        String formattedTime = configvariable.formatDateAndTimeWithZone("HH:mm:ss", ZoneId.of("Asia/Singapore"), now);
        configvariable.setStringVariable(formattedDate, "FROM_DATE");
        configvariable.setStringVariable(formattedTime, "START_TIME");
        createAppointmentDetails = myDocApi.createAppointment();
    }

    @When("I verify following details are present in response of create appointment API")
    public void verifyCreateAppointmentResponse(DataTable dt) {

        List<Map<String, String>> rows = dt.asMaps(String.class, String.class);
        Map<String, String> createAppointmentDetailsMap = rows.get(0);
        String actualVal = null;
        for (String key : createAppointmentDetailsMap.keySet()) {
            if (key.contains("data")) {
                String[] parts = key.split("->");
                if (parts.length == 2) {
                    actualVal = createAppointmentDetails.jsonPath().get("data." + parts[1]).toString();
                } else if (parts.length == 3) {
                    actualVal = createAppointmentDetails.jsonPath().get("data." + parts[1] + "." + parts[2]).toString();
                }
                Assert.assertEquals(actualVal, configvariable.expandValue(createAppointmentDetailsMap.get(key)), configvariable.expandValue(createAppointmentDetailsMap.get(key)) + " value is present in response");
            } else if (key.contains("code")) {
                actualVal = createAppointmentDetails.jsonPath().get("code").toString();
                Assert.assertEquals(actualVal, configvariable.expandValue(createAppointmentDetailsMap.get(key)), configvariable.expandValue(createAppointmentDetailsMap.get(key)) + " value is present in response");
            } else if (key.contains("message")) {
                actualVal = createAppointmentDetails.jsonPath().get("message").toString();
                Assert.assertEquals(actualVal, configvariable.expandValue(createAppointmentDetailsMap.get(key)), configvariable.expandValue(createAppointmentDetailsMap.get(key)) + " value is present in response");
            }
        }
    }

    @When("I verify following details are present in response of accept appointment API")
    public void verifyAcceptAppointmentResponse(DataTable dt) {
        List<Map<String, String>> rows = dt.asMaps(String.class, String.class);
        Map<String, String> acceptAppointmentDetailsMap = rows.get(0);
        String actualVal = null;
        for (String key : acceptAppointmentDetailsMap.keySet()) {
            if (key.contains("data")) {
                String[] parts = key.split("->");
                if (parts.length == 2) {
                    actualVal = acceptAppointmentDetails.jsonPath().get("data." + parts[1]).toString();
                } else if (parts.length == 3) {
                    actualVal = acceptAppointmentDetails.jsonPath().get("data." + parts[1] + "." + parts[2]).toString();
                }
                Assert.assertEquals(actualVal, configvariable.expandValue(acceptAppointmentDetailsMap.get(key)), configvariable.expandValue(acceptAppointmentDetailsMap.get(key)) + " value is present in response");
            } else if (key.contains("code")) {
                actualVal = acceptAppointmentDetails.jsonPath().get("code").toString();
                Assert.assertEquals(actualVal, configvariable.expandValue(acceptAppointmentDetailsMap.get(key)), configvariable.expandValue(acceptAppointmentDetailsMap.get(key)) + " value is present in response");
            } else if (key.contains("message")) {
                actualVal = acceptAppointmentDetails.jsonPath().get("message").toString();
                Assert.assertEquals(actualVal, configvariable.expandValue(acceptAppointmentDetailsMap.get(key)), configvariable.expandValue(acceptAppointmentDetailsMap.get(key)) + " value is present in response");
            }
        }
    }

    @When("I verify following details are present in response of reject appointment API")
    public void verifyRejectAppointmentResponse(DataTable dt) {
        List<Map<String, String>> rows = dt.asMaps(String.class, String.class);
        Map<String, String> rejectAppointmentDetailsMap = rows.get(0);
        String actualVal = null;
        for (String key : rejectAppointmentDetailsMap.keySet()) {
            if (key.contains("data")) {
                String[] parts = key.split("->");
                if (parts.length == 2) {
                    actualVal = rejectAppointmentDetails.jsonPath().get("data." + parts[1]).toString();
                } else if (parts.length == 3) {
                    actualVal = rejectAppointmentDetails.jsonPath().get("data." + parts[1] + "." + parts[2]).toString();
                }
                Assert.assertEquals(actualVal, configvariable.expandValue(rejectAppointmentDetailsMap.get(key)), configvariable.expandValue(rejectAppointmentDetailsMap.get(key)) + " value is present in response");
            } else if (key.contains("code")) {
                actualVal = rejectAppointmentDetails.jsonPath().get("code").toString();
                Assert.assertEquals(actualVal, configvariable.expandValue(rejectAppointmentDetailsMap.get(key)), configvariable.expandValue(rejectAppointmentDetailsMap.get(key)) + " value is present in response");
            } else if (key.contains("message")) {
                actualVal = rejectAppointmentDetails.jsonPath().get("message").toString();
                Assert.assertEquals(actualVal, configvariable.expandValue(rejectAppointmentDetailsMap.get(key)), configvariable.expandValue(rejectAppointmentDetailsMap.get(key)) + " value is present in response");
            }
        }
    }

    @When("I create the patient using MyDoc Api")
    public void createPatient() {
        myDocApi.createPatient();
    }

    @When("I add the NRIC to patient using MyDoc APi")
    public void addNRIC() {
        myDocApi.addNricToPatient();
    }

    @When("I get the appointment detail for patient \"([^\"]*)\" MyDoc Api")
    public void getAppointmentResponse(String patientEmail) {
        //getAppointmentDetails = myDocApi.getApppointmentIdForPatient(configvariable.expandValue(patientEmail));
    }

    @When("I verify following details are present in response of get appointment API")
    public void verifyGetAppointmentResponseForPatient(DataTable dt) {
        List<Map<String, String>> rows = dt.asMaps(String.class, String.class);
        Map<String, String> getAppointmentDetailsMap = rows.get(0);
        String actualVal = null;
        int index = 0;
        for (String key : getAppointmentDetailsMap.keySet()) {
            if (key.contains("data")) {
                int totalAppointments = getAppointmentDetails.jsonPath().get("total");
                for (int iCount = 0; iCount < totalAppointments; iCount++) {
                    if (getAppointmentDetails.jsonPath().get("data[" + iCount + "].patient.email") != null && getAppointmentDetails.jsonPath().get("data[" + iCount + "].patient.email").equals(configvariable.expandValue("${PATIENT_EMAIL}").toLowerCase())) {
                        index = iCount;
                        break;
                    }
                }
                String[] parts = key.split("->");
                if (parts.length == 2) {
                    actualVal = getAppointmentDetails.jsonPath().get("data[" + index + "]" + "." + parts[1]).toString();
                } else if (parts.length == 3) {
                    actualVal = getAppointmentDetails.jsonPath().get("data[" + index + "]" + "." + parts[1] + "." + parts[2]).toString();
                }
                Assert.assertEquals(actualVal, configvariable.expandValue(getAppointmentDetailsMap.get(key)), configvariable.expandValue(getAppointmentDetailsMap.get(key)) + " value is present in response");
            } else if (key.contains("code")) {
                actualVal = getAppointmentDetails.jsonPath().get("code").toString();
                Assert.assertEquals(actualVal, configvariable.expandValue(getAppointmentDetailsMap.get(key)), configvariable.expandValue(getAppointmentDetailsMap.get(key)) + " value is present in response");
            } else if (key.contains("message")) {
                actualVal = getAppointmentDetails.jsonPath().get("message").toString();
                Assert.assertEquals(actualVal, configvariable.expandValue(getAppointmentDetailsMap.get(key)), configvariable.expandValue(getAppointmentDetailsMap.get(key)) + " value is present in response");
            }
        }
    }

    @When("I get the details using MyDoc Api for account id \"([^\"]*)\"")
    public void getAccount(String accountId) {
        getAccountDetails = myDocApi.getAccountID(accountId);
    }

    @When("I verify the account details returned by the MyDoc API")
    public void verifyGetAccount(DataTable dt) {
        List<Map<String, String>> rows = dt.asMaps(String.class, String.class);
        Map<String, String> getAccountDetailsMap = rows.get(0);
        String actualVal = null;
        for (String key : getAccountDetailsMap.keySet()) {
            if (key.contains("data")) {
                String[] parts = key.split("->");
                if (parts.length == 2) {
                    actualVal = getAccountDetails.jsonPath().get("data." + parts[1]).toString();
                } else if (parts.length == 3) {
                    actualVal = getAccountDetails.jsonPath().get("data." + parts[1] + "." + parts[2]).toString();
                }
                Assert.assertEquals(actualVal, configvariable.expandValue(getAccountDetailsMap.get(key)), configvariable.expandValue(getAccountDetailsMap.get(key)) + " value is present in response");
            } else if (key.contains("code")) {
                actualVal = getAccountDetails.jsonPath().get("code").toString();
                Assert.assertEquals(actualVal, configvariable.expandValue(getAccountDetailsMap.get(key)), configvariable.expandValue(getAccountDetailsMap.get(key)) + " value is present in response");
            } else if (key.contains("message")) {
                actualVal = getAccountDetails.jsonPath().get("message").toString();
                Assert.assertEquals(actualVal, configvariable.expandValue(getAccountDetailsMap.get(key)), configvariable.expandValue(getAccountDetailsMap.get(key)) + " value is present in response");
            }
        }
    }

    @When("I get the group details using MyDoc Api for account id \"([^\"]*)\"")
    public void getAccountGroup(String accountId) {
        getAcctGroupDetails = myDocApi.getAccountGroupID(accountId);
    }

    @When("I verify the account group details returned by the MyDoc API")
    public void verifyGetAccountGroup(DataTable dt) {
        List<Map<String, String>> rows = dt.asMaps(String.class, String.class);
        Map<String, String> getAcctGroupDetailsMap = rows.get(0);
        String actualVal = null;
        for (String key : getAcctGroupDetailsMap.keySet()) {
            if (key.contains("data")) {
                String[] parts = key.split("->");
                if (parts.length == 2) {
                    actualVal = getAcctGroupDetails.jsonPath().get("data." + parts[1]).toString();
                } else if (parts.length == 3) {
                    actualVal = getAcctGroupDetails.jsonPath().get("data." + parts[1] + "." + parts[2]).toString();
                }
                Assert.assertEquals(actualVal, configvariable.expandValue(getAcctGroupDetailsMap.get(key)), configvariable.expandValue(getAcctGroupDetailsMap.get(key)) + " value is present in response");
            } else if (key.contains("code")) {
                actualVal = getAcctGroupDetails.jsonPath().get("code").toString();
                Assert.assertEquals(actualVal, configvariable.expandValue(getAcctGroupDetailsMap.get(key)), configvariable.expandValue(getAcctGroupDetailsMap.get(key)) + " value is present in response");
            } else if (key.contains("message")) {
                actualVal = getAcctGroupDetails.jsonPath().get("message").toString();
                Assert.assertEquals(actualVal, configvariable.expandValue(getAcctGroupDetailsMap.get(key)), configvariable.expandValue(getAcctGroupDetailsMap.get(key)) + " value is present in response");
            }
        }
    }

    @When("I update my account details using above mentioned values through MyDoc API for \"([^\"]*)\"")
    public void updateAcctDetails(String accountId) {
        updateAcctDetails = myDocApi.updateAccountDetails(accountId);
    }

    @When("I verify the following details are present in the response of update account API")
    public void verifyPutAccount(DataTable dt) {
        List<Map<String, String>> rows = dt.asMaps(String.class, String.class);
        Map<String, String> updateAcctDetailsMap = rows.get(0);
        String actualVal = null;
        for (String key : updateAcctDetailsMap.keySet()) {
            if (key.contains("data")) {
                String[] parts = key.split("->");
                if (parts.length == 2) {
                    actualVal = updateAcctDetails.jsonPath().get("data." + parts[1]).toString();
                } else if (parts.length == 3) {
                    actualVal = updateAcctDetails.jsonPath().get("data." + parts[1] + "." + parts[2]).toString();
                }
                Assert.assertEquals(actualVal, configvariable.expandValue(updateAcctDetailsMap.get(key)), configvariable.expandValue(updateAcctDetailsMap.get(key)) + " value is present in response");
            } else if (key.contains("code")) {
                actualVal = updateAcctDetails.jsonPath().get("code").toString();
                Assert.assertEquals(actualVal, configvariable.expandValue(updateAcctDetailsMap.get(key)), configvariable.expandValue(updateAcctDetailsMap.get(key)) + " value is present in response");
            } else if (key.contains("message")) {
                actualVal = updateAcctDetails.jsonPath().get("message").toString();
                Assert.assertEquals(actualVal, configvariable.expandValue(updateAcctDetailsMap.get(key)), configvariable.expandValue(updateAcctDetailsMap.get(key)) + " value is present in response");
            }
        }
    }

    @When("I verify the following details are present in the response of create case notes API")
    public void verifyCreateCaseNote(DataTable dt) {
        List<Map<String, String>> rows = dt.asMaps(String.class, String.class);
        Map<String, String> createCaseNoteDetailsMap = rows.get(0);
        String actualVal = null;
        for (String key : createCaseNoteDetailsMap.keySet()) {
            if (key.contains("data")) {
                String[] parts = key.split("->");
                if (parts.length == 2) {
                    actualVal = createCaseNoteDetails.jsonPath().get("data." + parts[1]).toString();
                } else if (parts.length == 3) {
                    actualVal = createCaseNoteDetails.jsonPath().get("data." + parts[1] + "." + parts[2]).toString();
                } else if (parts.length == 4) {
                    actualVal = createCaseNoteDetails.jsonPath().get("data." + parts[1] + "." + parts[2] + "." + parts[3]).toString();
                }
                Assert.assertEquals(actualVal, configvariable.expandValue(createCaseNoteDetailsMap.get(key)), configvariable.expandValue(createCaseNoteDetailsMap.get(key)) + " value is present in response");
            } else if (key.contains("code")) {
                actualVal = createCaseNoteDetails.jsonPath().get("code").toString();
                Assert.assertEquals(actualVal, configvariable.expandValue(createCaseNoteDetailsMap.get(key)), configvariable.expandValue(createCaseNoteDetailsMap.get(key)) + " value is present in response");
            } else if (key.contains("message")) {
                actualVal = createCaseNoteDetails.jsonPath().get("message").toString();
                Assert.assertEquals(actualVal, configvariable.expandValue(createCaseNoteDetailsMap.get(key)), configvariable.expandValue(createCaseNoteDetailsMap.get(key)) + " value is present in response");
            }
        }
    }

    @When("I login to MyDoc using api with admin credentials")
    public void loginToMyDocWithAdminCredential(DataTable adminCredentials) {
        //myDocApi.loginToMyDocWithAdminCredential();
        Map<String, String> adminDetailsMap;
        adminDetailsMap = adminCredentials.asMap(String.class, String.class);
        configvariable.assignValueToVarMap(adminDetailsMap);
        myDocApi.loginToMyDoc(configvariable.getStringVar("ADMIN_EMAIL"), configvariable.getStringVar("ADMIN_PASSWORD"));
    }

    @When("I get the group details using MyDoc API")
    public void getGroup() {
        getGroupDetails = myDocApi.getGroups();
    }

    @When("I verify the group details returned by the MyDoc API")
    public void verifyGetGroup(DataTable dt) {
        List<Map<String, String>> rows = dt.asMaps(String.class, String.class);
        Map<String, String> getGroupDetailsMap = rows.get(0);
        String actualVal = null;
        for (String key : getGroupDetailsMap.keySet()) {
            if (key.contains("data")) {
                String[] parts = key.split("->");
                if (parts.length == 2) {
                    actualVal = getGroupDetails.jsonPath().get("data." + parts[1]).toString();
                } else if (parts.length == 3) {
                    actualVal = getGroupDetails.jsonPath().get("data." + parts[1] + "." + parts[2]).toString();
                }
                Assert.assertEquals(actualVal, configvariable.expandValue(getGroupDetailsMap.get(key)), configvariable.expandValue(getGroupDetailsMap.get(key)) + " value is present in response");
            } else if (key.contains("code")) {
                actualVal = getGroupDetails.jsonPath().get("code").toString();
                Assert.assertEquals(actualVal, configvariable.expandValue(getGroupDetailsMap.get(key)), configvariable.expandValue(getGroupDetailsMap.get(key)) + " value is present in response");
            } else if (key.contains("message")) {
                actualVal = getGroupDetails.jsonPath().get("message").toString();
                Assert.assertEquals(actualVal, configvariable.expandValue(getGroupDetailsMap.get(key)), configvariable.expandValue(getGroupDetailsMap.get(key)) + " value is present in response");
            }
        }
    }

    @When("I login to MyDoc using api with patient credentials")
    public void loginToMyDocWithPatientCredentials(DataTable dt) {
        Map<String, String> patientCredentials;
        patientCredentials = dt.asMap(String.class, String.class);
        //myDocApi.loginToMyDocWithPatientCredential(configvariable.expandValue(patientCredentials.get("PATIENT_EMAIL")), patientCredentials.get("PATIENT_PASSWORD"));
        myDocApi.loginToMyDoc(configvariable.expandValue(patientCredentials.get("PATIENT_EMAIL")), patientCredentials.get("PATIENT_PASSWORD"));

    }

    @When("I verify following details are present in response of create EMC API")
    public void verifyCreateEMCResponse(DataTable dt) {
        List<Map<String, String>> rows = dt.asMaps(String.class, String.class);
        Map<String, String> createEMCDetailsMap = rows.get(0);
        String actualVal = null;
        for (String key : createEMCDetailsMap.keySet()) {
            if (key.contains("data")) {
                String[] parts = key.split("->");
                if (parts.length == 2) {
                    actualVal = createEMCDetails.jsonPath().get("data." + parts[1]).toString();
                } else if (parts.length == 3) {
                    actualVal = createEMCDetails.jsonPath().get("data." + parts[1] + "." + parts[2]).toString();
                }
                Assert.assertEquals(actualVal, configvariable.expandValue(createEMCDetailsMap.get(key)), configvariable.expandValue(createEMCDetailsMap.get(key)) + " value is present in response");
            } else if (key.contains("code")) {
                actualVal = createEMCDetails.jsonPath().get("code").toString();
                Assert.assertEquals(actualVal, configvariable.expandValue(createEMCDetailsMap.get(key)), configvariable.expandValue(createEMCDetailsMap.get(key)) + " value is present in response");
            } else if (key.contains("message")) {
                actualVal = createEMCDetails.jsonPath().get("message").toString();
                Assert.assertEquals(actualVal, configvariable.expandValue(createEMCDetailsMap.get(key)), configvariable.expandValue(createEMCDetailsMap.get(key)) + " value is present in response");
            }
        }
    }

    @When("I verify following details are present in response of send EMC API")
    public void verifySendEMCResponse(DataTable dt) {
        List<Map<String, String>> rows = dt.asMaps(String.class, String.class);
        Map<String, String> sendEMCDetailsMap = rows.get(0);
        String actualVal = null;
        for (String key : sendEMCDetailsMap.keySet()) {
            if (key.contains("data")) {
                String[] parts = key.split("->");
                if (parts.length == 2) {
                    actualVal = sendEMCDetails.jsonPath().get("data." + parts[1]).toString();
                } else if (parts.length == 3) {
                    actualVal = sendEMCDetails.jsonPath().get("data." + parts[1] + "." + parts[2]).toString();
                }
                Assert.assertEquals(actualVal, configvariable.expandValue(sendEMCDetailsMap.get(key)), configvariable.expandValue(sendEMCDetailsMap.get(key)) + " value is present in response");
            } else if (key.contains("code")) {
                actualVal = sendEMCDetails.jsonPath().get("code").toString();
                Assert.assertEquals(actualVal, configvariable.expandValue(sendEMCDetailsMap.get(key)), configvariable.expandValue(sendEMCDetailsMap.get(key)) + " value is present in response");
            } else if (key.contains("message")) {
                actualVal = sendEMCDetails.jsonPath().get("message").toString();
                Assert.assertEquals(actualVal, configvariable.expandValue(sendEMCDetailsMap.get(key)), configvariable.expandValue(sendEMCDetailsMap.get(key)) + " value is present in response");
            }
        }
    }

    @When("I get the available doctor using MyDoc Api")
    public void getAvailableDoctor() {
        getAvailableDoctorDetails = myDocApi.getAvailableDoctor();
    }

    @When("I verify following details are present in response of available doctor API")
    public void verifyAvailableDoctorResponse(DataTable dt) {
        List<Map<String, String>> rows = dt.asMaps(String.class, String.class);
        Map<String, String> getAvailableDoctorDetailsMap = rows.get(0);
        int docCount = ((ArrayList) getAvailableDoctorDetails.jsonPath().get("data")).size();
        boolean flag = docCount > 0;
        Assert.assertTrue(flag, configvariable.expandValue(getAvailableDoctorDetailsMap.get("data")) + " value is present in response");
        String actualCodeVal = getAvailableDoctorDetails.jsonPath().get("code").toString();
        Assert.assertEquals(actualCodeVal, configvariable.expandValue(getAvailableDoctorDetailsMap.get("code")), configvariable.expandValue(getAvailableDoctorDetailsMap.get("code")) + " value is present in response");
        String actualMessageVal = getAvailableDoctorDetails.jsonPath().get("message").toString();
        Assert.assertEquals(actualMessageVal, configvariable.expandValue(getAvailableDoctorDetailsMap.get("message")), configvariable.expandValue(getAvailableDoctorDetailsMap.get("message")) + " value is present in response");
    }

    @When("I create the emergency contact using MyDoc API")
    public void createEmergencyContacts() {
        createEmergencyContactDetails = myDocApi.createEmergencyContacts();
    }

    @When("I verify the following details are present in the response of \"([^\"]*)\" emergency contact API")
    public void verifyEmergencyContactResponse(String operationType, DataTable dt) {
        Response emergencyContactDetail = null;
        if (operationType.equalsIgnoreCase("create")) {
            emergencyContactDetail = createEmergencyContactDetails;
        } else if (operationType.equalsIgnoreCase("update")) {
            emergencyContactDetail = updateEmergencyContactDetails;
        } else if (operationType.equalsIgnoreCase("get")) {
            emergencyContactDetail = getEmergencyContactDetails;
        } else if (operationType.equalsIgnoreCase("delete")) {
            emergencyContactDetail = deleteEmergencyContactDetails;
        }
        List<Map<String, String>> rows = dt.asMaps(String.class, String.class);
        Map<String, String> emergencyContactsDetailsMap = rows.get(0);
        String actualVal = null;
        for (String key : emergencyContactsDetailsMap.keySet()) {
            if (key.contains("data")) {
                String[] parts = key.split("->");
                actualVal = emergencyContactDetail.jsonPath().get("data[0]" + "." + parts[1]).toString();
                Assert.assertEquals(actualVal, configvariable.expandValue(emergencyContactsDetailsMap.get(key)), configvariable.expandValue(emergencyContactsDetailsMap.get(key)) + " value is present in response");
            } else if (key.contains("code")) {
                actualVal = emergencyContactDetail.jsonPath().get("code").toString();
                Assert.assertEquals(actualVal, configvariable.expandValue(emergencyContactsDetailsMap.get(key)), configvariable.expandValue(emergencyContactsDetailsMap.get(key)) + " value is present in response");
            } else if (key.contains("message")) {
                actualVal = emergencyContactDetail.jsonPath().get("message").toString();
                Assert.assertEquals(actualVal, configvariable.expandValue(emergencyContactsDetailsMap.get(key)), configvariable.expandValue(emergencyContactsDetailsMap.get(key)) + " value is present in response");
            }
        }
    }

    @When("I update the emergency contact using MyDoc API")
    public void updateEmergencyContacts() {
        String emergency_contact_id = createEmergencyContactDetails.jsonPath().get("data[0].id").toString();
        configvariable.setStringVariable(emergency_contact_id, "MYDOC_EMERGENCY_CONTACT_ID");
        updateEmergencyContactDetails = myDocApi.updateEmergencyContacts();
    }

    @When("I get the emergency contact using MyDoc API")
    public void getEmergencyContacts() {
        getEmergencyContactDetails = myDocApi.getEmergencyContacts();
    }

    @When("I delete the emergency contact using MyDoc API")
    public void deleteEmergencyContacts() {
        deleteEmergencyContactDetails = myDocApi.deleteEmergencyContacts();
    }

    @When("I get the chat messages \"([^\"]*)\" in the episode using MyDoc API")
    public void getChatResponse(String message) {
        getEpisodeChatMessages = myDocApi.getEpisodeMessages(message);
    }

    @When("I verify following details are present in response of get episode messages API")
    public void verifyGetEpisodeChatMessages(DataTable dt) {
        List<Map<String, String>> rows = dt.asMaps(String.class, String.class);
        Map<String, String> getEpisodeChatMessagesMap = rows.get(0);
        String actualVal = null;
        String chatMsg = null;
        int index = 0;
        int totalMessages = getEpisodeChatMessages.jsonPath().get("total");
        for (String key : getEpisodeChatMessagesMap.keySet()) {
            if (key.contains("data")) {
                String[] parts = key.split("->");
                chatMsg = configvariable.expandValue(getEpisodeChatMessagesMap.get("data->content"));
                for (int iCount = 0; iCount < totalMessages; iCount++) {
                    if (getEpisodeChatMessages.jsonPath().get("data[" + iCount + "].content") == chatMsg) {
                        index = iCount;
                        break;
                    }
                }
                if (parts.length == 2) {
                    actualVal = getEpisodeChatMessages.jsonPath().get("data[" + index + "]" + "." + parts[1]).toString();
                } else if (parts.length == 3) {
                    actualVal = getEpisodeChatMessages.jsonPath().get("data[" + index + "]" + "." + parts[1] + "." + parts[2]).toString();
                }
                Assert.assertEquals(actualVal, configvariable.expandValue(getEpisodeChatMessagesMap.get(key)), configvariable.expandValue(getEpisodeChatMessagesMap.get(key)) + " value is present in response");
            } else if (key.contains("code")) {
                actualVal = getEpisodeChatMessages.jsonPath().get("code").toString();
                Assert.assertEquals(actualVal, configvariable.expandValue(getEpisodeChatMessagesMap.get(key)), configvariable.expandValue(getEpisodeChatMessagesMap.get(key)) + " value is present in response");
            } else if (key.contains("message")) {
                actualVal = getEpisodeChatMessages.jsonPath().get("message").toString();
                Assert.assertEquals(actualVal, configvariable.expandValue(getEpisodeChatMessagesMap.get(key)), configvariable.expandValue(getEpisodeChatMessagesMap.get(key)) + " value is present in response");
            }
        }
    }

    @Then("^I confirm the doctor appointment$")
    public void iConfirmTheDoctorAppointment() {
        myDocApi.getAppointmentId();
        myDocApi.acceptDoctor();

    }

    @And("^Doctor accepts the appointment for the patient$")
    public void doctorAcceptsTheAppointmentForThePatient() {
        myDocApi.getApppointmentIdForPatient();
        acceptAppointmentDetails = myDocApi.doctorAcceptAppointment();
    }


}


//package com.onepulse.app.stepdefinitions.apisteps;
//
//import com.onepulse.app.api.PulseMalinatorApi;
//import com.onepulse.app.utils.MyDocDoctorDetails;
//import com.prudential.tap.config.Configvariable;
//import com.onepulse.app.api.MyDocApi;
//import com.onepulse.app.cucumberhooks.CucumberHook;
//import cucumber.api.DataTable;
//import cucumber.api.java.en.Then;
//import cucumber.api.java.en.When;
//import io.restassured.response.Response;
//import org.testng.Assert;
//
//import java.time.LocalDateTime;
//import java.time.ZoneId;
//import java.util.ArrayList;
//import java.util.Map;
//
//public class MyDocApiSteps {
//    private MyDocApi myDocApi = CucumberHook.context.getBean(MyDocApi.class);
//    private Configvariable configvariable = CucumberHook.context.getBean(Configvariable.class);
//    private MyDocDoctorDetails myDocDoctorDetails = CucumberHook.context.getBean(MyDocDoctorDetails.class);
//    private Response createEpisodeDetails = null;
//    private Response createAppointmentDetails = null;
//    private Response acceptAppointmentDetails = null;
//    private Response rejectAppointmentDetails = null;
//    private Response getAppointmentDetails = null;
//    private Response getAccountDetails = null;
//    private Response getAcctGroupDetails = null;
//    private Response updateAcctDetails = null;
//    private Response createCaseNoteDetails = null;
//    private Response getGroupDetails = null;
//    private Response createEMCDetails = null;
//    private Response sendEMCDetails = null;
//    private Response getEpisodeChatMessages = null;
//    private Response getAvailableDoctorDetails = null;
//    private Response createEmergencyContactDetails = null;
//    private Response updateEmergencyContactDetails = null;
//    private Response getEmergencyContactDetails = null;
//    private Response deleteEmergencyContactDetails = null;
//
//    @When("I login to MyDoc using api with doctor credentials")
//    public void loginToMyDocWithDoctorCredential() {
//
//       myDocApi.loginToMyDoc(configvariable.getStringVar("DoctorUsername"), configvariable.getStringVar("DoctorPassword"));
//
//
//
//
//    }
//
//    @When("Doctor accepts the appointment for the patient \"([^\"]*)\"")
//    public void doctorAcceptAppointment(String patientEmail) {
//        myDocApi.getApppointmentIdForPatient(configvariable.expandValue(patientEmail));
//        acceptAppointmentDetails = myDocApi.doctorAcceptAppointment();
//    }
//
//
//    @When("I login to MyDoc using api with concierge credentials as below")
//    public void loginToMyDocWithConciergeCredential(DataTable conciergeDetails) {
//        Map<String, String> conciergeDetailsMap;
//        conciergeDetailsMap = conciergeDetails.asMap(String.class, String.class);
//        configvariable.assignValueToVarMap(conciergeDetailsMap);
//        myDocApi.loginToMyDoc(configvariable.getStringVar("CONCIERGE_EMAIL"), configvariable.getStringVar("CONCIERGE_PASSWORD"));
//    }
//
//    @When("I get MyDoc Patient ID using API for patient \"([^\"]*)\" into variable \"([^\"]*)\"")
//    public void getPatientIdMyMuyDocAPI(String patientEmail, String patient_id) {
//        configvariable.setStringVariable(myDocApi.getPatientID(patientEmail), patient_id);
//    }
//
//    @When("I create episode using MyDoc API")
//    public void createEpisodeUsingMyDocAPI(DataTable userDetails) {
//        Map<String, String> conciergeDetailsMap;
//        conciergeDetailsMap = userDetails.asMap(String.class, String.class);
//        createEpisodeDetails = myDocApi.createEpisode(configvariable.expandValue(conciergeDetailsMap.get("patient_id")), configvariable.expandValue(conciergeDetailsMap.get("myDoc_UserId")));
//    }
//
//    @When("I verify following details are present in response of create episode API")
//    public void verifyCreateEpisodeResponse(DataTable dt) {
//        Map<String, String> createEpisodeDetailsMap;
//        createEpisodeDetailsMap = dt.asMaps(String.class, String.class).get(0);
//        String actualVal = null;
//        int docIndex = 0;
//        int patientIndex = 0;
//        int totalMembers = ((ArrayList) createEpisodeDetails.jsonPath().get("data.members")).size();
//        for (int iCount = 0; iCount < totalMembers; iCount++) {
//            if (createEpisodeDetails.jsonPath().get("data." + "members[" + iCount + "].id").toString() != null && createEpisodeDetails.jsonPath().get("data." + "members[" + iCount + "].id").toString().equals(configvariable.expandValue("${DoctorId}"))) {
//                docIndex = iCount;
//                break;
//            }
//        }
//        for (int iCount = 0; iCount < totalMembers; iCount++) {
//            if (createEpisodeDetails.jsonPath().get("data." + "members[" + iCount + "].id").toString() != null && createEpisodeDetails.jsonPath().get("data." + "members[" + iCount + "].id").toString().equals(configvariable.expandValue("${PATIENT_ID}"))) {
//                patientIndex = iCount;
//                break;
//            }
//        }
//        for (String key : createEpisodeDetailsMap.keySet()) {
//            if (key.contains("data")) {
//                String[] parts = key.split("->");
//                if (parts[1].contains("members") && parts[2].contains("doctor")) {
//                    actualVal = createEpisodeDetails.jsonPath().get("data." + parts[1] + "[" + docIndex + "]" + "." + parts[3]).toString();
//                } else if (parts[1].contains("members") && parts[2].contains("patient")) {
//                    actualVal = createEpisodeDetails.jsonPath().get("data." + parts[1] + "[" + patientIndex + "]" + "." + parts[3]).toString();
//                } else if (parts.length == 2) {
//                    actualVal = createEpisodeDetails.jsonPath().get("data." + parts[1]).toString();
//                }
//                Assert.assertEquals(actualVal, configvariable.expandValue(createEpisodeDetailsMap.get(key)), configvariable.expandValue(createEpisodeDetailsMap.get(key)) + " value is present in response");
//            } else if (key.contains("code")) {
//                actualVal = createEpisodeDetails.jsonPath().get("code").toString();
//                Assert.assertEquals(actualVal, configvariable.expandValue(createEpisodeDetailsMap.get(key)), configvariable.expandValue(createEpisodeDetailsMap.get(key)) + " value is present in response");
//            } else if (key.contains("message")) {
//                actualVal = createEpisodeDetails.jsonPath().get("message").toString();
//                Assert.assertEquals(actualVal, configvariable.expandValue(createEpisodeDetailsMap.get(key)), configvariable.expandValue(createEpisodeDetailsMap.get(key)) + " value is present in response");
//            }
//        }
//
//    }
//
//    @When("I send message \"([^\"]*)\" to patient using MyDoc API")
//    public void sendMessageToPatientUsingMyDocAPI(String message) {
//        myDocApi.sendEpisodeMessage(configvariable.expandValue(message));
//    }
//
//    @When("I create eMC for patient using MyDoc API")
//    public void createEMCForPatient() {
//        createEMCDetails = myDocApi.createEmc();
//    }
//
//    @When("I send eMC to the patient using MyDoc API")
//    public void sendEMCToPatient() {
//        sendEMCDetails = myDocApi.sendEmc();
//    }
//
//    @When("I create case note for patient using below details with MyDoc API")
//    public void createCaseNoteForPatient(DataTable caseDetails) {
//        Map<String, String> variableMap;
//        variableMap = caseDetails.asMap(String.class, String.class);
//        configvariable.assignValueToVarMap(variableMap);
//        createCaseNoteDetails = myDocApi.createCaseNoteForPatient();
//    }
//
//    @When("I close the consultation using MyDoc Api")
//    public void closeConsultationForPatient() {
//        myDocApi.closeConsultationForPatient();
//    }
//
//    @When("Doctor rejects the appointment for the patient \"([^\"]*)\"")
//    public void doctoRejectAppointment(String patientEmail) {
//        myDocApi.getApppointmentIdForPatient(configvariable.expandValue(patientEmail));
//        rejectAppointmentDetails = myDocApi.doctorRejectAppointment();
//    }
//
//    @When("I create the appointment using MyDoc Api")
//    public void createDoctorAppointment() {
//        LocalDateTime now = LocalDateTime.now().plusHours(1);
//        String formattedDate = configvariable.formatDateAndTime("yyyy-MM-dd", now);
//        String formattedTime = configvariable.formatDateAndTimeWithZone("HH:mm:ss", ZoneId.of("Asia/Singapore"), now);
//        configvariable.setStringVariable(formattedDate, "FROM_DATE");
//        configvariable.setStringVariable(formattedTime, "START_TIME");
//        createAppointmentDetails = myDocApi.createAppointment();
//    }
//
//    @When("I verify following details are present in response of create appointment API")
//    public void verifyCreateAppointmentResponse(DataTable dt) {
//        Map<String, String> createAppointmentDetailsMap;
//        createAppointmentDetailsMap = dt.asMaps(String.class, String.class).get(0);
//        String actualVal = null;
//        for (String key : createAppointmentDetailsMap.keySet()) {
//            if (key.contains("data")) {
//                String[] parts = key.split("->");
//                if (parts.length == 2) {
//                    actualVal = createAppointmentDetails.jsonPath().get("data." + parts[1]).toString();
//                } else if (parts.length == 3) {
//                    actualVal = createAppointmentDetails.jsonPath().get("data." + parts[1] + "." + parts[2]).toString();
//                }
//                Assert.assertEquals(actualVal, configvariable.expandValue(createAppointmentDetailsMap.get(key)), configvariable.expandValue(createAppointmentDetailsMap.get(key)) + " value is present in response");
//            } else if (key.contains("code")) {
//                actualVal = createAppointmentDetails.jsonPath().get("code").toString();
//                Assert.assertEquals(actualVal, configvariable.expandValue(createAppointmentDetailsMap.get(key)), configvariable.expandValue(createAppointmentDetailsMap.get(key)) + " value is present in response");
//            } else if (key.contains("message")) {
//                actualVal = createAppointmentDetails.jsonPath().get("message").toString();
//                Assert.assertEquals(actualVal, configvariable.expandValue(createAppointmentDetailsMap.get(key)), configvariable.expandValue(createAppointmentDetailsMap.get(key)) + " value is present in response");
//            }
//        }
//    }
//
//    @When("I verify following details are present in response of accept appointment API")
//    public void verifyAcceptAppointmentResponse(DataTable dt) {
//        Map<String, String> acceptAppointmentDetailsMap;
//        acceptAppointmentDetailsMap = dt.asMaps(String.class, String.class).get(0);
//        String actualVal = null;
//        for (String key : acceptAppointmentDetailsMap.keySet()) {
//            if (key.contains("data")) {
//                String[] parts = key.split("->");
//                if (parts.length == 2) {
//                    actualVal = acceptAppointmentDetails.jsonPath().get("data." + parts[1]).toString();
//                } else if (parts.length == 3) {
//                    actualVal = acceptAppointmentDetails.jsonPath().get("data." + parts[1] + "." + parts[2]).toString();
//                }
//                Assert.assertEquals(actualVal, configvariable.expandValue(acceptAppointmentDetailsMap.get(key)), configvariable.expandValue(acceptAppointmentDetailsMap.get(key)) + " value is present in response");
//            } else if (key.contains("code")) {
//                actualVal = acceptAppointmentDetails.jsonPath().get("code").toString();
//                Assert.assertEquals(actualVal, configvariable.expandValue(acceptAppointmentDetailsMap.get(key)), configvariable.expandValue(acceptAppointmentDetailsMap.get(key)) + " value is present in response");
//            } else if (key.contains("message")) {
//                actualVal = acceptAppointmentDetails.jsonPath().get("message").toString();
//                Assert.assertEquals(actualVal, configvariable.expandValue(acceptAppointmentDetailsMap.get(key)), configvariable.expandValue(acceptAppointmentDetailsMap.get(key)) + " value is present in response");
//            }
//        }
//    }
//
//    @When("I verify following details are present in response of reject appointment API")
//    public void verifyRejectAppointmentResponse(DataTable dt) {
//        Map<String, String> rejectAppointmentDetailsMap;
//        rejectAppointmentDetailsMap = dt.asMaps(String.class, String.class).get(0);
//        String actualVal = null;
//        for (String key : rejectAppointmentDetailsMap.keySet()) {
//            if (key.contains("data")) {
//                String[] parts = key.split("->");
//                if (parts.length == 2) {
//                    actualVal = rejectAppointmentDetails.jsonPath().get("data." + parts[1]).toString();
//                } else if (parts.length == 3) {
//                    actualVal = rejectAppointmentDetails.jsonPath().get("data." + parts[1] + "." + parts[2]).toString();
//                }
//                Assert.assertEquals(actualVal, configvariable.expandValue(rejectAppointmentDetailsMap.get(key)), configvariable.expandValue(rejectAppointmentDetailsMap.get(key)) + " value is present in response");
//            } else if (key.contains("code")) {
//                actualVal = rejectAppointmentDetails.jsonPath().get("code").toString();
//                Assert.assertEquals(actualVal, configvariable.expandValue(rejectAppointmentDetailsMap.get(key)), configvariable.expandValue(rejectAppointmentDetailsMap.get(key)) + " value is present in response");
//            } else if (key.contains("message")) {
//                actualVal = rejectAppointmentDetails.jsonPath().get("message").toString();
//                Assert.assertEquals(actualVal, configvariable.expandValue(rejectAppointmentDetailsMap.get(key)), configvariable.expandValue(rejectAppointmentDetailsMap.get(key)) + " value is present in response");
//            }
//        }
//    }
//
//    @When("I create the patient using MyDoc Api")
//    public void createPatient() {
//        myDocApi.createPatient();
//    }
//
//    @When("I add the NRIC to patient using MyDoc APi")
//    public void addNRIC() {
//        myDocApi.addNricToPatient();
//    }
//
//    @When("I get the appointment detail for patient \"([^\"]*)\" MyDoc Api")
//    public void getAppointmentResponse(String patientEmail) {
//        getAppointmentDetails = myDocApi.getApppointmentIdForPatient(configvariable.expandValue(patientEmail));
//    }
//
//    @When("I verify following details are present in response of get appointment API")
//    public void verifyGetAppointmentResponseForPatient(DataTable dt) {
//        Map<String, String> getAppointmentDetailsMap;
//        getAppointmentDetailsMap = dt.asMaps(String.class, String.class).get(0);
//        String actualVal = null;
//        int index = 0;
//        for (String key : getAppointmentDetailsMap.keySet()) {
//            if (key.contains("data")) {
//                int totalAppointments = getAppointmentDetails.jsonPath().get("total");
//                for (int iCount = 0; iCount < totalAppointments; iCount++) {
//                    if (getAppointmentDetails.jsonPath().get("data[" + iCount + "].patient.email") != null && getAppointmentDetails.jsonPath().get("data[" + iCount + "].patient.email").equals(configvariable.expandValue("${PATIENT_EMAIL}").toLowerCase())) {
//                        index = iCount;
//                        break;
//                    }
//                }
//                String[] parts = key.split("->");
//                if (parts.length == 2) {
//                    actualVal = getAppointmentDetails.jsonPath().get("data[" + index + "]" + "." + parts[1]).toString();
//                } else if (parts.length == 3) {
//                    actualVal = getAppointmentDetails.jsonPath().get("data[" + index + "]" + "." + parts[1] + "." + parts[2]).toString();
//                }
//                Assert.assertEquals(actualVal, configvariable.expandValue(getAppointmentDetailsMap.get(key)), configvariable.expandValue(getAppointmentDetailsMap.get(key)) + " value is present in response");
//            } else if (key.contains("code")) {
//                actualVal = getAppointmentDetails.jsonPath().get("code").toString();
//                Assert.assertEquals(actualVal, configvariable.expandValue(getAppointmentDetailsMap.get(key)), configvariable.expandValue(getAppointmentDetailsMap.get(key)) + " value is present in response");
//            } else if (key.contains("message")) {
//                actualVal = getAppointmentDetails.jsonPath().get("message").toString();
//                Assert.assertEquals(actualVal, configvariable.expandValue(getAppointmentDetailsMap.get(key)), configvariable.expandValue(getAppointmentDetailsMap.get(key)) + " value is present in response");
//            }
//        }
//    }
//
//    @When("I get the details using MyDoc Api for account id \"([^\"]*)\"")
//    public void getAccount(String accountId) {
//        getAccountDetails = myDocApi.getAccountID(accountId);
//    }
//
//    @When("I verify the account details returned by the MyDoc API")
//    public void verifyGetAccount(DataTable dt) {
//        Map<String, String> getAccountDetailsMap;
//        getAccountDetailsMap = dt.asMaps(String.class, String.class).get(0);
//        String actualVal = null;
//        for (String key : getAccountDetailsMap.keySet()) {
//            if (key.contains("data")) {
//                String[] parts = key.split("->");
//                if (parts.length == 2) {
//                    actualVal = getAccountDetails.jsonPath().get("data." + parts[1]).toString();
//                } else if (parts.length == 3) {
//                    actualVal = getAccountDetails.jsonPath().get("data." + parts[1] + "." + parts[2]).toString();
//                }
//                Assert.assertEquals(actualVal, configvariable.expandValue(getAccountDetailsMap.get(key)), configvariable.expandValue(getAccountDetailsMap.get(key)) + " value is present in response");
//            } else if (key.contains("code")) {
//                actualVal = getAccountDetails.jsonPath().get("code").toString();
//                Assert.assertEquals(actualVal, configvariable.expandValue(getAccountDetailsMap.get(key)), configvariable.expandValue(getAccountDetailsMap.get(key)) + " value is present in response");
//            } else if (key.contains("message")) {
//                actualVal = getAccountDetails.jsonPath().get("message").toString();
//                Assert.assertEquals(actualVal, configvariable.expandValue(getAccountDetailsMap.get(key)), configvariable.expandValue(getAccountDetailsMap.get(key)) + " value is present in response");
//            }
//        }
//    }
//
//    @When("I get the group details using MyDoc Api for account id \"([^\"]*)\"")
//    public void getAccountGroup(String accountId) {
//        getAcctGroupDetails = myDocApi.getAccountGroupID(accountId);
//    }
//
//    @When("I verify the account group details returned by the MyDoc API")
//    public void verifyGetAccountGroup(DataTable dt) {
//        Map<String, String> getAcctGroupDetailsMap;
//        getAcctGroupDetailsMap = dt.asMaps(String.class, String.class).get(0);
//        String actualVal = null;
//        for (String key : getAcctGroupDetailsMap.keySet()) {
//            if (key.contains("data")) {
//                String[] parts = key.split("->");
//                if (parts.length == 2) {
//                    actualVal = getAcctGroupDetails.jsonPath().get("data." + parts[1]).toString();
//                } else if (parts.length == 3) {
//                    actualVal = getAcctGroupDetails.jsonPath().get("data." + parts[1] + "." + parts[2]).toString();
//                }
//                Assert.assertEquals(actualVal, configvariable.expandValue(getAcctGroupDetailsMap.get(key)), configvariable.expandValue(getAcctGroupDetailsMap.get(key)) + " value is present in response");
//            } else if (key.contains("code")) {
//                actualVal = getAcctGroupDetails.jsonPath().get("code").toString();
//                Assert.assertEquals(actualVal, configvariable.expandValue(getAcctGroupDetailsMap.get(key)), configvariable.expandValue(getAcctGroupDetailsMap.get(key)) + " value is present in response");
//            } else if (key.contains("message")) {
//                actualVal = getAcctGroupDetails.jsonPath().get("message").toString();
//                Assert.assertEquals(actualVal, configvariable.expandValue(getAcctGroupDetailsMap.get(key)), configvariable.expandValue(getAcctGroupDetailsMap.get(key)) + " value is present in response");
//            }
//        }
//    }
//
//    @When("I update my account details using above mentioned values through MyDoc API for \"([^\"]*)\"")
//    public void updateAcctDetails(String accountId) {
//        updateAcctDetails = myDocApi.updateAccountDetails(accountId);
//    }
//
//    @When("I verify the following details are present in the response of update account API")
//    public void verifyPutAccount(DataTable dt) {
//        Map<String, String> updateAcctDetailsMap;
//        updateAcctDetailsMap = dt.asMaps(String.class, String.class).get(0);
//        String actualVal = null;
//        for (String key : updateAcctDetailsMap.keySet()) {
//            if (key.contains("data")) {
//                String[] parts = key.split("->");
//                if (parts.length == 2) {
//                    actualVal = updateAcctDetails.jsonPath().get("data." + parts[1]).toString();
//                } else if (parts.length == 3) {
//                    actualVal = updateAcctDetails.jsonPath().get("data." + parts[1] + "." + parts[2]).toString();
//                }
//                Assert.assertEquals(actualVal, configvariable.expandValue(updateAcctDetailsMap.get(key)), configvariable.expandValue(updateAcctDetailsMap.get(key)) + " value is present in response");
//            } else if (key.contains("code")) {
//                actualVal = updateAcctDetails.jsonPath().get("code").toString();
//                Assert.assertEquals(actualVal, configvariable.expandValue(updateAcctDetailsMap.get(key)), configvariable.expandValue(updateAcctDetailsMap.get(key)) + " value is present in response");
//            } else if (key.contains("message")) {
//                actualVal = updateAcctDetails.jsonPath().get("message").toString();
//                Assert.assertEquals(actualVal, configvariable.expandValue(updateAcctDetailsMap.get(key)), configvariable.expandValue(updateAcctDetailsMap.get(key)) + " value is present in response");
//            }
//        }
//    }
//
//    @When("I verify the following details are present in the response of create case notes API")
//    public void verifyCreateCaseNote(DataTable dt) {
//        Map<String, String> createCaseNoteDetailsMap;
//        createCaseNoteDetailsMap = dt.asMaps(String.class, String.class).get(0);
//        String actualVal = null;
//        for (String key : createCaseNoteDetailsMap.keySet()) {
//            if (key.contains("data")) {
//                String[] parts = key.split("->");
//                if (parts.length == 2) {
//                    actualVal = createCaseNoteDetails.jsonPath().get("data." + parts[1]).toString();
//                } else if (parts.length == 3) {
//                    actualVal = createCaseNoteDetails.jsonPath().get("data." + parts[1] + "." + parts[2]).toString();
//                } else if (parts.length == 4) {
//                    actualVal = createCaseNoteDetails.jsonPath().get("data." + parts[1] + "." + parts[2] + "." + parts[3]).toString();
//                }
//                Assert.assertEquals(actualVal, configvariable.expandValue(createCaseNoteDetailsMap.get(key)), configvariable.expandValue(createCaseNoteDetailsMap.get(key)) + " value is present in response");
//            } else if (key.contains("code")) {
//                actualVal = createCaseNoteDetails.jsonPath().get("code").toString();
//                Assert.assertEquals(actualVal, configvariable.expandValue(createCaseNoteDetailsMap.get(key)), configvariable.expandValue(createCaseNoteDetailsMap.get(key)) + " value is present in response");
//            } else if (key.contains("message")) {
//                actualVal = createCaseNoteDetails.jsonPath().get("message").toString();
//                Assert.assertEquals(actualVal, configvariable.expandValue(createCaseNoteDetailsMap.get(key)), configvariable.expandValue(createCaseNoteDetailsMap.get(key)) + " value is present in response");
//            }
//        }
//    }
//
//    @When("I login to MyDoc using api with admin credentials")
//    public void loginToMyDocWithAdminCredential(DataTable adminCredentials) {
//        //myDocApi.loginToMyDocWithAdminCredential();
//        Map<String, String> adminDetailsMap;
//        adminDetailsMap = adminCredentials.asMap(String.class, String.class);
//        configvariable.assignValueToVarMap(adminDetailsMap);
//        myDocApi.loginToMyDoc(configvariable.getStringVar("ADMIN_EMAIL"), configvariable.getStringVar("ADMIN_PASSWORD"));
//    }
//
//    @When("I get the group details using MyDoc API")
//    public void getGroup() {
//        getGroupDetails = myDocApi.getGroups();
//    }
//
//    @When("I verify the group details returned by the MyDoc API")
//    public void verifyGetGroup(DataTable dt) {
//        Map<String, String> getGroupDetailsMap;
//        getGroupDetailsMap = dt.asMaps(String.class, String.class).get(0);
//        String actualVal = null;
//        for (String key : getGroupDetailsMap.keySet()) {
//            if (key.contains("data")) {
//                String[] parts = key.split("->");
//                if (parts.length == 2) {
//                    actualVal = getGroupDetails.jsonPath().get("data." + parts[1]).toString();
//                } else if (parts.length == 3) {
//                    actualVal = getGroupDetails.jsonPath().get("data." + parts[1] + "." + parts[2]).toString();
//                }
//                Assert.assertEquals(actualVal, configvariable.expandValue(getGroupDetailsMap.get(key)), configvariable.expandValue(getGroupDetailsMap.get(key)) + " value is present in response");
//            } else if (key.contains("code")) {
//                actualVal = getGroupDetails.jsonPath().get("code").toString();
//                Assert.assertEquals(actualVal, configvariable.expandValue(getGroupDetailsMap.get(key)), configvariable.expandValue(getGroupDetailsMap.get(key)) + " value is present in response");
//            } else if (key.contains("message")) {
//                actualVal = getGroupDetails.jsonPath().get("message").toString();
//                Assert.assertEquals(actualVal, configvariable.expandValue(getGroupDetailsMap.get(key)), configvariable.expandValue(getGroupDetailsMap.get(key)) + " value is present in response");
//            }
//        }
//    }
//
//    @When("I login to MyDoc using api with patient credentials")
//    public void loginToMyDocWithPatientCredentials(DataTable dt) {
//        Map<String, String> patientCredentials;
//        patientCredentials = dt.asMap(String.class, String.class);
//        //myDocApi.loginToMyDocWithPatientCredential(configvariable.expandValue(patientCredentials.get("PATIENT_EMAIL")), patientCredentials.get("PATIENT_PASSWORD"));
//        myDocApi.loginToMyDoc(configvariable.expandValue(patientCredentials.get("PATIENT_EMAIL")), patientCredentials.get("PATIENT_PASSWORD"));
//
//    }
//
//    @When("I verify following details are present in response of create EMC API")
//    public void verifyCreateEMCResponse(DataTable dt) {
//        Map<String, String> createEMCDetailsMap;
//        createEMCDetailsMap = dt.asMaps(String.class, String.class).get(0);
//        String actualVal = null;
//        for (String key : createEMCDetailsMap.keySet()) {
//            if (key.contains("data")) {
//                String[] parts = key.split("->");
//                if (parts.length == 2) {
//                    actualVal = createEMCDetails.jsonPath().get("data." + parts[1]).toString();
//                } else if (parts.length == 3) {
//                    actualVal = createEMCDetails.jsonPath().get("data." + parts[1] + "." + parts[2]).toString();
//                }
//                Assert.assertEquals(actualVal, configvariable.expandValue(createEMCDetailsMap.get(key)), configvariable.expandValue(createEMCDetailsMap.get(key)) + " value is present in response");
//            } else if (key.contains("code")) {
//                actualVal = createEMCDetails.jsonPath().get("code").toString();
//                Assert.assertEquals(actualVal, configvariable.expandValue(createEMCDetailsMap.get(key)), configvariable.expandValue(createEMCDetailsMap.get(key)) + " value is present in response");
//            } else if (key.contains("message")) {
//                actualVal = createEMCDetails.jsonPath().get("message").toString();
//                Assert.assertEquals(actualVal, configvariable.expandValue(createEMCDetailsMap.get(key)), configvariable.expandValue(createEMCDetailsMap.get(key)) + " value is present in response");
//            }
//        }
//    }
//
//    @When("I verify following details are present in response of send EMC API")
//    public void verifySendEMCResponse(DataTable dt) {
//        Map<String, String> sendEMCDetailsMap;
//        sendEMCDetailsMap = dt.asMaps(String.class, String.class).get(0);
//        String actualVal = null;
//        for (String key : sendEMCDetailsMap.keySet()) {
//            if (key.contains("data")) {
//                String[] parts = key.split("->");
//                if (parts.length == 2) {
//                    actualVal = sendEMCDetails.jsonPath().get("data." + parts[1]).toString();
//                } else if (parts.length == 3) {
//                    actualVal = sendEMCDetails.jsonPath().get("data." + parts[1] + "." + parts[2]).toString();
//                }
//                Assert.assertEquals(actualVal, configvariable.expandValue(sendEMCDetailsMap.get(key)), configvariable.expandValue(sendEMCDetailsMap.get(key)) + " value is present in response");
//            } else if (key.contains("code")) {
//                actualVal = sendEMCDetails.jsonPath().get("code").toString();
//                Assert.assertEquals(actualVal, configvariable.expandValue(sendEMCDetailsMap.get(key)), configvariable.expandValue(sendEMCDetailsMap.get(key)) + " value is present in response");
//            } else if (key.contains("message")) {
//                actualVal = sendEMCDetails.jsonPath().get("message").toString();
//                Assert.assertEquals(actualVal, configvariable.expandValue(sendEMCDetailsMap.get(key)), configvariable.expandValue(sendEMCDetailsMap.get(key)) + " value is present in response");
//            }
//        }
//    }
//
//    @When("I get the available doctor using MyDoc Api")
//    public void getAvailableDoctor() {
//        getAvailableDoctorDetails = myDocApi.getAvailableDoctor();
//    }
//
//    @When("I verify following details are present in response of available doctor API")
//    public void verifyAvailableDoctorResponse(DataTable dt) {
//        Map<String, String> getAvailableDoctorDetailsMap;
//        getAvailableDoctorDetailsMap = dt.asMaps(String.class, String.class).get(0);
//        int docCount = ((ArrayList) getAvailableDoctorDetails.jsonPath().get("data")).size();
//        boolean flag = docCount > 0;
//        Assert.assertTrue(flag, configvariable.expandValue(getAvailableDoctorDetailsMap.get("data")) + " value is present in response");
//        String actualCodeVal = getAvailableDoctorDetails.jsonPath().get("code").toString();
//        Assert.assertEquals(actualCodeVal, configvariable.expandValue(getAvailableDoctorDetailsMap.get("code")), configvariable.expandValue(getAvailableDoctorDetailsMap.get("code")) + " value is present in response");
//        String actualMessageVal = getAvailableDoctorDetails.jsonPath().get("message").toString();
//        Assert.assertEquals(actualMessageVal, configvariable.expandValue(getAvailableDoctorDetailsMap.get("message")), configvariable.expandValue(getAvailableDoctorDetailsMap.get("message")) + " value is present in response");
//    }
//
//    @When("I create the emergency contact using MyDoc API")
//    public void createEmergencyContacts() {
//        createEmergencyContactDetails = myDocApi.createEmergencyContacts();
//    }
//
//    @When("I verify the following details are present in the response of \"([^\"]*)\" emergency contact API")
//    public void verifyEmergencyContactResponse(String operationType,DataTable dt) {
//        Response emergencyContactDetail = null;
//        if(operationType.equalsIgnoreCase("create")){
//            emergencyContactDetail = createEmergencyContactDetails;
//        }
//        else if(operationType.equalsIgnoreCase("update")){
//            emergencyContactDetail = updateEmergencyContactDetails;
//        }
//        else if(operationType.equalsIgnoreCase("get")){
//            emergencyContactDetail = getEmergencyContactDetails;
//        }
//        else if(operationType.equalsIgnoreCase("delete")){
//            emergencyContactDetail = deleteEmergencyContactDetails;
//        }
//        Map<String, String> emergencyContactsDetailsMap;
//        emergencyContactsDetailsMap = dt.asMaps(String.class, String.class).get(0);
//        String actualVal = null;
//        for (String key : emergencyContactsDetailsMap.keySet()) {
//            if (key.contains("data")) {
//                String[] parts = key.split("->");
//                actualVal = emergencyContactDetail.jsonPath().get("data[0]" + "." + parts[1]).toString();
//                Assert.assertEquals(actualVal, configvariable.expandValue(emergencyContactsDetailsMap.get(key)), configvariable.expandValue(emergencyContactsDetailsMap.get(key)) + " value is present in response");
//            } else if (key.contains("code")) {
//                actualVal = emergencyContactDetail.jsonPath().get("code").toString();
//                Assert.assertEquals(actualVal, configvariable.expandValue(emergencyContactsDetailsMap.get(key)), configvariable.expandValue(emergencyContactsDetailsMap.get(key)) + " value is present in response");
//            } else if (key.contains("message")) {
//                actualVal = emergencyContactDetail.jsonPath().get("message").toString();
//                Assert.assertEquals(actualVal, configvariable.expandValue(emergencyContactsDetailsMap.get(key)), configvariable.expandValue(emergencyContactsDetailsMap.get(key)) + " value is present in response");
//            }
//        }
//    }
//
//    @When("I update the emergency contact using MyDoc API")
//    public void updateEmergencyContacts() {
//        String emergency_contact_id = createEmergencyContactDetails.jsonPath().get("data[0].id").toString();
//        configvariable.setStringVariable(emergency_contact_id, "MYDOC_EMERGENCY_CONTACT_ID");
//        updateEmergencyContactDetails = myDocApi.updateEmergencyContacts();
//    }
//
//    @When("I get the emergency contact using MyDoc API")
//    public void getEmergencyContacts() {
//        getEmergencyContactDetails = myDocApi.getEmergencyContacts();
//    }
//
//    @When("I delete the emergency contact using MyDoc API")
//    public void deleteEmergencyContacts() {
//        deleteEmergencyContactDetails = myDocApi.deleteEmergencyContacts();
//    }
//
//    @When("I get the chat messages \"([^\"]*)\" in the episode using MyDoc API")
//    public void getChatResponse(String message) {
//        getEpisodeChatMessages = myDocApi.getEpisodeMessages(message);
//    }
//
//    @When("I verify following details are present in response of get episode messages API")
//    public void verifyGetEpisodeChatMessages(DataTable dt) {
//        Map<String, String> getEpisodeChatMessagesMap;
//        getEpisodeChatMessagesMap = dt.asMaps(String.class, String.class).get(0);
//        String actualVal = null;
//        String chatMsg = null;
//        int index = 0;
//        int totalMessages = getEpisodeChatMessages.jsonPath().get("total");
//        for (String key : getEpisodeChatMessagesMap.keySet()) {
//            if (key.contains("data")) {
//                String[] parts = key.split("->");
//                chatMsg = configvariable.expandValue(getEpisodeChatMessagesMap.get("data->content"));
//                for (int iCount = 0; iCount < totalMessages; iCount++) {
//                    if (getEpisodeChatMessages.jsonPath().get("data[" + iCount + "].content") == chatMsg) {
//                        index = iCount;
//                        break;
//                    }
//                }
//                if (parts.length == 2) {
//                    actualVal = getEpisodeChatMessages.jsonPath().get("data[" + index + "]" + "." + parts[1]).toString();
//                } else if (parts.length == 3) {
//                    actualVal = getEpisodeChatMessages.jsonPath().get("data[" + index + "]" + "." + parts[1] + "." + parts[2]).toString();
//                }
//                Assert.assertEquals(actualVal, configvariable.expandValue(getEpisodeChatMessagesMap.get(key)), configvariable.expandValue(getEpisodeChatMessagesMap.get(key)) + " value is present in response");
//            } else if (key.contains("code")) {
//                actualVal = getEpisodeChatMessages.jsonPath().get("code").toString();
//                Assert.assertEquals(actualVal, configvariable.expandValue(getEpisodeChatMessagesMap.get(key)), configvariable.expandValue(getEpisodeChatMessagesMap.get(key)) + " value is present in response");
//            } else if (key.contains("message")) {
//                actualVal = getEpisodeChatMessages.jsonPath().get("message").toString();
//                Assert.assertEquals(actualVal, configvariable.expandValue(getEpisodeChatMessagesMap.get(key)), configvariable.expandValue(getEpisodeChatMessagesMap.get(key)) + " value is present in response");
//            }
//        }
//    }
//
//
//    @Then("^I confirm the doctor appointment$")
//    public void iConfirmTheDoctorAppointment() {
//        myDocApi.getAppointmentId();
//        myDocApi.acceptDoctor();
//
//
//    }
//}
//
//
//
//

//package com.onepulse.app.stepdefinitions.apisteps;
//
//import com.onepulse.app.api.PulseMalinatorApi;
//import com.onepulse.app.utils.MyDocDoctorDetails;
//import com.prudential.tap.config.Configvariable;
//import com.onepulse.app.api.MyDocApi;
//import com.onepulse.app.cucumberhooks.CucumberHook;
//import cucumber.api.DataTable;
//import cucumber.api.java.en.Then;
//import cucumber.api.java.en.When;
//import io.restassured.response.Response;
//import org.testng.Assert;
//
//import java.time.LocalDateTime;
//import java.time.ZoneId;
//import java.util.ArrayList;
//import java.util.Map;
//
//public class MyDocApiSteps {
//    private MyDocApi myDocApi = CucumberHook.context.getBean(MyDocApi.class);
//    private Configvariable configvariable = CucumberHook.context.getBean(Configvariable.class);
//    private MyDocDoctorDetails myDocDoctorDetails = CucumberHook.context.getBean(MyDocDoctorDetails.class);
//    private Response createEpisodeDetails = null;
//    private Response createAppointmentDetails = null;
//    private Response acceptAppointmentDetails = null;
//    private Response rejectAppointmentDetails = null;
//    private Response getAppointmentDetails = null;
//    private Response getAccountDetails = null;
//    private Response getAcctGroupDetails = null;
//    private Response updateAcctDetails = null;
//    private Response createCaseNoteDetails = null;
//    private Response getGroupDetails = null;
//    private Response createEMCDetails = null;
//    private Response sendEMCDetails = null;
//    private Response getEpisodeChatMessages = null;
//    private Response getAvailableDoctorDetails = null;
//    private Response createEmergencyContactDetails = null;
//    private Response updateEmergencyContactDetails = null;
//    private Response getEmergencyContactDetails = null;
//    private Response deleteEmergencyContactDetails = null;
//
//    @When("I login to MyDoc using api with doctor credentials")
//    public void loginToMyDocWithDoctorCredential() {
//
//       myDocApi.loginToMyDoc(configvariable.getStringVar("DoctorUsername"), configvariable.getStringVar("DoctorPassword"));
//
//
//
//
//    }
//
//    @When("Doctor accepts the appointment for the patient \"([^\"]*)\"")
//    public void doctorAcceptAppointment(String patientEmail) {
//        myDocApi.getApppointmentIdForPatient(configvariable.expandValue(patientEmail));
//        acceptAppointmentDetails = myDocApi.doctorAcceptAppointment();
//    }
//
//
//    @When("I login to MyDoc using api with concierge credentials as below")
//    public void loginToMyDocWithConciergeCredential(DataTable conciergeDetails) {
//        Map<String, String> conciergeDetailsMap;
//        conciergeDetailsMap = conciergeDetails.asMap(String.class, String.class);
//        configvariable.assignValueToVarMap(conciergeDetailsMap);
//        myDocApi.loginToMyDoc(configvariable.getStringVar("CONCIERGE_EMAIL"), configvariable.getStringVar("CONCIERGE_PASSWORD"));
//    }
//
//    @When("I get MyDoc Patient ID using API for patient \"([^\"]*)\" into variable \"([^\"]*)\"")
//    public void getPatientIdMyMuyDocAPI(String patientEmail, String patient_id) {
//        configvariable.setStringVariable(myDocApi.getPatientID(patientEmail), patient_id);
//    }
//
//    @When("I create episode using MyDoc API")
//    public void createEpisodeUsingMyDocAPI(DataTable userDetails) {
//        Map<String, String> conciergeDetailsMap;
//        conciergeDetailsMap = userDetails.asMap(String.class, String.class);
//        createEpisodeDetails = myDocApi.createEpisode(configvariable.expandValue(conciergeDetailsMap.get("patient_id")), configvariable.expandValue(conciergeDetailsMap.get("myDoc_UserId")));
//    }
//
//    @When("I verify following details are present in response of create episode API")
//    public void verifyCreateEpisodeResponse(DataTable dt) {
//        Map<String, String> createEpisodeDetailsMap;
//        createEpisodeDetailsMap = dt.asMaps(String.class, String.class).get(0);
//        String actualVal = null;
//        int docIndex = 0;
//        int patientIndex = 0;
//        int totalMembers = ((ArrayList) createEpisodeDetails.jsonPath().get("data.members")).size();
//        for (int iCount = 0; iCount < totalMembers; iCount++) {
//            if (createEpisodeDetails.jsonPath().get("data." + "members[" + iCount + "].id").toString() != null && createEpisodeDetails.jsonPath().get("data." + "members[" + iCount + "].id").toString().equals(configvariable.expandValue("${DoctorId}"))) {
//                docIndex = iCount;
//                break;
//            }
//        }
//        for (int iCount = 0; iCount < totalMembers; iCount++) {
//            if (createEpisodeDetails.jsonPath().get("data." + "members[" + iCount + "].id").toString() != null && createEpisodeDetails.jsonPath().get("data." + "members[" + iCount + "].id").toString().equals(configvariable.expandValue("${PATIENT_ID}"))) {
//                patientIndex = iCount;
//                break;
//            }
//        }
//        for (String key : createEpisodeDetailsMap.keySet()) {
//            if (key.contains("data")) {
//                String[] parts = key.split("->");
//                if (parts[1].contains("members") && parts[2].contains("doctor")) {
//                    actualVal = createEpisodeDetails.jsonPath().get("data." + parts[1] + "[" + docIndex + "]" + "." + parts[3]).toString();
//                } else if (parts[1].contains("members") && parts[2].contains("patient")) {
//                    actualVal = createEpisodeDetails.jsonPath().get("data." + parts[1] + "[" + patientIndex + "]" + "." + parts[3]).toString();
//                } else if (parts.length == 2) {
//                    actualVal = createEpisodeDetails.jsonPath().get("data." + parts[1]).toString();
//                }
//                Assert.assertEquals(actualVal, configvariable.expandValue(createEpisodeDetailsMap.get(key)), configvariable.expandValue(createEpisodeDetailsMap.get(key)) + " value is present in response");
//            } else if (key.contains("code")) {
//                actualVal = createEpisodeDetails.jsonPath().get("code").toString();
//                Assert.assertEquals(actualVal, configvariable.expandValue(createEpisodeDetailsMap.get(key)), configvariable.expandValue(createEpisodeDetailsMap.get(key)) + " value is present in response");
//            } else if (key.contains("message")) {
//                actualVal = createEpisodeDetails.jsonPath().get("message").toString();
//                Assert.assertEquals(actualVal, configvariable.expandValue(createEpisodeDetailsMap.get(key)), configvariable.expandValue(createEpisodeDetailsMap.get(key)) + " value is present in response");
//            }
//        }
//
//    }
//
//    @When("I send message \"([^\"]*)\" to patient using MyDoc API")
//    public void sendMessageToPatientUsingMyDocAPI(String message) {
//        myDocApi.sendEpisodeMessage(configvariable.expandValue(message));
//    }
//
//    @When("I create eMC for patient using MyDoc API")
//    public void createEMCForPatient() {
//        createEMCDetails = myDocApi.createEmc();
//    }
//
//    @When("I send eMC to the patient using MyDoc API")
//    public void sendEMCToPatient() {
//        sendEMCDetails = myDocApi.sendEmc();
//    }
//
//    @When("I create case note for patient using below details with MyDoc API")
//    public void createCaseNoteForPatient(DataTable caseDetails) {
//        Map<String, String> variableMap;
//        variableMap = caseDetails.asMap(String.class, String.class);
//        configvariable.assignValueToVarMap(variableMap);
//        createCaseNoteDetails = myDocApi.createCaseNoteForPatient();
//    }
//
//    @When("I close the consultation using MyDoc Api")
//    public void closeConsultationForPatient() {
//        myDocApi.closeConsultationForPatient();
//    }
//
//    @When("Doctor rejects the appointment for the patient \"([^\"]*)\"")
//    public void doctoRejectAppointment(String patientEmail) {
//        myDocApi.getApppointmentIdForPatient(configvariable.expandValue(patientEmail));
//        rejectAppointmentDetails = myDocApi.doctorRejectAppointment();
//    }
//
//    @When("I create the appointment using MyDoc Api")
//    public void createDoctorAppointment() {
//        LocalDateTime now = LocalDateTime.now().plusHours(1);
//        String formattedDate = configvariable.formatDateAndTime("yyyy-MM-dd", now);
//        String formattedTime = configvariable.formatDateAndTimeWithZone("HH:mm:ss", ZoneId.of("Asia/Singapore"), now);
//        configvariable.setStringVariable(formattedDate, "FROM_DATE");
//        configvariable.setStringVariable(formattedTime, "START_TIME");
//        createAppointmentDetails = myDocApi.createAppointment();
//    }
//
//    @When("I verify following details are present in response of create appointment API")
//    public void verifyCreateAppointmentResponse(DataTable dt) {
//        Map<String, String> createAppointmentDetailsMap;
//        createAppointmentDetailsMap = dt.asMaps(String.class, String.class).get(0);
//        String actualVal = null;
//        for (String key : createAppointmentDetailsMap.keySet()) {
//            if (key.contains("data")) {
//                String[] parts = key.split("->");
//                if (parts.length == 2) {
//                    actualVal = createAppointmentDetails.jsonPath().get("data." + parts[1]).toString();
//                } else if (parts.length == 3) {
//                    actualVal = createAppointmentDetails.jsonPath().get("data." + parts[1] + "." + parts[2]).toString();
//                }
//                Assert.assertEquals(actualVal, configvariable.expandValue(createAppointmentDetailsMap.get(key)), configvariable.expandValue(createAppointmentDetailsMap.get(key)) + " value is present in response");
//            } else if (key.contains("code")) {
//                actualVal = createAppointmentDetails.jsonPath().get("code").toString();
//                Assert.assertEquals(actualVal, configvariable.expandValue(createAppointmentDetailsMap.get(key)), configvariable.expandValue(createAppointmentDetailsMap.get(key)) + " value is present in response");
//            } else if (key.contains("message")) {
//                actualVal = createAppointmentDetails.jsonPath().get("message").toString();
//                Assert.assertEquals(actualVal, configvariable.expandValue(createAppointmentDetailsMap.get(key)), configvariable.expandValue(createAppointmentDetailsMap.get(key)) + " value is present in response");
//            }
//        }
//    }
//
//    @When("I verify following details are present in response of accept appointment API")
//    public void verifyAcceptAppointmentResponse(DataTable dt) {
//        Map<String, String> acceptAppointmentDetailsMap;
//        acceptAppointmentDetailsMap = dt.asMaps(String.class, String.class).get(0);
//        String actualVal = null;
//        for (String key : acceptAppointmentDetailsMap.keySet()) {
//            if (key.contains("data")) {
//                String[] parts = key.split("->");
//                if (parts.length == 2) {
//                    actualVal = acceptAppointmentDetails.jsonPath().get("data." + parts[1]).toString();
//                } else if (parts.length == 3) {
//                    actualVal = acceptAppointmentDetails.jsonPath().get("data." + parts[1] + "." + parts[2]).toString();
//                }
//                Assert.assertEquals(actualVal, configvariable.expandValue(acceptAppointmentDetailsMap.get(key)), configvariable.expandValue(acceptAppointmentDetailsMap.get(key)) + " value is present in response");
//            } else if (key.contains("code")) {
//                actualVal = acceptAppointmentDetails.jsonPath().get("code").toString();
//                Assert.assertEquals(actualVal, configvariable.expandValue(acceptAppointmentDetailsMap.get(key)), configvariable.expandValue(acceptAppointmentDetailsMap.get(key)) + " value is present in response");
//            } else if (key.contains("message")) {
//                actualVal = acceptAppointmentDetails.jsonPath().get("message").toString();
//                Assert.assertEquals(actualVal, configvariable.expandValue(acceptAppointmentDetailsMap.get(key)), configvariable.expandValue(acceptAppointmentDetailsMap.get(key)) + " value is present in response");
//            }
//        }
//    }
//
//    @When("I verify following details are present in response of reject appointment API")
//    public void verifyRejectAppointmentResponse(DataTable dt) {
//        Map<String, String> rejectAppointmentDetailsMap;
//        rejectAppointmentDetailsMap = dt.asMaps(String.class, String.class).get(0);
//        String actualVal = null;
//        for (String key : rejectAppointmentDetailsMap.keySet()) {
//            if (key.contains("data")) {
//                String[] parts = key.split("->");
//                if (parts.length == 2) {
//                    actualVal = rejectAppointmentDetails.jsonPath().get("data." + parts[1]).toString();
//                } else if (parts.length == 3) {
//                    actualVal = rejectAppointmentDetails.jsonPath().get("data." + parts[1] + "." + parts[2]).toString();
//                }
//                Assert.assertEquals(actualVal, configvariable.expandValue(rejectAppointmentDetailsMap.get(key)), configvariable.expandValue(rejectAppointmentDetailsMap.get(key)) + " value is present in response");
//            } else if (key.contains("code")) {
//                actualVal = rejectAppointmentDetails.jsonPath().get("code").toString();
//                Assert.assertEquals(actualVal, configvariable.expandValue(rejectAppointmentDetailsMap.get(key)), configvariable.expandValue(rejectAppointmentDetailsMap.get(key)) + " value is present in response");
//            } else if (key.contains("message")) {
//                actualVal = rejectAppointmentDetails.jsonPath().get("message").toString();
//                Assert.assertEquals(actualVal, configvariable.expandValue(rejectAppointmentDetailsMap.get(key)), configvariable.expandValue(rejectAppointmentDetailsMap.get(key)) + " value is present in response");
//            }
//        }
//    }
//
//    @When("I create the patient using MyDoc Api")
//    public void createPatient() {
//        myDocApi.createPatient();
//    }
//
//    @When("I add the NRIC to patient using MyDoc APi")
//    public void addNRIC() {
//        myDocApi.addNricToPatient();
//    }
//
//    @When("I get the appointment detail for patient \"([^\"]*)\" MyDoc Api")
//    public void getAppointmentResponse(String patientEmail) {
//        getAppointmentDetails = myDocApi.getApppointmentIdForPatient(configvariable.expandValue(patientEmail));
//    }
//
//    @When("I verify following details are present in response of get appointment API")
//    public void verifyGetAppointmentResponseForPatient(DataTable dt) {
//        Map<String, String> getAppointmentDetailsMap;
//        getAppointmentDetailsMap = dt.asMaps(String.class, String.class).get(0);
//        String actualVal = null;
//        int index = 0;
//        for (String key : getAppointmentDetailsMap.keySet()) {
//            if (key.contains("data")) {
//                int totalAppointments = getAppointmentDetails.jsonPath().get("total");
//                for (int iCount = 0; iCount < totalAppointments; iCount++) {
//                    if (getAppointmentDetails.jsonPath().get("data[" + iCount + "].patient.email") != null && getAppointmentDetails.jsonPath().get("data[" + iCount + "].patient.email").equals(configvariable.expandValue("${PATIENT_EMAIL}").toLowerCase())) {
//                        index = iCount;
//                        break;
//                    }
//                }
//                String[] parts = key.split("->");
//                if (parts.length == 2) {
//                    actualVal = getAppointmentDetails.jsonPath().get("data[" + index + "]" + "." + parts[1]).toString();
//                } else if (parts.length == 3) {
//                    actualVal = getAppointmentDetails.jsonPath().get("data[" + index + "]" + "." + parts[1] + "." + parts[2]).toString();
//                }
//                Assert.assertEquals(actualVal, configvariable.expandValue(getAppointmentDetailsMap.get(key)), configvariable.expandValue(getAppointmentDetailsMap.get(key)) + " value is present in response");
//            } else if (key.contains("code")) {
//                actualVal = getAppointmentDetails.jsonPath().get("code").toString();
//                Assert.assertEquals(actualVal, configvariable.expandValue(getAppointmentDetailsMap.get(key)), configvariable.expandValue(getAppointmentDetailsMap.get(key)) + " value is present in response");
//            } else if (key.contains("message")) {
//                actualVal = getAppointmentDetails.jsonPath().get("message").toString();
//                Assert.assertEquals(actualVal, configvariable.expandValue(getAppointmentDetailsMap.get(key)), configvariable.expandValue(getAppointmentDetailsMap.get(key)) + " value is present in response");
//            }
//        }
//    }
//
//    @When("I get the details using MyDoc Api for account id \"([^\"]*)\"")
//    public void getAccount(String accountId) {
//        getAccountDetails = myDocApi.getAccountID(accountId);
//    }
//
//    @When("I verify the account details returned by the MyDoc API")
//    public void verifyGetAccount(DataTable dt) {
//        Map<String, String> getAccountDetailsMap;
//        getAccountDetailsMap = dt.asMaps(String.class, String.class).get(0);
//        String actualVal = null;
//        for (String key : getAccountDetailsMap.keySet()) {
//            if (key.contains("data")) {
//                String[] parts = key.split("->");
//                if (parts.length == 2) {
//                    actualVal = getAccountDetails.jsonPath().get("data." + parts[1]).toString();
//                } else if (parts.length == 3) {
//                    actualVal = getAccountDetails.jsonPath().get("data." + parts[1] + "." + parts[2]).toString();
//                }
//                Assert.assertEquals(actualVal, configvariable.expandValue(getAccountDetailsMap.get(key)), configvariable.expandValue(getAccountDetailsMap.get(key)) + " value is present in response");
//            } else if (key.contains("code")) {
//                actualVal = getAccountDetails.jsonPath().get("code").toString();
//                Assert.assertEquals(actualVal, configvariable.expandValue(getAccountDetailsMap.get(key)), configvariable.expandValue(getAccountDetailsMap.get(key)) + " value is present in response");
//            } else if (key.contains("message")) {
//                actualVal = getAccountDetails.jsonPath().get("message").toString();
//                Assert.assertEquals(actualVal, configvariable.expandValue(getAccountDetailsMap.get(key)), configvariable.expandValue(getAccountDetailsMap.get(key)) + " value is present in response");
//            }
//        }
//    }
//
//    @When("I get the group details using MyDoc Api for account id \"([^\"]*)\"")
//    public void getAccountGroup(String accountId) {
//        getAcctGroupDetails = myDocApi.getAccountGroupID(accountId);
//    }
//
//    @When("I verify the account group details returned by the MyDoc API")
//    public void verifyGetAccountGroup(DataTable dt) {
//        Map<String, String> getAcctGroupDetailsMap;
//        getAcctGroupDetailsMap = dt.asMaps(String.class, String.class).get(0);
//        String actualVal = null;
//        for (String key : getAcctGroupDetailsMap.keySet()) {
//            if (key.contains("data")) {
//                String[] parts = key.split("->");
//                if (parts.length == 2) {
//                    actualVal = getAcctGroupDetails.jsonPath().get("data." + parts[1]).toString();
//                } else if (parts.length == 3) {
//                    actualVal = getAcctGroupDetails.jsonPath().get("data." + parts[1] + "." + parts[2]).toString();
//                }
//                Assert.assertEquals(actualVal, configvariable.expandValue(getAcctGroupDetailsMap.get(key)), configvariable.expandValue(getAcctGroupDetailsMap.get(key)) + " value is present in response");
//            } else if (key.contains("code")) {
//                actualVal = getAcctGroupDetails.jsonPath().get("code").toString();
//                Assert.assertEquals(actualVal, configvariable.expandValue(getAcctGroupDetailsMap.get(key)), configvariable.expandValue(getAcctGroupDetailsMap.get(key)) + " value is present in response");
//            } else if (key.contains("message")) {
//                actualVal = getAcctGroupDetails.jsonPath().get("message").toString();
//                Assert.assertEquals(actualVal, configvariable.expandValue(getAcctGroupDetailsMap.get(key)), configvariable.expandValue(getAcctGroupDetailsMap.get(key)) + " value is present in response");
//            }
//        }
//    }
//
//    @When("I update my account details using above mentioned values through MyDoc API for \"([^\"]*)\"")
//    public void updateAcctDetails(String accountId) {
//        updateAcctDetails = myDocApi.updateAccountDetails(accountId);
//    }
//
//    @When("I verify the following details are present in the response of update account API")
//    public void verifyPutAccount(DataTable dt) {
//        Map<String, String> updateAcctDetailsMap;
//        updateAcctDetailsMap = dt.asMaps(String.class, String.class).get(0);
//        String actualVal = null;
//        for (String key : updateAcctDetailsMap.keySet()) {
//            if (key.contains("data")) {
//                String[] parts = key.split("->");
//                if (parts.length == 2) {
//                    actualVal = updateAcctDetails.jsonPath().get("data." + parts[1]).toString();
//                } else if (parts.length == 3) {
//                    actualVal = updateAcctDetails.jsonPath().get("data." + parts[1] + "." + parts[2]).toString();
//                }
//                Assert.assertEquals(actualVal, configvariable.expandValue(updateAcctDetailsMap.get(key)), configvariable.expandValue(updateAcctDetailsMap.get(key)) + " value is present in response");
//            } else if (key.contains("code")) {
//                actualVal = updateAcctDetails.jsonPath().get("code").toString();
//                Assert.assertEquals(actualVal, configvariable.expandValue(updateAcctDetailsMap.get(key)), configvariable.expandValue(updateAcctDetailsMap.get(key)) + " value is present in response");
//            } else if (key.contains("message")) {
//                actualVal = updateAcctDetails.jsonPath().get("message").toString();
//                Assert.assertEquals(actualVal, configvariable.expandValue(updateAcctDetailsMap.get(key)), configvariable.expandValue(updateAcctDetailsMap.get(key)) + " value is present in response");
//            }
//        }
//    }
//
//    @When("I verify the following details are present in the response of create case notes API")
//    public void verifyCreateCaseNote(DataTable dt) {
//        Map<String, String> createCaseNoteDetailsMap;
//        createCaseNoteDetailsMap = dt.asMaps(String.class, String.class).get(0);
//        String actualVal = null;
//        for (String key : createCaseNoteDetailsMap.keySet()) {
//            if (key.contains("data")) {
//                String[] parts = key.split("->");
//                if (parts.length == 2) {
//                    actualVal = createCaseNoteDetails.jsonPath().get("data." + parts[1]).toString();
//                } else if (parts.length == 3) {
//                    actualVal = createCaseNoteDetails.jsonPath().get("data." + parts[1] + "." + parts[2]).toString();
//                } else if (parts.length == 4) {
//                    actualVal = createCaseNoteDetails.jsonPath().get("data." + parts[1] + "." + parts[2] + "." + parts[3]).toString();
//                }
//                Assert.assertEquals(actualVal, configvariable.expandValue(createCaseNoteDetailsMap.get(key)), configvariable.expandValue(createCaseNoteDetailsMap.get(key)) + " value is present in response");
//            } else if (key.contains("code")) {
//                actualVal = createCaseNoteDetails.jsonPath().get("code").toString();
//                Assert.assertEquals(actualVal, configvariable.expandValue(createCaseNoteDetailsMap.get(key)), configvariable.expandValue(createCaseNoteDetailsMap.get(key)) + " value is present in response");
//            } else if (key.contains("message")) {
//                actualVal = createCaseNoteDetails.jsonPath().get("message").toString();
//                Assert.assertEquals(actualVal, configvariable.expandValue(createCaseNoteDetailsMap.get(key)), configvariable.expandValue(createCaseNoteDetailsMap.get(key)) + " value is present in response");
//            }
//        }
//    }
//
//    @When("I login to MyDoc using api with admin credentials")
//    public void loginToMyDocWithAdminCredential(DataTable adminCredentials) {
//        //myDocApi.loginToMyDocWithAdminCredential();
//        Map<String, String> adminDetailsMap;
//        adminDetailsMap = adminCredentials.asMap(String.class, String.class);
//        configvariable.assignValueToVarMap(adminDetailsMap);
//        myDocApi.loginToMyDoc(configvariable.getStringVar("ADMIN_EMAIL"), configvariable.getStringVar("ADMIN_PASSWORD"));
//    }
//
//    @When("I get the group details using MyDoc API")
//    public void getGroup() {
//        getGroupDetails = myDocApi.getGroups();
//    }
//
//    @When("I verify the group details returned by the MyDoc API")
//    public void verifyGetGroup(DataTable dt) {
//        Map<String, String> getGroupDetailsMap;
//        getGroupDetailsMap = dt.asMaps(String.class, String.class).get(0);
//        String actualVal = null;
//        for (String key : getGroupDetailsMap.keySet()) {
//            if (key.contains("data")) {
//                String[] parts = key.split("->");
//                if (parts.length == 2) {
//                    actualVal = getGroupDetails.jsonPath().get("data." + parts[1]).toString();
//                } else if (parts.length == 3) {
//                    actualVal = getGroupDetails.jsonPath().get("data." + parts[1] + "." + parts[2]).toString();
//                }
//                Assert.assertEquals(actualVal, configvariable.expandValue(getGroupDetailsMap.get(key)), configvariable.expandValue(getGroupDetailsMap.get(key)) + " value is present in response");
//            } else if (key.contains("code")) {
//                actualVal = getGroupDetails.jsonPath().get("code").toString();
//                Assert.assertEquals(actualVal, configvariable.expandValue(getGroupDetailsMap.get(key)), configvariable.expandValue(getGroupDetailsMap.get(key)) + " value is present in response");
//            } else if (key.contains("message")) {
//                actualVal = getGroupDetails.jsonPath().get("message").toString();
//                Assert.assertEquals(actualVal, configvariable.expandValue(getGroupDetailsMap.get(key)), configvariable.expandValue(getGroupDetailsMap.get(key)) + " value is present in response");
//            }
//        }
//    }
//
//    @When("I login to MyDoc using api with patient credentials")
//    public void loginToMyDocWithPatientCredentials(DataTable dt) {
//        Map<String, String> patientCredentials;
//        patientCredentials = dt.asMap(String.class, String.class);
//        //myDocApi.loginToMyDocWithPatientCredential(configvariable.expandValue(patientCredentials.get("PATIENT_EMAIL")), patientCredentials.get("PATIENT_PASSWORD"));
//        myDocApi.loginToMyDoc(configvariable.expandValue(patientCredentials.get("PATIENT_EMAIL")), patientCredentials.get("PATIENT_PASSWORD"));
//
//    }
//
//    @When("I verify following details are present in response of create EMC API")
//    public void verifyCreateEMCResponse(DataTable dt) {
//        Map<String, String> createEMCDetailsMap;
//        createEMCDetailsMap = dt.asMaps(String.class, String.class).get(0);
//        String actualVal = null;
//        for (String key : createEMCDetailsMap.keySet()) {
//            if (key.contains("data")) {
//                String[] parts = key.split("->");
//                if (parts.length == 2) {
//                    actualVal = createEMCDetails.jsonPath().get("data." + parts[1]).toString();
//                } else if (parts.length == 3) {
//                    actualVal = createEMCDetails.jsonPath().get("data." + parts[1] + "." + parts[2]).toString();
//                }
//                Assert.assertEquals(actualVal, configvariable.expandValue(createEMCDetailsMap.get(key)), configvariable.expandValue(createEMCDetailsMap.get(key)) + " value is present in response");
//            } else if (key.contains("code")) {
//                actualVal = createEMCDetails.jsonPath().get("code").toString();
//                Assert.assertEquals(actualVal, configvariable.expandValue(createEMCDetailsMap.get(key)), configvariable.expandValue(createEMCDetailsMap.get(key)) + " value is present in response");
//            } else if (key.contains("message")) {
//                actualVal = createEMCDetails.jsonPath().get("message").toString();
//                Assert.assertEquals(actualVal, configvariable.expandValue(createEMCDetailsMap.get(key)), configvariable.expandValue(createEMCDetailsMap.get(key)) + " value is present in response");
//            }
//        }
//    }
//
//    @When("I verify following details are present in response of send EMC API")
//    public void verifySendEMCResponse(DataTable dt) {
//        Map<String, String> sendEMCDetailsMap;
//        sendEMCDetailsMap = dt.asMaps(String.class, String.class).get(0);
//        String actualVal = null;
//        for (String key : sendEMCDetailsMap.keySet()) {
//            if (key.contains("data")) {
//                String[] parts = key.split("->");
//                if (parts.length == 2) {
//                    actualVal = sendEMCDetails.jsonPath().get("data." + parts[1]).toString();
//                } else if (parts.length == 3) {
//                    actualVal = sendEMCDetails.jsonPath().get("data." + parts[1] + "." + parts[2]).toString();
//                }
//                Assert.assertEquals(actualVal, configvariable.expandValue(sendEMCDetailsMap.get(key)), configvariable.expandValue(sendEMCDetailsMap.get(key)) + " value is present in response");
//            } else if (key.contains("code")) {
//                actualVal = sendEMCDetails.jsonPath().get("code").toString();
//                Assert.assertEquals(actualVal, configvariable.expandValue(sendEMCDetailsMap.get(key)), configvariable.expandValue(sendEMCDetailsMap.get(key)) + " value is present in response");
//            } else if (key.contains("message")) {
//                actualVal = sendEMCDetails.jsonPath().get("message").toString();
//                Assert.assertEquals(actualVal, configvariable.expandValue(sendEMCDetailsMap.get(key)), configvariable.expandValue(sendEMCDetailsMap.get(key)) + " value is present in response");
//            }
//        }
//    }
//
//    @When("I get the available doctor using MyDoc Api")
//    public void getAvailableDoctor() {
//        getAvailableDoctorDetails = myDocApi.getAvailableDoctor();
//    }
//
//    @When("I verify following details are present in response of available doctor API")
//    public void verifyAvailableDoctorResponse(DataTable dt) {
//        Map<String, String> getAvailableDoctorDetailsMap;
//        getAvailableDoctorDetailsMap = dt.asMaps(String.class, String.class).get(0);
//        int docCount = ((ArrayList) getAvailableDoctorDetails.jsonPath().get("data")).size();
//        boolean flag = docCount > 0;
//        Assert.assertTrue(flag, configvariable.expandValue(getAvailableDoctorDetailsMap.get("data")) + " value is present in response");
//        String actualCodeVal = getAvailableDoctorDetails.jsonPath().get("code").toString();
//        Assert.assertEquals(actualCodeVal, configvariable.expandValue(getAvailableDoctorDetailsMap.get("code")), configvariable.expandValue(getAvailableDoctorDetailsMap.get("code")) + " value is present in response");
//        String actualMessageVal = getAvailableDoctorDetails.jsonPath().get("message").toString();
//        Assert.assertEquals(actualMessageVal, configvariable.expandValue(getAvailableDoctorDetailsMap.get("message")), configvariable.expandValue(getAvailableDoctorDetailsMap.get("message")) + " value is present in response");
//    }
//
//    @When("I create the emergency contact using MyDoc API")
//    public void createEmergencyContacts() {
//        createEmergencyContactDetails = myDocApi.createEmergencyContacts();
//    }
//
//    @When("I verify the following details are present in the response of \"([^\"]*)\" emergency contact API")
//    public void verifyEmergencyContactResponse(String operationType,DataTable dt) {
//        Response emergencyContactDetail = null;
//        if(operationType.equalsIgnoreCase("create")){
//            emergencyContactDetail = createEmergencyContactDetails;
//        }
//        else if(operationType.equalsIgnoreCase("update")){
//            emergencyContactDetail = updateEmergencyContactDetails;
//        }
//        else if(operationType.equalsIgnoreCase("get")){
//            emergencyContactDetail = getEmergencyContactDetails;
//        }
//        else if(operationType.equalsIgnoreCase("delete")){
//            emergencyContactDetail = deleteEmergencyContactDetails;
//        }
//        Map<String, String> emergencyContactsDetailsMap;
//        emergencyContactsDetailsMap = dt.asMaps(String.class, String.class).get(0);
//        String actualVal = null;
//        for (String key : emergencyContactsDetailsMap.keySet()) {
//            if (key.contains("data")) {
//                String[] parts = key.split("->");
//                actualVal = emergencyContactDetail.jsonPath().get("data[0]" + "." + parts[1]).toString();
//                Assert.assertEquals(actualVal, configvariable.expandValue(emergencyContactsDetailsMap.get(key)), configvariable.expandValue(emergencyContactsDetailsMap.get(key)) + " value is present in response");
//            } else if (key.contains("code")) {
//                actualVal = emergencyContactDetail.jsonPath().get("code").toString();
//                Assert.assertEquals(actualVal, configvariable.expandValue(emergencyContactsDetailsMap.get(key)), configvariable.expandValue(emergencyContactsDetailsMap.get(key)) + " value is present in response");
//            } else if (key.contains("message")) {
//                actualVal = emergencyContactDetail.jsonPath().get("message").toString();
//                Assert.assertEquals(actualVal, configvariable.expandValue(emergencyContactsDetailsMap.get(key)), configvariable.expandValue(emergencyContactsDetailsMap.get(key)) + " value is present in response");
//            }
//        }
//    }
//
//    @When("I update the emergency contact using MyDoc API")
//    public void updateEmergencyContacts() {
//        String emergency_contact_id = createEmergencyContactDetails.jsonPath().get("data[0].id").toString();
//        configvariable.setStringVariable(emergency_contact_id, "MYDOC_EMERGENCY_CONTACT_ID");
//        updateEmergencyContactDetails = myDocApi.updateEmergencyContacts();
//    }
//
//    @When("I get the emergency contact using MyDoc API")
//    public void getEmergencyContacts() {
//        getEmergencyContactDetails = myDocApi.getEmergencyContacts();
//    }
//
//    @When("I delete the emergency contact using MyDoc API")
//    public void deleteEmergencyContacts() {
//        deleteEmergencyContactDetails = myDocApi.deleteEmergencyContacts();
//    }
//
//    @When("I get the chat messages \"([^\"]*)\" in the episode using MyDoc API")
//    public void getChatResponse(String message) {
//        getEpisodeChatMessages = myDocApi.getEpisodeMessages(message);
//    }
//
//    @When("I verify following details are present in response of get episode messages API")
//    public void verifyGetEpisodeChatMessages(DataTable dt) {
//        Map<String, String> getEpisodeChatMessagesMap;
//        getEpisodeChatMessagesMap = dt.asMaps(String.class, String.class).get(0);
//        String actualVal = null;
//        String chatMsg = null;
//        int index = 0;
//        int totalMessages = getEpisodeChatMessages.jsonPath().get("total");
//        for (String key : getEpisodeChatMessagesMap.keySet()) {
//            if (key.contains("data")) {
//                String[] parts = key.split("->");
//                chatMsg = configvariable.expandValue(getEpisodeChatMessagesMap.get("data->content"));
//                for (int iCount = 0; iCount < totalMessages; iCount++) {
//                    if (getEpisodeChatMessages.jsonPath().get("data[" + iCount + "].content") == chatMsg) {
//                        index = iCount;
//                        break;
//                    }
//                }
//                if (parts.length == 2) {
//                    actualVal = getEpisodeChatMessages.jsonPath().get("data[" + index + "]" + "." + parts[1]).toString();
//                } else if (parts.length == 3) {
//                    actualVal = getEpisodeChatMessages.jsonPath().get("data[" + index + "]" + "." + parts[1] + "." + parts[2]).toString();
//                }
//                Assert.assertEquals(actualVal, configvariable.expandValue(getEpisodeChatMessagesMap.get(key)), configvariable.expandValue(getEpisodeChatMessagesMap.get(key)) + " value is present in response");
//            } else if (key.contains("code")) {
//                actualVal = getEpisodeChatMessages.jsonPath().get("code").toString();
//                Assert.assertEquals(actualVal, configvariable.expandValue(getEpisodeChatMessagesMap.get(key)), configvariable.expandValue(getEpisodeChatMessagesMap.get(key)) + " value is present in response");
//            } else if (key.contains("message")) {
//                actualVal = getEpisodeChatMessages.jsonPath().get("message").toString();
//                Assert.assertEquals(actualVal, configvariable.expandValue(getEpisodeChatMessagesMap.get(key)), configvariable.expandValue(getEpisodeChatMessagesMap.get(key)) + " value is present in response");
//            }
//        }
//    }
//
//
//    @Then("^I confirm the doctor appointment$")
//    public void iConfirmTheDoctorAppointment() {
//        myDocApi.getAppointmentId();
//        myDocApi.acceptDoctor();
//
//
//    }
//}
//
//
//
//

