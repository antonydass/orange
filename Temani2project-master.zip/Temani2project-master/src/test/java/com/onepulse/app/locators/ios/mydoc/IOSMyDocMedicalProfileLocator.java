package com.onepulse.app.locators.ios.mydoc;

import org.openqa.selenium.By;
import org.springframework.stereotype.Component;

@Component
public class IOSMyDocMedicalProfileLocator {
    public By nonOfTheAbove = By.xpath("//XCUIElementTypeOther[@name='None of the above']");
    public By okButton = By.xpath("//XCUIElementTypeOther[@name='OK']");
    public By medicalProfileText = By.xpath("//XCUIElementTypeStaticText[@name='Medical Profile']");
    public By allergies = By.xpath("//XCUIElementTypeStaticText[@name='Allergies']//following::XCUIElementTypeOther[1]/XCUIElementTypeTextView");
    public By medicalCondition = By.xpath("//XCUIElementTypeStaticText[@name='Medical Conditions']//following::XCUIElementTypeOther[1]/XCUIElementTypeTextView");
    public By medication = By.xpath("//XCUIElementTypeStaticText[@name='Medications']//following::XCUIElementTypeOther[1]/XCUIElementTypeTextField");
    public By emergencyContactName = By.xpath("//XCUIElementTypeStaticText[@name='Emergency Contact Name']//following::XCUIElementTypeOther[1]/XCUIElementTypeTextField");
    public By emergencyContactPhone = By.xpath("//XCUIElementTypeOther[@name='+65 ']/XCUIElementTypeOther/XCUIElementTypeTextField");
    public By proceedButton = By.xpath("(//XCUIElementTypeOther[@name='Proceed'])[3]");
    public By paymentDetailsText = By.xpath("//XCUIElementTypeStaticText[@name='Payment Details']");
    public By countryCode = By.xpath("//XCUIElementTypeStaticText[@name='+65 ']");
    public static String MEDPROFILE_FIELD_LABEL = "//XCUIElementTypeStaticText[@name=\"%s\"]";
}
