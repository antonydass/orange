package com.onepulse.app.stepdefinitions.mobilesteps;

import com.onepulse.app.cucumberhooks.CucumberHook;
import com.onepulse.app.screens.PulseRegistrationScreen;
import com.onepulse.app.screens.TestBasePage;
import com.prod.tap.config.Configvariable;
//import com.prudential.tap.config.Configvariable;
import cucumber.api.DataTable;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import java.util.List;
import java.util.Map;


public class RegistrationSteps {

    private PulseRegistrationScreen pulseRegistrationScreen = CucumberHook.context.getBean(PulseRegistrationScreen.class);

    private Configvariable configvariable = CucumberHook.context.getBean(Configvariable.class);
    @Autowired
    private TestBasePage testBasePage;

    @And("I click on resend \"([^\"]*)\" button")
    public void clickOnResendBtn(String resendTxt) {
//        Assert.assertEquals(pulseRegistrationScreen.clickOnResendBtn(TestBasePage.platform),resendTxt);
        pulseRegistrationScreen.clickOnResendBtn();
    }


    @Then("^I click the Sign in link$")
    public void clickSignIns_InSignUp() throws Throwable {
        pulseRegistrationScreen.clickSignIns_InSignUp(TestBasePage.platform);
    }

    @And("user enters registration details")
    public void enterRegistrationDetails(DataTable userDetails) {
        Map<String, String> registrationDetails;
        registrationDetails = userDetails.asMap(String.class, String.class);
        pulseRegistrationScreen.enterRegistrationDetails(registrationDetails);
    }

    @Given("^Clear the Email id  field in sigin up$")
    public void ClearEmail_id() throws Throwable {
        pulseRegistrationScreen.ClearEmail_id(TestBasePage.platform);
    }

    @And("I enter \"([^\"]*)\" OTP")
    public void enterOTP(String otp) {
        pulseRegistrationScreen.enterOTP(TestBasePage.platform, configvariable.expandValue(otp));
    }

    @And("I handle carousel")
    public void handleCarousel() {

        pulseRegistrationScreen.handleCarousel(TestBasePage.platform);
    }


    @When("I enable the show password icon")
    public void showPassword() {
        pulseRegistrationScreen.showPassword();
    }

    @Then("I enter invalid details for \"([^\"]*)\" and verify the error message \"([^\"]*)\"")
    public void validateRegValues(String fieldName, String errorMsg, DataTable dt) {
        List<String> invalidRegDetails;
        invalidRegDetails = dt.asList(String.class);
        pulseRegistrationScreen.validateRegValues(TestBasePage.platform, invalidRegDetails, fieldName, errorMsg);
    }


    @When("I enter invalid Pulse registration details and validate the error message")
    public void verifyErrorMessageForInvalidPulseRegistrationValue(DataTable registrationInvalidPulseDetails) {
        Map<String, String> registrationDetails;
        registrationDetails = registrationInvalidPulseDetails.asMap(String.class, String.class);
        pulseRegistrationScreen.validatePulseRegistrationFieldValue(TestBasePage.platform, registrationDetails);
    }

    //    covid19
    @When("I enter valid details for \"([^\"]*)\" and verify the error message \"([^\"]*)\" should not display")
    public void validateValidPasswordValues(String fieldName, String errorMsg, DataTable dt) {
        List<String> validPasswordValues;
        validPasswordValues = dt.asList(String.class);
        pulseRegistrationScreen.validateValidPasswordValues(TestBasePage.platform, validPasswordValues, fieldName, errorMsg);
    }


//    @Then("^I enter the mobile number in welcome to pulse$")
//    public void i_enter_the_mobile_number_in_welcome_to_pulse(DataTable userDetails) throws Throwable {
//        Map<String, String> registrationDetails;
//        registrationDetails = userDetails.asMap(String.class, String.class);
//        pulseRegistrationScreen.enterMobileNumber(TestBasePage.platform, registrationDetails);
//    }

    @Then("^I click the pulse Device location$")
    public void clickPulseLocation() throws Throwable {
        pulseRegistrationScreen.clickLocations(TestBasePage.platform);
    }

    @Then("^I click the continue button$")
    public void continueButton() throws Throwable {
        pulseRegistrationScreen.continueButton();
    }

    @Then("^I click the continue buttons$")
    public void continuebuttons() throws Throwable {
        pulseRegistrationScreen.continuebuttons(TestBasePage.platform);
    }

    @Then("^I click the date in Date of Birth field$")
    public void enterDateOfBirth() throws Throwable {
        pulseRegistrationScreen.enterDateOfBirth(TestBasePage.platform);
    }


    @Then("^I click the Done icon$")
    public void doneButton() {
        pulseRegistrationScreen.doneButton(TestBasePage.platform);
    }

    @Then("^I select the  Male icon$")
    public void MaleImage() {
        pulseRegistrationScreen.maleImage(TestBasePage.platform);
    }

    @Then("^I click the NRIC number$")
    public void enterNric(DataTable userDetails) throws Throwable {
        Map<String, String> registrationDetails;
        registrationDetails = userDetails.asMap(String.class, String.class);
        pulseRegistrationScreen.enterNric(registrationDetails.get("NRIC number"));
    }

    @Then("^I click the Free Assessment$")
    public void freeAssement() throws Throwable {
        pulseRegistrationScreen.freeAssement(TestBasePage.platform);
    }

    @Given("^I click the Back button in Babylon screen$")
    public void backbutton_babylon() throws Throwable {
        pulseRegistrationScreen.backbutton_babylon(TestBasePage.platform);
    }


    @Given("^I click the Account icon in Home screen$")
    public void accountButton() {
        pulseRegistrationScreen.accountButton();
    }


    @Given("^user click on \"([^\"]*)\" with Email button$")
    public void clickRegisterWithEmail(String buttonText) throws Throwable {
        pulseRegistrationScreen.clickRegisterButton(configvariable.expandValue(buttonText));
    }


    @When("^taps on continue \"([^\"]*)\" button$")
    public void clickOnContinue(String buttonText) {
        pulseRegistrationScreen.clickRegisterContinueButton();
    }

    @Given("^I enter the \"([^\"]*)\" in welcome to pulse$")
    public void enterMobileNumber(String text, DataTable userDetails) {
        Map<String, String> registrationDetails;
        registrationDetails = userDetails.asMap(String.class, String.class);
        pulseRegistrationScreen.enterMobileNumber(TestBasePage.platform, registrationDetails, text);
    }

    @Given("^I enter the \"([^\"]*)\" in welcome to pulses$")
    public void EditMobileNumber(String textss, DataTable userDetails) throws Throwable {
        Map<String, String> registrationDetails;
        registrationDetails = userDetails.asMap(String.class, String.class);
        pulseRegistrationScreen.EditMobileNumber(TestBasePage.platform, registrationDetails, textss);
    }

    @Then("^user should be landed home screen$")
    public void isHomePageDisplayed() throws Throwable {
        pulseRegistrationScreen.isHomePageDisplayed(TestBasePage.platform);
    }

    @Then("^I Select the \"([^\"]*)\" in welcome to pulse$")
    public void Datepickup(String textss, DataTable userDetails) throws Throwable {
        Map<String, String> registrationDetails;
        registrationDetails = userDetails.asMap(String.class, String.class);
        pulseRegistrationScreen.Datepickup(TestBasePage.platform, registrationDetails, textss);
    }

    @Then("^I select the country \"([^\"]*)\"$")
    public void iSelectTheCountry(String countryName) throws Throwable {
        pulseRegistrationScreen.selectRegistrationCountry(TestBasePage.platform, configvariable.expandValue(countryName));
    }

    @Given("^I click the Resend button in OTP screen$")
    public void ClickResendButton() {
    //    pulseRegistrationScreen.clickResendButton(TestBasePage.platform);
    }

    @When("^I verify enter otp screen is not displayed$")
    public void ValidateEnterOtpScreen() {
        Assert.assertFalse(pulseRegistrationScreen.verifyOTPScreen());
    }

    @And("^I choose my wellness goals under wellness plan screen$")
    public void iChooseMyWellnessGoalsUnderWellnessPlanScreen() {
        pulseRegistrationScreen.selectWellnessPackage();
    }

    @And("^I enter my height and weight details$")
    public void iEnterMyHeightAndWeightDetails() {
        pulseRegistrationScreen.verifyHeightandWeightScreenUi();
    }

    @And("^I click on Calculate BMI button$")
    public void iClickOnCalculateBMIButton() {
        pulseRegistrationScreen.clickCalculateBMIButton();
    }

    @And("^I select the \"([^\"]*)\" in doing exercise$")
    public void iSelectTheInDoingExercise(String arg0) throws Throwable {
        pulseRegistrationScreen.clickLightExercise();
    }

    @And("^I select my favorite food dietary$")
    public void iSelectMyFavoriteFoodDietary() {
        pulseRegistrationScreen.clickFoodProducts();
    }

    @And("^I verify that \"([^\"]*)\" is displayed$")
    public void iVerifyThatIsDisplayed(String arg0) throws Throwable {
        pulseRegistrationScreen.verifytrackerConnectScreenUI();
    }

    @And("^I answer as \"([^\"]*)\" to \"([^\"]*)\"$")
    public void iAnswerAsTo(String buttonText, String arg1) {
        pulseRegistrationScreen.selectFoodAllergies(configvariable.expandValue(buttonText));
    }

    @And("^I see that \"([^\"]*)\" text is displayed$")
    public void iSeeThatTextIsDisplayed(String arg0) {
        pulseRegistrationScreen.verifyWelcomeToPulseScreen();
    }

    @And("^I see that fitness subscription exclusive offers screen is displayed$")
    public void iSeeThatFitnessSubscriptionExclusiveOffersScreenIsDisplayed() {
        pulseRegistrationScreen.verifyFitnessExclusiveOffersScreenUI();
    }

    @And("^I click on close icon$")
    public void iClickOnCloseIcon() {
            pulseRegistrationScreen.closeOffersScreen();
    }

    @And("^I click on close on healthy you icon$")
    public void iClickOnClosehaelthyouIcon() {
  //      pulseRegistrationScreen.closeHealthyYOuScreen();
    }


//    @Given("^user click on \"([^\"]*)\" with Email button$")
//    public void clickRegisterWithEmail(String buttonText) throws Throwable {
//        pulseRegistrationScreen.clickRegisterButton(TestBasePage.platform,configvariable.expandValue("buttonText"));
//    }

//    @And("user enters registration details")
//    public void enterRegistrationDetails(DataTable userDetails) {
//        Map<String, String> registrationDetails;
//        registrationDetails = userDetails.asMap(String.class, String.class);
//        pulseRegistrationScreen.enterRegistrationDetails(TestBasePage.platform, registrationDetails);
//    }

//    @When("^taps on continue \"([^\"]*)\" button$")
//    public void clickOnContinue(String buttonText) throws Throwable {
//        pulseRegistrationScreen.clickRegisterContinueButton(TestBasePage.platform,configvariable.expandValue(buttonText));
//    }


//    @Then("^I click the My settings in Account screen$")
//    public void i_click_the_My_settings_in_Account_screen() throws Throwable {
//
//        pulseRegistrationScreen.MySettings_button(TestBasePage.platform);
//    }
//    @Then("^I select the SG in Country field$")
//    public void i_select_the_SG_in_Country_field() throws Throwable {
//        pulseRegistrationScreen.Select_Country(TestBasePage.platform);
//
//    }
//    @Then("^I click the Back button in My setting screen$")
//    public void i_click_the_Back_button_in_My_setting_screen() throws Throwable {
//        pulseRegistrationScreen.MySettings_backbutton(TestBasePage.platform);
//    }
//
//    @Then("^I click the Home button$")
//    public void i_click_the_Home_button() throws Throwable {
//        pulseRegistrationScreen.isHomePageDisplayedbutton(TestBasePage.platform);
//    }
//    @Then("^I click the Review Manage your group icon$")
//    public void i_click_the_Review_Manage_your_group_icon() throws Throwable {
//        pulseRegistrationScreen.IsReviewandManagebutton(TestBasePage.platform);
//    }

    @And("I enter OTP in one pulse app for user email \"([^\"]*)\"")
    public void enterOTPInPulse(String email) {
        pulseRegistrationScreen.enterOTP(TestBasePage.platform, configvariable.expandValue(email));
    }

    @And("I read the otp for emailid \"([^\"]*)\" using mailsac api and store into a variable \"([^\"]*)\"")
    public void readOTP(String emailId, String varName) {
        pulseRegistrationScreen.readOTP(configvariable.expandValue(emailId), varName);
    }


    @When("^I change the country as required on registration page$")
    public void iSelectTheCountry() {
        String countryName = configvariable.expandValue("${country.name}");
        pulseRegistrationScreen.changeTheCountryName(TestBasePage.platform, countryName);
    }

    @Then("^I verify below language options on toggle bar as per specified lbu on login page$")
    public void verifyTheLanguageOptions() {
        String lbu = System.getProperty("app.lbu");
        String[] langOptions = configvariable.getStringVar(lbu.toLowerCase()).split(",");
        SoftAssert softAssert = new SoftAssert();
        for (String lang : langOptions) {
            softAssert.assertTrue(pulseRegistrationScreen.verifyTheLanguageOptions(lang), lang + " is displayed as expected");
        }
        softAssert.assertAll();
    }

//    @When("^I change the language as required on registration page$")
//    public void iSelectTheLanguage() {
//        String language;
//        String expectedLang = System.getProperty("app.language");
//        String lbu = System.getProperty("app.lbu");
//        if (lbu.equalsIgnoreCase("th")) {
//            if (expectedLang.equalsIgnoreCase("en")) {
//                language = "English";
//            } else {
//                language = configvariable.expandValue("${lang.name.text}");
//            }
//            pulseRegistrationScreen.selectTheLanguage(TestBasePage.platform, language);
//        }
//    }


    @When("^I change the language as required on registration page$")
    public void iSelectTheLanguage() {
        String expectedLang = System.getProperty("app.language");
        String lbu = System.getProperty("app.lbu");
        if (lbu.equalsIgnoreCase("th") && expectedLang.equalsIgnoreCase("en")) {
     //           pulseRegistrationScreen.selectLanguageEN();
         }
        else if (lbu.equalsIgnoreCase("my") && expectedLang.equalsIgnoreCase("en")) {
       //     pulseRegistrationScreen.selectLanguageEN();
        }
        if (lbu.equalsIgnoreCase("vn") && expectedLang.equalsIgnoreCase("en")) {
       //     pulseRegistrationScreen.selectLanguageEN();
        }
        else {
             String language = configvariable.expandValue("${lang.name.text}");
             pulseRegistrationScreen.selectTheLanguage(TestBasePage.platform, language);
        }
    }


    @Then("^I select the language option on toggle bar as required on login page$")
    public void selectTheLangOption() {
        String lang = System.getProperty("app.language").toUpperCase();
        pulseRegistrationScreen.selectTheLanguageToggle(lang);
    }

    @Then("^I verify the validation error message is displayed for following field on registration page$")
    public void verifyValidationMessage(DataTable dt) {
        Map<String, String> errorMessageMap = dt.asMap(String.class, String.class);
        SoftAssert softAssert = new SoftAssert();
        for (String key : errorMessageMap.keySet()) {
            String field = configvariable.expandValue(key);
            String errorMessage = configvariable.expandValue(errorMessageMap.get(key));
            softAssert.assertTrue(pulseRegistrationScreen.verifyValidationMessage(errorMessage), "validation message: " + errorMessage + " is displayed for field: " + field);
        }
        softAssert.assertAll();

    }

    @Then("^I verify the country code should be displayed correctly on phone number screen$")
    public void verifyCountryCode() {
        pulseRegistrationScreen.verifyCountryCode(TestBasePage.platform);
    }

    @Then("^I verify following field label should be displayed on registration screen$")
    public void verifyRegistrationScreenFieldLabel(DataTable dt) {
        List<String> fields = dt.asList(String.class);
        SoftAssert softAssert = new SoftAssert();
        for (String key : fields) {
            String fieldName = configvariable.expandValue(key);
            softAssert.assertTrue(pulseRegistrationScreen.verifyRegistrationScreenFieldLabel(fieldName), fieldName + " is displayed as expected");
        }
        softAssert.assertAll();
    }

    @Then("^I click on connect Later button$")
    public void clickOnConnectLaterBtn() {
        pulseRegistrationScreen.clickOnConnectLaterBtn();
    }

    @Then("^I click skip button$")
    public void iClickSkipButton() {
        pulseRegistrationScreen.clickSkipButton(TestBasePage.platform);
    }



    @Then("^verify validation message \"([^\"]*)\" on registration workflow screen$")
    public void verifyInvalidMsg(String invalidMsg) {
        String lbu = System.getProperty("app.lbu");
        if (!lbu.equalsIgnoreCase("ph")) {
            Assert.assertTrue(pulseRegistrationScreen.verifyInvalidMsg(configvariable.expandValue(invalidMsg)), invalidMsg);
        }
    }

    @Then("^I navigate to pulse registration page and select the lang on toggle bar then click on continue with email button$")
    public void navigateToRegistrationPageAndChangeTheLang() {
        String lbu = System.getProperty("app.lbu");
        if (!lbu.equalsIgnoreCase("sg")) {
            pulseRegistrationScreen.navigateToRegistrationPage();
            String lang = System.getProperty("app.language").toUpperCase();
            pulseRegistrationScreen.selectTheLanguageToggle(lang);
            pulseRegistrationScreen.selectContinueWithEmailBtn();
        }
    }

    @Then("^I select the language option on toggle bar as required on registration page$")
    public void selectTheLangOptionOnRegPage() {
        String lbu = System.getProperty("app.lbu");
        if (!lbu.equalsIgnoreCase("sg")) {
            String lang = System.getProperty("app.language").toUpperCase();
            pulseRegistrationScreen.selectTheLanguageToggle(lang);
        }

    }

    @And("^I enter NRIC number last (\\d+) digits \"([^\"]*)\"$")
    public void iEnterNRICNumberLastDigits(int arg0, String nricNumber) throws Throwable {
        pulseRegistrationScreen.enterNric(nricNumber);
    }

    @Then("^verify BMI validation message \"([^\"]*)\" on registration workflow screen$")
    public void verifyBMIMsg(String invalidMsg) {
        String lbu = System.getProperty("app.lbu");
        if (!lbu.equalsIgnoreCase("ph") || !lbu.equalsIgnoreCase("my")) {
            Assert.assertTrue(pulseRegistrationScreen.verifyInvalidMsg(configvariable.expandValue(invalidMsg)), invalidMsg);
        }
    }


    @Then("^I navigate to pulse registration page and select the lang on toggle bar$")
    public void navigateToRegPageAndSelectTheLangUsingToggle() {
        String lbu = System.getProperty("app.lbu");
        pulseRegistrationScreen.navigateToRegistrationPage();
        if (!lbu.equalsIgnoreCase("sg")) {
            String lang = System.getProperty("app.language").toUpperCase();
            pulseRegistrationScreen.selectTheLanguageToggle(lang);
        }
    }

//    @Then("^I click on connect with google button$")
//    public void selectConnectWithGoogleBtn() {
//        pulseRegistrationScreen.selectConnectWithGoogleBtn();
//    }
//
//    @Then("^I click on connect with facebook button$")
//    public void selectConnectWithFacebookBtn() {
//        pulseRegistrationScreen.selectConnectWithFacebookBtn();
//    }
//
//    @Then("^I wait for otp screen after clicking on signup button$")
//    public void verifyOTPScreen(){
//        pulseRegistrationScreen.verifyOTPScreenAfterSignUp();
//    }
//
//    @Then("^I click skip button for PH LBU registration flow$")
//    public void iClickSkipButtonPH() {
//        pulseRegistrationScreen.clickSkipButtonPH(TestBasePage.platform);
//    }
//
//
//    @Given("^I relaunch the app on registration failure$")
//    public void iRelaunchTheAppOnRegistrationFailure() {
//        pulseRegistrationScreen.relaunchApp(TestBasePage.platform, System.getProperty("app.lbu"));
//    }
//
//    @Then("^I click the Activate icon in registration screen$")
//    public void clickActivateIcon() {
//        pulseRegistrationScreen.clickActivateIcons();
//    }
//
//    @Then("^I skip the avatar screen if present$")
//    public void iClickAvatarSkipButton() {
//        pulseRegistrationScreen.clickAvatarSkipButton();
//    }
//
//    @Then("^I click the Activate button in Marketing Consent screen$")
//    public void iClickActivateMarketingConsent() {
//        pulseRegistrationScreen.clickActivateMarketingConsent();
//    }
//
//    @Then("^I complete the registration for \"([^\"]*)\" LBU$")
//    public void iCompleteTheRegistrationForLBU(String lbu) throws Throwable {
//        pulseRegistrationScreen.completeRegistrationPageValidation(configvariable.expandValue(lbu));
//    }
//    @Then("^I click skip button for TH LBU registration flow$")
//    public void iClickSkipButtonTH() {
//        pulseRegistrationScreen.clickSkipButtonTH(TestBasePage.platform);
//    }
//
//    @And("^I proceed with BMI page with continue$")
//    public void iProceedBMIPage() {
//        pulseRegistrationScreen.proceedBMI();
//
//    }
//
//    @And("^I select Excerice \"([^\"]*)\" in how active are you page$")
//    public void iSelectExerciseInHowActivePage(String arg0) throws Throwable {
//        pulseRegistrationScreen.activeExcericiseSelect();
//    }
//
//    @And("^I see welcome to pulse \"([^\"]*)\" text and continue$")
//    public void iSeeWelcomePulseIsDisplayed(String arg0) {
//        pulseRegistrationScreen.setWelcomePulseContinuePage();
//    }
//
//    @And("^I verify that \"([^\"]*)\" is displayed on Registration journey$")
//    public void verifyStaticTextDisplayed(String text) throws Throwable {
//        pulseRegistrationScreen.verifyStaticText(text);
//    }
//
//    @And("^User logs out from the current session$")
//    public void signOut(){
//        pulseRegistrationScreen.signOut();
//    }
//
//
//    @And("^I verify that \"([^\"]*)\" label is displayed on Registration journey$")
//    public void verifyStaticLabelDisplayed(String text) throws Throwable {
//        pulseRegistrationScreen.verifyLabelText(text);
//    }
//
//    @And("^I select \"([^\"]*)\" on \"([^\"]*)\" screen$")
//    public void selectOption(String text, String pageTitle) throws Throwable {
//        pulseRegistrationScreen.selectOption(text);
//    }



}



