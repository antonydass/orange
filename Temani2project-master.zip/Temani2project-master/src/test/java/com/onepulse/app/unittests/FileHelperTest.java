package com.onepulse.app.unittests;

import com.onepulse.app.utils.FileHelper;
import org.testng.annotations.Test;

public class FileHelperTest {

    private FileHelper fileHelper = new FileHelper();

    @Test
    public void testLoadLocalizationFile() {

      //  fileHelper.loadLocalizationFile("sg", "en", "Android");

    }
}
