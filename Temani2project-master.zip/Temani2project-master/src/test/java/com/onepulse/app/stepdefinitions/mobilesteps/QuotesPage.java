package com.onepulse.app.stepdefinitions.mobilesteps;

import com.onepulse.app.screens.TestBasePage;
import com.prod.tap.config.Configvariable;
import com.prod.tap.selenium.ExecutionContext;
import org.apache.log4j.Logger;
import org.openqa.selenium.ElementClickInterceptedException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.awt.*;
import java.util.List;
import java.util.Map;

@Component
public class QuotesPage {

    private static final Logger logger = Logger.getLogger(QuotesPage.class);
    @Autowired
    private TestBasePage testBasePage;

    @Autowired
    private ExecutionContext executionContext;

    @Autowired
    private Configvariable configvariable;

    public String searchTextField = "//input[@type='text'][@placeholder=\"${quote.search.field}\"]";
    public String filterButton = "//button[text()='${quote.filter.button}']";
    public String filterOptions = "//span[text()='%s']/following-sibling::span/input[@type='checkbox']";
    public String filterOptionsText = "//span[text()='%s']";
    public String searchNoFoundText = "//p[text()=\"${quote.no.quote.found.text}\"]";
    public String actionButton = "//div[contains(@class,\"UtilityDropDown-\")]/button";
    public String phActionButton = "//tbody//tr//td[5]/div/button[1]";
    public String actionOptions = "//button[text()='%s']";
    public String quotesTable = "//div";
    public String removeSearchTextButton = "//input[@placeholder='${quote.search.field}']/following-sibling::div";
    public String quotesTableLocator = "//thead//following-sibling::tbody/tr[1]";
    public String expiredQuoteInfoButton = "//div[@name='info']";

    public QuotesPage() {
    }

    public void getWelcomePageText() {
        this.testBasePage.getText("");
    }

    public void clickFilterButton() {
        this.testBasePage.clickButton(this.configvariable.expandValue(this.filterButton));
    }

    public boolean isSearchTextFound() {
        return this.testBasePage.isElementDisplayed(this.configvariable.expandValue(this.searchNoFoundText));
    }

    public boolean isSearchFieldEnabled() {
        return this.testBasePage.isElementEnabled(this.configvariable.expandValue(this.searchTextField));
    }

    public boolean isSearchFieldDisplayed() {
        return this.testBasePage.isElementDisplayed(this.configvariable.expandValue(this.searchTextField));
    }

    public boolean isFilterButtonEnabled() {
        return this.testBasePage.isElementEnabled(this.configvariable.expandValue(this.filterButton));
    }

    public boolean isFilterButtonDisplayed() {
        return this.testBasePage.isElementDisplayed(this.configvariable.expandValue(this.filterButton));
    }

    public void enterSearchCriteria(String searchVal) {
        this.testBasePage.scrollTillElementFound(this.configvariable.expandValue(this.searchTextField));
        this.testBasePage.clearText(this.configvariable.expandValue(this.searchTextField));
        this.testBasePage.enterTextCharByChar(this.configvariable.expandValue(this.searchTextField), this.configvariable.expandValue(searchVal.trim()));
        this.testBasePage.waitTime(5);
    }

    public boolean isFilterOptionDisplayed(String filterOption) {
        return this.testBasePage.isElementPresent(this.configvariable.getFormattedString(this.configvariable.expandValue(this.filterOptionsText), filterOption));
    }

    public void clickFilterOption(String filterOption) {
        String locator = this.configvariable.getFormattedString(this.configvariable.expandValue(this.filterOptions), filterOption);
        if (!this.testBasePage.isElementSelected(locator)) {
            this.testBasePage.clickButtonUsingJs(this.configvariable.getFormattedString(this.configvariable.expandValue(this.filterOptions), filterOption));
        }

    }



    public void clickActionOption(String action) {
        this.testBasePage.clickButton(this.configvariable.getFormattedString(this.configvariable.expandValue(this.actionOptions), action));
    }

    public void clickActionButton() {
        try {
            if (this.configvariable.getStringVar("sales.fe.lbu").equalsIgnoreCase("th")) {
                this.testBasePage.clickButton(this.actionButton);
            } else {
                this.testBasePage.clickButton(this.phActionButton);
            }
        } catch (ElementClickInterceptedException var2) {
            this.clickFilterButton();
            this.testBasePage.clickButton(this.actionButton);
        }

    }

    public int getSearchedRowCount() {
        return this.testBasePage.getTableRowsCount(this.quotesTable);
    }

    public boolean isQuotesPresentForOnlySearchedValue(String searchValue, String columnName) {
        int attempts = 0;
        boolean results = false;

        List columnData;
        for(columnData = null; attempts < 3; ++attempts) {
            try {
                columnData = this.testBasePage.getColumnDataForTdHeaders(this.quotesTable, columnName);
                results = true;
            } catch (Exception var7) {
                results = false;
            }

            if (results) {
                break;
            }
        }

        return columnData.contains(searchValue);
    }

    public boolean isActionOptionPresent(String actionOption) {
        return this.testBasePage.isElementDisplayed(this.configvariable.getFormattedString(this.configvariable.expandValue(this.actionOptions), actionOption));
    }

    public String getReferenceNumberForSearchedQuote() {
        Map<String, Integer> columns = this.testBasePage.getColumnIndexOfTableHeader(this.quotesTable);
        int columnNumber = (Integer)columns.get(this.configvariable.expandValue("${quote.table.header.reference.num}"));
        return this.testBasePage.getTableCellData(this.quotesTable, 1, columnNumber);
    }

    public List<String> getWebTableHeaders() {
        return this.testBasePage.getWebTableHeaderList(this.quotesTable);
    }

    public String getQuoteTableDetails(String columnName, int rowNumber) {
        Map<String, Integer> columns = this.testBasePage.getColumnIndexOfTableHeader(this.quotesTable);
        int columnNumber = (Integer)columns.get(columnName);
        return this.testBasePage.getTableCellData(this.quotesTable, rowNumber, columnNumber);
    }

    public int getRowCompanyRowNumber(String compName) {
        int rows = this.testBasePage.getTableRowsCount(this.quotesTable);
        int rowNumber = 0;

        for(int iRow = 1; iRow <= rows; ++iRow) {
            if (this.testBasePage.getTableCellData(this.quotesTable, iRow, 1).equalsIgnoreCase(compName)) {
                rowNumber = iRow;
                break;
            }
        }

        return rowNumber;
    }

    public void unSelectFilterOption(String filterOption) {
        String locator = this.configvariable.getFormattedString(this.configvariable.expandValue(this.filterOptions), filterOption);
        if (this.testBasePage.isElementSelected(locator)) {
            this.testBasePage.clickButtonUsingJs(this.configvariable.getFormattedString(this.configvariable.expandValue(this.filterOptions), filterOption));
        }

    }

    public void removeSearchText() {
        this.testBasePage.clickButton(this.configvariable.expandValue(this.removeSearchTextButton));
    }

    public boolean verifyVisibilityOfQuotesTable() {
        return this.testBasePage.isElementDisplayed(this.quotesTableLocator);
    }

    public void clickExpiredQuoteInfoButton() {
        this.testBasePage.clickButton(this.expiredQuoteInfoButton);
    }
}


