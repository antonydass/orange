package com.onepulse.app.locators.ios.mydoc;

import org.openqa.selenium.By;
import org.springframework.stereotype.Component;

@Component
public class IOSMyDocTnCLocator {

    public By legalAndPrivacy = By.xpath("(//XCUIElementTypeOther[@name='Legal & Privacy'])[2]");
    public By termsAndConditions = By.xpath("(//XCUIElementTypeOther[@name='Terms & Conditions'])[2]");
    public By termsAndConditionsText = By.xpath("//XCUIElementTypeStaticText[@name='Terms & Conditions']");
    public By myDocTnCLink = By.xpath("(//XCUIElementTypeOther[@name='MyDoc'])[2]");
    public By firstCross = By.xpath("(//XCUIElementTypeOther[contains(@name,\"MyDoc Terms & Conditions The Terms and Conditions were updated on 14 September 2019.\")])[12]/preceding::XCUIElementTypeOther[1]");
    public By secondCross = By.xpath("//XCUIElementTypeStaticText[@name=\"Terms & Conditions\"]/parent:: XCUIElementTypeOther/preceding-sibling::XCUIElementTypeOther/XCUIElementTypeOther");
    ////XCUIElementTypeStaticText[@name='Privacy Notice']/preceding::XCUIElementTypeOther[1]
    public By thirdCross = By.xpath("(//XCUIElementTypeOther[@name=\"Terms & Conditions\"])[1]/parent::XCUIElementTypeOther/preceding-sibling::XCUIElementTypeOther/XCUIElementTypeOther");
    public By altCross = By.xpath("(//XCUIElementTypeOther[@name='Terms & Conditions Pulse by Prudential'])[2]/XCUIElementTypeOther[1]/XCUIElementTypeOther");
    public By altCross2 = By.xpath("//XCUIElementTypeApplication[@name='Pulse']/XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther[2]/XCUIElementTypeOther[1]/XCUIElementTypeOther[1]/XCUIElementTypeOther/XCUIElementTypeOther[2]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther[1]/XCUIElementTypeOther");

}
