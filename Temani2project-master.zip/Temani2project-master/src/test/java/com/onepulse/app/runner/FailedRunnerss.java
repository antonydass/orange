package com.onepulse.app.runner;


import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
        monochrome = true,
        features = "classpath:features",

        glue = {"com/onepulse/app/stepdefinitions", "com/onepulse/app/cucumberhooks", "com/prod/tap/tapsteps"},
        // tags ={"@ConsultDoctor_BookAppointment,@ConsultDoctor_Editstart,@ConsultDoctor_startchat,@ConsultDoctor_Edit_BookingAppointment,@Dietician_Negative,@Dietician,@Mycommunties,@Mycommunties_facebook,@MyContentFirst,@HealthChannel,@Legal,@MySettings"},

        tags = {"@TestWeb", "~@ignore"},

        // tags = {"@SharewithfriendsE2E,@MydocConsultationSummary,@FileValidation,@babylonAnalLump,@babylonCall995,@babylonVirusRash,@babylonHernia,@babylonRib,@Legal,@onepulseRegistration,@onepulseLogin,@PulseEditProfile,@WealthRegistration,@WealthChannel,@MydocDocsDownload,@Wealth360ViewProduct,@WealthCallMeBack,@WealthNewGoalStatus,@RubyChatbot,@HealthChannel,@MyEvent,@WealthNewGoal,@WealthEditGoalAccountType,@Mycommunties,@MySettings,@WDailyFinancialBytes,@OptionalWealthRegistration,@MyDocEndToEndTest,@StoreLocator,@PruSafeCovidCover,@PruCancer360,@PruCovid19Protection,@PruSafeDengu,@EditPrivateRetirementGoal,@EditCustomizeLifestyle"},
        plugin = {"pretty", "html:target/site/cucumber-pretty",
                "json:reports/cucumber/cucumber.json","rerun:target/failedrerun.txt"}

)
public class FailedRunnerss {
}
