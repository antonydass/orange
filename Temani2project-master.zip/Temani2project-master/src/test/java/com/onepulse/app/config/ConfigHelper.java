package com.onepulse.app.config;

public class ConfigHelper {

   public static String MALINATOR_EMAIL = "wss://www.mailinator.com/ws/fetchinbox?zone=public&query=%s";
   public static String EMAIL_URL_FORMAT = "https://www.mailinator.com/fetch_email?";
//        "https://www.mailinator.com/v3/index.jsp?zone=public&query=taf-966231061030"
}
