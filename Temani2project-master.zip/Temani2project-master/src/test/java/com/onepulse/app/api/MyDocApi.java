package com.onepulse.app.api;
import com.onepulse.app.config.MyDocApiConstUtils;
import com.prod.tap.api.RestAPIMethods;
import com.prod.tap.config.Configvariable;
import com.prod.tap.exception.TapException;
import com.prod.tap.exception.TapExceptionType;
import io.restassured.response.Response;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;


@Component
public class MyDocApi {
    private final Logger logger = Logger.getLogger(MyDocApi.class);

    @Autowired
    private RestAPIMethods restAPIMethods;

    @Autowired
    private Configvariable configvariable;

    public static String DoctorId;
    public static String appointmentId;
    public static String loginAccessToken;

    public String loginToMyDoc(String myDocUsername, String myDocPassword) {
        logger.info("Doctor Name :" + myDocUsername +"   :  "+  "Password :" +myDocPassword );
        logger.info("Doctor Id : " +configvariable.getStringVar("DoctorId"));
        restAPIMethods.setApiBaseUri(Configvariable.envPropertyMap.get(MyDocApiConstUtils.MYDOC_BASE_URL));
        restAPIMethods.setApiEndPoint(MyDocApiConstUtils.MYDOC_LOGIN_ENDPOINT);
        restAPIMethods.setBasicAuthentication(myDocUsername, myDocPassword);
        Map<String, String> formData = new HashMap<>();
        formData.put("type", "diary");
        formData.put("client_id", MyDocApiConstUtils.MYDOC_CLIENT_ID);
        formData.put("client_secret", MyDocApiConstUtils.MYDOC_CLIENT_SECRETID);
        formData.put("username", myDocUsername);
        formData.put("password", myDocPassword);
        restAPIMethods.setBodyParam(formData);
        Response response = restAPIMethods.sendRequest("POST");
        logger.info(restAPIMethods.getResponseAsString());
        if (response.getStatusCode() != 200) {
            logger.error("Unable to hit MyDoc endpoint = " + configvariable.expandValue(MyDocApiConstUtils.MYDOC_LOGIN_ENDPOINT));
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "Unable to login to MyDoc using API [{}]", configvariable.expandValue(MyDocApiConstUtils.MYDOC_LOGIN_ENDPOINT));
        }
        loginAccessToken = response.jsonPath().get("data.authentication.access_token");
        String type = response.jsonPath().get("data.account.type[0]").toString();
        if (type.contains("patient")) {
            configvariable.setStringVariable(loginAccessToken, "patient_access_token");
            String patientID = response.jsonPath().get("data.account.id").toString();
            configvariable.setStringVariable(patientID, "mydoc_patient_id");
        } else if (type.contains("admin")) {
            configvariable.setStringVariable(loginAccessToken, "admin_access_token");
            String patientID = response.jsonPath().get("data.account.id").toString();
            configvariable.setStringVariable(patientID, "mydoc_admin_id");
        } else {
            configvariable.setStringVariable(loginAccessToken, "access_token");
        }
        return loginAccessToken;
    }

    public Response getApppointmentIdForPatient() {
        String appointmentId = "";
        String episodeId = "";
        String patientId = "";
        restAPIMethods.setApiBaseUri(Configvariable.envPropertyMap.get(MyDocApiConstUtils.MYDOC_BASE_URL));
        restAPIMethods.setApiEndPoint(configvariable.expandValue(MyDocApiConstUtils.MYDOC_APPOINTMENTS_ENDPOINT));
        Map<String, String> headers = new HashMap<>();
        headers.put("Authorization", "Bearer " + loginAccessToken);
        System.out.println(loginAccessToken);
        restAPIMethods.setHeaderParams(headers);
        Response response = restAPIMethods.sendRequest("GET");
        logger.info(restAPIMethods.getResponseAsString());
        if ((response.getStatusCode() != 200) || (response.jsonPath().get("total") == null)) {
            logger.error("Unable to hit MyDoc endpoint = " + configvariable.expandValue(MyDocApiConstUtils.MYDOC_APPOINTMENTS_ENDPOINT));
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "Unable to get appointment for doctor [{}]", configvariable.expandValue(MyDocApiConstUtils.MYDOC_APPOINTMENTS_ENDPOINT));
        }
        int totalAppointments = response.jsonPath().get("total");
        for (int iCount = 0; iCount < totalAppointments; iCount++) {
                appointmentId = response.jsonPath().get("data[" + iCount + "].id").toString();
                episodeId = response.jsonPath().get("data[" + iCount + "].episode_id").toString();
                patientId = response.jsonPath().get("data[" + iCount + "].patient.id").toString();
                break;
            }

        if (appointmentId.isEmpty()) {
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "Count not find appointment for patient [{}]");
        }

        configvariable.setStringVariable(appointmentId, "appointment_Id");
        logger.info("Appointment ID : " +appointmentId);
        configvariable.setStringVariable(episodeId, "EPISODE_ID");
        configvariable.setStringVariable(patientId, "PATIENT_ID");
        return response;
    }

    public Response doctorAcceptAppointment() {
        restAPIMethods.setApiBaseUri(Configvariable.envPropertyMap.get(MyDocApiConstUtils.MYDOC_BASE_URL));
        restAPIMethods.setApiEndPoint(configvariable.expandValue(MyDocApiConstUtils.MYDOC_ACCEPT_REJECT_ENDPOINT));
        Map<String, String> headers = new HashMap<>();
        Map<String, String> formData = new HashMap<>();
        formData.put("client_id", MyDocApiConstUtils.MYDOC_CLIENT_ID);
        formData.put("client_secret", MyDocApiConstUtils.MYDOC_CLIENT_SECRETID);
        restAPIMethods.setBodyParam(formData);
        Response response = restAPIMethods.sendRequest("POST");
        logger.info(restAPIMethods.getResponseAsString());
        if (response.getStatusCode() != 200) {
            logger.error("Unable to hit MyDoc endpoint = " + configvariable.expandValue(MyDocApiConstUtils.MYDOC_ACCEPT_REJECT_ENDPOINT));
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "Doctor not able to appoint appointment using MyDoc API [{}]", configvariable.expandValue(MyDocApiConstUtils.MYDOC_ACCEPT_REJECT_ENDPOINT));
        }
        return response;
    }

    public String getPatientID(String patientEmail) {
        String patientID = "";
        restAPIMethods.setApiBaseUri(Configvariable.envPropertyMap.get(MyDocApiConstUtils.MYDOC_BASE_URL));
        restAPIMethods.setApiEndPoint(configvariable.expandValue(MyDocApiConstUtils.MYDOC_SEARCH_PATIENT_ENDPOINT));
        Map<String, String> headers = new HashMap<>();
        headers.put("Authorization", "Bearer " + configvariable.getStringVar("access_token"));
        restAPIMethods.setHeaderParams(headers);
        Response response = restAPIMethods.sendRequest("GET");
        logger.info(restAPIMethods.getResponseAsString());
        if (response.getStatusCode() != 200 || response.jsonPath().get("total") == null) {
            logger.error("Unable to hit MyDoc endpoint = " + configvariable.expandValue(MyDocApiConstUtils.MYDOC_SEARCH_PATIENT_ENDPOINT));
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "Unale to get patient ID using MyDoc API [{}]", configvariable.expandValue(MyDocApiConstUtils.MYDOC_SEARCH_PATIENT_ENDPOINT));
        }
        int totalPatients = response.jsonPath().get("total");
        for (int iCount = 0; iCount < totalPatients; iCount++) {
            if (response.jsonPath().get("data[" + iCount + "].email") != null && response.jsonPath().get("data[" + iCount + "].email").equals(configvariable.expandValue(patientEmail).toLowerCase())) {
                patientID = response.jsonPath().get("data[" + iCount + "].id").toString();
                break;
            }
        }

        if (patientID.isEmpty()) {
            logger.error("Count not find patient id for patient = " + configvariable.expandValue(patientEmail));
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "Count not find patient id for patient [{}] using MyDoc API ", configvariable.expandValue(patientEmail));
        }

        return patientID;
    }

    public Response createEpisode(String patientID, String myDocUserID) {
        restAPIMethods.setApiBaseUri(Configvariable.envPropertyMap.get(MyDocApiConstUtils.MYDOC_BASE_URL));
        restAPIMethods.setApiEndPoint(configvariable.expandValue(MyDocApiConstUtils.MYDOC_CREATE_EPISODE_ENDPOINT));
        Map<String, String> headers = new HashMap<>();
        headers.put("Authorization", "Bearer " + configvariable.getStringVar("access_token"));
        restAPIMethods.setHeaderParams(headers);
        Map<String, String> formData = new HashMap<>();
        formData.put("subject", "Episode Automation");
        formData.put("type", "callcentre");
        formData.put("group_id", MyDocApiConstUtils.MYDOC_GROUPID);
        formData.put("participants[]", patientID);
        restAPIMethods.setBodyParam(formData);
        restAPIMethods.setBodyParam("participants[]", myDocUserID);
        Response response = restAPIMethods.sendRequest("POST");
        logger.info(restAPIMethods.getResponseAsString());
        if (restAPIMethods.getStatusCode() != 200) {
            logger.error("Unable to hit MyDoc endpoint = " + configvariable.expandValue(MyDocApiConstUtils.MYDOC_CREATE_EPISODE_ENDPOINT));
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "Unable to create Episode using MyDoc API [{}]", configvariable.expandValue(MyDocApiConstUtils.MYDOC_CREATE_EPISODE_ENDPOINT));
        }
        String episodeID = response.jsonPath().get("data.id").toString();
        configvariable.setStringVariable(episodeID, "EPISODE_ID");
        return response;
    }

    public void sendEpisodeMessage(String message) {
        restAPIMethods.setApiBaseUri(Configvariable.envPropertyMap.get(MyDocApiConstUtils.MYDOC_BASE_URL));
        restAPIMethods.setApiEndPoint(configvariable.expandValue(MyDocApiConstUtils.MYDOC_SEND_MESSAGE_ENDPOINT));
        Map<String, String> headers = new HashMap<>();
        headers.put("Authorization", "Bearer " + configvariable.getStringVar("access_token"));
        restAPIMethods.setHeaderParams(headers);
        Map<String, String> formData = new HashMap<>();
        formData.put("type", "message");
        formData.put("content", message);
        formData.put("episode_id", configvariable.getStringVar("EPISODE_ID"));
        restAPIMethods.setBodyParam(formData);
        Response response = restAPIMethods.sendRequest("POST");
        logger.info(restAPIMethods.getResponseAsString());
        if (response.getStatusCode() != 200) {
            logger.error("Unable to hit MyDoc endpoint = " + configvariable.expandValue(MyDocApiConstUtils.MYDOC_SEND_MESSAGE_ENDPOINT));
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "Unable to send Message using MyDoc API [{}]", configvariable.expandValue(MyDocApiConstUtils.MYDOC_SEND_MESSAGE_ENDPOINT));
        }

    }

    public Response createEmc() {
        restAPIMethods.setApiBaseUri(Configvariable.envPropertyMap.get(MyDocApiConstUtils.MYDOC_BASE_URL));
        restAPIMethods.setApiEndPoint(configvariable.expandValue(MyDocApiConstUtils.MYDOC_CREATE_EMC_ENDPOINT));
        Map<String, String> headers = new HashMap<>();
        headers.put("Authorization", "Bearer " + configvariable.getStringVar("access_token"));
        restAPIMethods.setHeaderParams(headers);
        Map<String, String> formData = new HashMap<>();
        formData.put("reason", "Headache");
        formData.put("group_id", MyDocApiConstUtils.MYDOC_GROUPID);
        formData.put("patient_id", configvariable.getStringVar("PATIENT_ID"));
        formData.put("start_date", configvariable.generateRandomNumber("YYYY-MM-dd"));
        formData.put("end_date", configvariable.generateRandomNumber("YYYY-MM-dd"));
        restAPIMethods.setBodyParam(formData);
        Response response = restAPIMethods.sendRequest("POST");
        logger.info(restAPIMethods.getResponseAsString());
        if (restAPIMethods.getStatusCode() != 200) {
            logger.error("Unable to hit MyDoc endpoint = " + configvariable.expandValue(MyDocApiConstUtils.MYDOC_CREATE_EMC_ENDPOINT));
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "Unable to create EMD using MyDoc API [{}]", configvariable.expandValue(MyDocApiConstUtils.MYDOC_CREATE_EMC_ENDPOINT));
        }
        String episodeID = response.jsonPath().get("data.id").toString();
        configvariable.setStringVariable(episodeID, "EMC_ID");
        return response;
    }

    public Response sendEmc() {
        restAPIMethods.setApiBaseUri(Configvariable.envPropertyMap.get(MyDocApiConstUtils.MYDOC_BASE_URL));
        restAPIMethods.setApiEndPoint(configvariable.expandValue(MyDocApiConstUtils.MYDOC_SEND_EMC_ENDPOINT));
        Map<String, String> headers = new HashMap<>();
        headers.put("Authorization", "Bearer " + configvariable.getStringVar("access_token"));
        restAPIMethods.setHeaderParams(headers);
        Map<String, String> formData = new HashMap<>();
        formData.put("episode_id", configvariable.getStringVar("EPISODE_ID"));
        restAPIMethods.setBodyParam(formData);
        Response response = restAPIMethods.sendRequest("POST");
        logger.info(restAPIMethods.getResponseAsString());
        if (response.getStatusCode() != 200 || response.jsonPath().get("data.file").toString() == null) {
            logger.error("Unable to hit MyDoc endpoint = " + configvariable.expandValue(MyDocApiConstUtils.MYDOC_SEND_EMC_ENDPOINT));
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "EMC not generated from MyDocAPI [{}]", configvariable.expandValue(MyDocApiConstUtils.MYDOC_SEND_EMC_ENDPOINT));
        }

        String emcFileName = response.jsonPath().get("data.file").toString();
        if (!emcFileName.isEmpty()) {
            String[] parts = emcFileName.split("/");
            emcFileName = parts[parts.length - 1];
            configvariable.setStringVariable(emcFileName, "EMC_FILE_NAME");
        } else {
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "EMC not generated from MyDocAPI [{}]", configvariable.expandValue(MyDocApiConstUtils.MYDOC_SEND_EMC_ENDPOINT));
        }
        return response;
    }

    public Response createCaseNoteForPatient() {
        restAPIMethods.setApiBaseUri(Configvariable.envPropertyMap.get(MyDocApiConstUtils.MYDOC_BASE_URL));
        restAPIMethods.setApiEndPoint(configvariable.expandValue(MyDocApiConstUtils.MYDOC_CREATE_CASENOTE_ENDPOINT));
        Map<String, String> headers = new HashMap<>();
        headers.put("Authorization", "Bearer " + configvariable.getStringVar("access_token"));
        restAPIMethods.setHeaderParams(headers);
        Map<String, String> formData = new HashMap<>();
        formData.put("episode_id", configvariable.getStringVar("EPISODE_ID"));
        formData.put("consult_for", configvariable.expandValue("${CONSULT_FOR}"));
        formData.put("gp_visit", "true");
        formData.put("ae_visit", "false");
        formData.put("patient_id", configvariable.getStringVar("PATIENT_ID"));
        formData.put("patient_note", "2 days rest");
        formData.put("pro_note", "MBFC Doctor");
        formData.put("icd10_code_ids[]", "4");
        restAPIMethods.setBodyParam(formData);
        Response response = restAPIMethods.sendRequest("POST");
        logger.info(restAPIMethods.getResponseAsString());
        if (restAPIMethods.getStatusCode() != 200) {
            logger.error("Unable to hit MyDoc endpoint = " + configvariable.expandValue(MyDocApiConstUtils.MYDOC_CREATE_EMC_ENDPOINT));
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "Unable to create case note using MyDoc API [{}]", configvariable.expandValue(MyDocApiConstUtils.MYDOC_CREATE_EMC_ENDPOINT));
        }
        String caseNoteID = response.jsonPath().get("data.id").toString();
        configvariable.setStringVariable(caseNoteID, "CASE_NOTE_ID");
        return response;

    }

    public void closeConsultationForPatient() {
        restAPIMethods.setApiBaseUri(Configvariable.envPropertyMap.get(MyDocApiConstUtils.MYDOC_BASE_URL));
        restAPIMethods.setApiEndPoint(configvariable.expandValue(MyDocApiConstUtils.MYDOC_CLOSE_CASENOTE_ENDPOINT));
        Map<String, String> headers = new HashMap<>();
        headers.put("Authorization", "Bearer " + configvariable.getStringVar("access_token"));
        restAPIMethods.setHeaderParams(headers);
        Map<String, String> formData = new HashMap<>();
        formData.put("reason", "completed");
        restAPIMethods.setBodyParam(formData);
        Response response = restAPIMethods.sendRequest("PUT");
        if (response.getStatusCode() != 200) {
            logger.error("Unable to hit MyDoc endpoint = " + configvariable.expandValue(MyDocApiConstUtils.MYDOC_ACCEPT_REJECT_ENDPOINT));
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "Doctor not able to close consultation using MyDoc API [{}]", configvariable.expandValue(MyDocApiConstUtils.MYDOC_ACCEPT_REJECT_ENDPOINT));
        }
    }

    public Response doctorRejectAppointment() {
        restAPIMethods.setApiBaseUri(Configvariable.envPropertyMap.get(MyDocApiConstUtils.MYDOC_BASE_URL));
        restAPIMethods.setApiEndPoint(configvariable.expandValue(MyDocApiConstUtils.MYDOC_ACCEPT_REJECT_ENDPOINT));
        Map<String, String> headers = new HashMap<>();
        headers.put("Authorization", "Bearer " + configvariable.getStringVar("access_token"));
        restAPIMethods.setHeaderParams(headers);
        Map<String, String> formData = new HashMap<>();
        formData.put("doctor_account_id", configvariable.getStringVar("DoctorId"));
        formData.put("start_at", configvariable.generateRandomNumber("yyyy-MM-dd'T'HH:mm:ss"));
        formData.put("duration", "15");
        formData.put("type", "clinic");
        formData.put("timezone", "utc");
        formData.put("status", "rejected");
        formData.put("patient_account_id", configvariable.expandValue("${PATIENT_ID}"));
        restAPIMethods.setBodyParam(formData);
        Response response = restAPIMethods.sendRequest("PUT");
        logger.info(restAPIMethods.getResponseAsString());
        if (response.getStatusCode() != 200) {
            logger.error("Unable to hit MyDoc endpoint = " + configvariable.expandValue(MyDocApiConstUtils.MYDOC_ACCEPT_REJECT_ENDPOINT));
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "Doctor not able to reject appointment using MyDoc API [{}]", configvariable.expandValue(MyDocApiConstUtils.MYDOC_ACCEPT_REJECT_ENDPOINT));
        }
        return response;
    }

    public Response getEpisodeMessages(String messageType) {
        String message = "";
        restAPIMethods.setApiBaseUri(Configvariable.envPropertyMap.get(MyDocApiConstUtils.MYDOC_BASE_URL));
        restAPIMethods.setApiEndPoint(configvariable.expandValue(MyDocApiConstUtils.MYDOC_GET_MESSAGE_ENDPOINT));
        Map<String, String> headers = new HashMap<>();
        headers.put("Authorization", "Bearer " + configvariable.getStringVar("access_token"));
        restAPIMethods.setHeaderParams(headers);
        Response response = restAPIMethods.sendRequest("GET");
        logger.info(restAPIMethods.getResponseAsString());
        if (response.getStatusCode() != 200 || response.jsonPath().get("total") == null) {
            logger.error("Unable to hit MyDoc endpoint = " + configvariable.expandValue(MyDocApiConstUtils.MYDOC_GET_MESSAGE_ENDPOINT));
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "Unable to get the episode messages using MyDoc API [{}]", configvariable.expandValue(MyDocApiConstUtils.MYDOC_GET_MESSAGE_ENDPOINT));
        }
        int totalMessages = response.jsonPath().get("total");
        if (messageType.equalsIgnoreCase("image")) {
            for (int iCount = 0; iCount < totalMessages; iCount++) {
                if (response.jsonPath().get("data[" + iCount + "].attachment") != null && response.jsonPath().get("data[" + iCount + "].attachment.type").toString().equalsIgnoreCase("image")) {
                    message = response.jsonPath().get("data[" + iCount + "].attachment.url").toString();
                    configvariable.setStringVariable(message, "mydoc_received_messages");
                    //message = response.jsonPath().get("data[" + iCount + "].attachment.url").toString();
                    break;
                }
            }
        } else {
            for (int iCount = 0; iCount < totalMessages; iCount++) {
                if (response.jsonPath().get("data[" + iCount + "].content") != null && response.jsonPath().get("data[" + iCount + "].type").toString().equalsIgnoreCase("message")) {
                    message = response.jsonPath().get("data[" + iCount + "].content").toString();
                    configvariable.setStringVariable(message, "mydoc_received_messages");

                    break;
                }
            }
        }
        if (message.isEmpty()) {
            logger.error("Doctor didn't receive the message");
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "could not get the message using MyDoc API [{}]", configvariable.expandValue(MyDocApiConstUtils.MYDOC_GET_MESSAGE_ENDPOINT));
        }
        return response;
    }

    public Response createAppointment() {
        restAPIMethods.setApiBaseUri(Configvariable.envPropertyMap.get(MyDocApiConstUtils.MYDOC_BASE_URL));
        restAPIMethods.setApiEndPoint(configvariable.expandValue(MyDocApiConstUtils.MYDOC_CREATE_APPOINTMENT_ENDPOINT));
        Map<String, String> headers = new HashMap<>();
        headers.put("Authorization", "Bearer " + configvariable.getStringVar("patient_access_token"));
        restAPIMethods.setHeaderParams(headers);
        Map<String, String> formData = new HashMap<>();
        formData.put("start_at", configvariable.getStringVar("FROM_DATE") + " " + configvariable.getStringVar("START_TIME"));
        formData.put("duration", configvariable.getStringVar("DURATION"));
        formData.put("timezone", "Asia/Singapore");
        formData.put("patient_account_id", configvariable.getStringVar("PATIENT_ID"));
        formData.put("type", "clinic");
        formData.put("status", "pending");
        formData.put("episode_id", configvariable.getStringVar("EPISODE_ID"));
        restAPIMethods.setBodyParam(formData);
        Response response = restAPIMethods.sendRequest("POST");
        logger.info(restAPIMethods.getResponseAsString());
        if (restAPIMethods.getStatusCode() != 200) {
            logger.error("Unable to hit MyDoc endpoint = " + configvariable.expandValue(MyDocApiConstUtils.MYDOC_CREATE_APPOINTMENT_ENDPOINT));
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "Unable to create appointment using MyDoc API [{}]", configvariable.expandValue(MyDocApiConstUtils.MYDOC_CREATE_APPOINTMENT_ENDPOINT));
        }
        String appointmentID = response.jsonPath().get("data.id").toString();
        configvariable.setStringVariable(appointmentID, "APPOINTMENT_ID");
        return response;
    }

    public void addNricToPatient() {
        restAPIMethods.setApiBaseUri(Configvariable.envPropertyMap.get(MyDocApiConstUtils.MYDOC_BASE_URL));
        restAPIMethods.setApiEndPoint(configvariable.expandValue(MyDocApiConstUtils.MYDOC_ADD_NRIC_PATIENT_ENDPOINT));
        Map<String, String> headers = new HashMap<>();
        headers.put("Authorization", "Bearer " + configvariable.getStringVar("patient_access_token"));
        headers.put("Content-Type", "application/x-www-form-urlencoded");
        restAPIMethods.setHeaderParams(headers);
        Map<String, String> formData = new HashMap<>();
        formData.put("identities[]", "\"{\"country_identity_id\":\"1\"}");
        restAPIMethods.setBodyParam(formData);
        restAPIMethods.setBodyParam("identities[]", "\"{\"value\":\"ABC123DEF\"}");

        Response response = restAPIMethods.sendRequest("POST");
        logger.info(restAPIMethods.getResponseAsString());
        if (restAPIMethods.getStatusCode() != 200) {
            logger.error("Unable to hit MyDoc endpoint = " + configvariable.expandValue(MyDocApiConstUtils.MYDOC_ADD_NRIC_PATIENT_ENDPOINT));
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "Unable to add NRIC using MyDoc API [{}]", configvariable.expandValue(MyDocApiConstUtils.MYDOC_ADD_NRIC_PATIENT_ENDPOINT));
        }
        String accountIdentitiesID = response.jsonPath().get("data.id");
        configvariable.setStringVariable(accountIdentitiesID, "account_identities_id");
    }

    public Response getAccountID(String accountId) {
        restAPIMethods.setApiBaseUri(Configvariable.envPropertyMap.get(MyDocApiConstUtils.MYDOC_BASE_URL));
        restAPIMethods.setApiEndPoint(configvariable.expandValue(MyDocApiConstUtils.MYDOC_GET_ACCT_ENDPOINT));
        Map<String, String> headers = new HashMap<>();
        headers.put("Authorization", "Bearer " + configvariable.getStringVar("access_token"));
        restAPIMethods.setHeaderParams(headers);
        Response response = restAPIMethods.sendRequest("GET");
        logger.info(restAPIMethods.getResponseAsString());
        if (response.getStatusCode() != 200) {
            logger.error("Unable to hit MyDoc endpoint = " + configvariable.expandValue(MyDocApiConstUtils.MYDOC_GET_ACCT_ENDPOINT));
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "Unable to get account details using MyDoc API [{}]", configvariable.expandValue(MyDocApiConstUtils.MYDOC_GET_ACCT_ENDPOINT));
        } else {
            return response;
        }
    }

    public Response getAccountGroupID(String accountId) {
        restAPIMethods.setApiBaseUri(Configvariable.envPropertyMap.get(MyDocApiConstUtils.MYDOC_BASE_URL));
        restAPIMethods.setApiEndPoint(configvariable.expandValue(MyDocApiConstUtils.MYDOC_GET_ACCTGROUPS));
        Map<String, String> headers = new HashMap<>();
        headers.put("Authorization", "Bearer " + configvariable.getStringVar("access_token"));
        restAPIMethods.setHeaderParams(headers);
        Response response = restAPIMethods.sendRequest("GET");
        logger.info(restAPIMethods.getResponseAsString());
        if (response.getStatusCode() != 200) {
            logger.error("Unable to hit MyDoc endpoint = " + configvariable.expandValue(MyDocApiConstUtils.MYDOC_GET_ACCTGROUPS));
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "Unable to get account group details using MyDoc API [{}]", configvariable.expandValue(MyDocApiConstUtils.MYDOC_GET_ACCTGROUPS));
        } else {
            return response;
        }
    }

    public Response updateAccountDetails(String accountId) {
        restAPIMethods.setApiBaseUri(Configvariable.envPropertyMap.get(MyDocApiConstUtils.MYDOC_BASE_URL));
        restAPIMethods.setApiEndPoint(configvariable.expandValue(MyDocApiConstUtils.MYDOC_GET_ACCT_ENDPOINT));
        Map<String, String> headers = new HashMap<>();
        headers.put("Authorization", "Bearer " + configvariable.getStringVar("patient_access_token"));
        restAPIMethods.setHeaderParams(headers);
        Map<String, String> formData = new HashMap<>();
        formData.put("first_name", configvariable.getStringVar("PATIENT_UPDATED_FIRSTNAME"));
        formData.put("last_name", configvariable.getStringVar("PATIENT_UPDATED_LASTNAME"));
        formData.put("gender", configvariable.getStringVar("PATIENT_UPDATED_GENDER"));
        formData.put("title", configvariable.getStringVar("PATIENT_UPDAED_TITLE"));
        formData.put("birthday", configvariable.getStringVar("PATIENT_UPDATED_DOB"));
        formData.put("contact", configvariable.getStringVar("PATIENT_UPDATED_CONTACT"));
        restAPIMethods.setBodyParam(formData);
        Response response = restAPIMethods.sendRequest("PUT");
        logger.info(restAPIMethods.getResponseAsString());
        if (response.getStatusCode() != 200) {
            logger.error("Unable to hit MyDoc endpoint = " + configvariable.expandValue(MyDocApiConstUtils.MYDOC_GET_ACCT_ENDPOINT));
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "User not able to update account details using MyDoc API [{}]", configvariable.expandValue(MyDocApiConstUtils.MYDOC_GET_ACCT_ENDPOINT));
        }
        return response;
    }

    public Response getGroups() {
        restAPIMethods.setApiBaseUri(Configvariable.envPropertyMap.get(MyDocApiConstUtils.MYDOC_BASE_URL));
        restAPIMethods.setApiEndPoint(configvariable.expandValue(MyDocApiConstUtils.MYDOC_GET_GROUPS));
        Map<String, String> headers = new HashMap<>();
        restAPIMethods.setHeaderParams(headers);
        Response response = restAPIMethods.sendRequest("GET");
        logger.info(restAPIMethods.getResponseAsString());
        if (response.getStatusCode() != 200) {
            logger.error("Unable to hit MyDoc endpoint = " + configvariable.expandValue(MyDocApiConstUtils.MYDOC_GET_GROUPS));
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "Unable to get group details with admin access using MyDoc API [{}]", configvariable.expandValue(MyDocApiConstUtils.MYDOC_GET_GROUPS));
        } else {
            return response;
        }
    }

    public Response getAvailableDoctor() {
        restAPIMethods.setApiBaseUri(Configvariable.envPropertyMap.get(MyDocApiConstUtils.MYDOC_BASE_URL));
        restAPIMethods.setApiEndPoint(configvariable.expandValue(MyDocApiConstUtils.MYDOC_AVAILABLE_PROFESSIONALS_ENDPOINT));
        Map<String, String> headers = new HashMap<>();
        headers.put("Authorization", "Bearer " + configvariable.getStringVar("patient_access_token"));
        restAPIMethods.setHeaderParams(headers);
        Response response = restAPIMethods.sendRequest("GET");
        logger.info(restAPIMethods.getResponseAsString());
        if (response.getStatusCode() != 200) {
            logger.error("Unable to hit MyDoc endpoint = " + configvariable.expandValue(MyDocApiConstUtils.MYDOC_AVAILABLE_PROFESSIONALS_ENDPOINT));
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "Doctor not able to get the available doctor using MyDoc API [{}]", configvariable.expandValue(MyDocApiConstUtils.MYDOC_AVAILABLE_PROFESSIONALS_ENDPOINT));
        }
        return response;
    }

    public Response createEmergencyContacts() {
        restAPIMethods.setApiBaseUri(Configvariable.envPropertyMap.get(MyDocApiConstUtils.MYDOC_BASE_URL));
        restAPIMethods.setApiEndPoint(configvariable.expandValue(MyDocApiConstUtils.MYDOC_CREATE_GET__EMERGENCYCONTACTS_ENDPOINT));
        Map<String, String> headers = new HashMap<>();
        headers.put("Authorization", "Bearer " + configvariable.getStringVar("patient_access_token"));
        headers.put("Content-Type", "application/json");
        restAPIMethods.setHeaderParams(headers);
        String requestBody = "{\"contacts\":[{\"name\":" + "\"" + configvariable.getStringVar("EMERGENCY_CONTACT_NAME") + "\"" + ",\"contact\":" + "\"" + configvariable.getStringVar("EMERGENCY_CONTACT") + "\"" + "}]}";
        restAPIMethods.setBodyParam(requestBody);
        Response response = restAPIMethods.sendRequest("POST");
        logger.info(restAPIMethods.getResponseAsString());
        if (response.getStatusCode() != 200) {
            logger.error("Unable to hit MyDoc endpoint = " + configvariable.expandValue(MyDocApiConstUtils.MYDOC_CREATE_GET__EMERGENCYCONTACTS_ENDPOINT));
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "unable to add the emergency contact using MyDoc API [{}]", configvariable.expandValue(MyDocApiConstUtils.MYDOC_CREATE_GET__EMERGENCYCONTACTS_ENDPOINT));
        }
        return response;
    }

    public Response updateEmergencyContacts() {
        restAPIMethods.setApiBaseUri(Configvariable.envPropertyMap.get(MyDocApiConstUtils.MYDOC_BASE_URL));
        restAPIMethods.setApiEndPoint(configvariable.expandValue(MyDocApiConstUtils.MYDOC_UPDATE_DELETE_EMERGENCYCONTACTS_ENDPOINT));
        Map<String, String> headers = new HashMap<>();
        headers.put("Authorization", "Bearer " + configvariable.getStringVar("patient_access_token"));
        headers.put("Content-Type", "application/json");
        restAPIMethods.setHeaderParams(headers);
        String requestBody = "{\"contacts\":[{\"name\":" + "\"" + configvariable.getStringVar("EMERGENCY_CONTACT_NAME") + "\"" + ",\"contact\":" + "\"" + configvariable.getStringVar("EMERGENCY_CONTACT") + "\"" + "}]}";
        restAPIMethods.setBodyParam(requestBody);
        Response response = restAPIMethods.sendRequest("PUT");
        logger.info(restAPIMethods.getResponseAsString());
        if (response.getStatusCode() != 200) {
            logger.error("Unable to hit MyDoc endpoint = " + configvariable.expandValue(MyDocApiConstUtils.MYDOC_UPDATE_DELETE_EMERGENCYCONTACTS_ENDPOINT));
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "unable to update the emergency contact using MyDoc API [{}]", configvariable.expandValue(MyDocApiConstUtils.MYDOC_UPDATE_DELETE_EMERGENCYCONTACTS_ENDPOINT));
        }
        return response;
    }

    public Response getEmergencyContacts() {
        restAPIMethods.setApiBaseUri(Configvariable.envPropertyMap.get(MyDocApiConstUtils.MYDOC_BASE_URL));
        restAPIMethods.setApiEndPoint(configvariable.expandValue(MyDocApiConstUtils.MYDOC_CREATE_GET__EMERGENCYCONTACTS_ENDPOINT));
        Map<String, String> headers = new HashMap<>();
        headers.put("Authorization", "Bearer " + configvariable.getStringVar("patient_access_token"));
        restAPIMethods.setHeaderParams(headers);
        Response response = restAPIMethods.sendRequest("GET");
        logger.info(restAPIMethods.getResponseAsString());
        if (response.getStatusCode() != 200) {
            logger.error("Unable to hit MyDoc endpoint = " + configvariable.expandValue(MyDocApiConstUtils.MYDOC_CREATE_GET__EMERGENCYCONTACTS_ENDPOINT));
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "unable to fetch the emergency contact using MyDoc API [{}]", configvariable.expandValue(MyDocApiConstUtils.MYDOC_CREATE_GET__EMERGENCYCONTACTS_ENDPOINT));
        }
        return response;
    }

    public Response deleteEmergencyContacts() {
        restAPIMethods.setApiBaseUri(Configvariable.envPropertyMap.get(MyDocApiConstUtils.MYDOC_BASE_URL));
        restAPIMethods.setApiEndPoint(configvariable.expandValue(MyDocApiConstUtils.MYDOC_UPDATE_DELETE_EMERGENCYCONTACTS_ENDPOINT));
        Map<String, String> headers = new HashMap<>();
        headers.put("Authorization", "Bearer " + configvariable.getStringVar("patient_access_token"));
        restAPIMethods.setHeaderParams(headers);
        Response response = restAPIMethods.sendRequest("DELETE");
        logger.info(restAPIMethods.getResponseAsString());
        if (response.getStatusCode() != 200) {
            logger.error("Unable to hit MyDoc endpoint = " + configvariable.expandValue(MyDocApiConstUtils.MYDOC_UPDATE_DELETE_EMERGENCYCONTACTS_ENDPOINT));
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "unable to delete the emergency contact using MyDoc API [{}]", configvariable.expandValue(MyDocApiConstUtils.MYDOC_UPDATE_DELETE_EMERGENCYCONTACTS_ENDPOINT));
        }
        return response;
    }

    // One Pulse --

    public void verifyPruPatient() {
        restAPIMethods.setApiBaseUri(Configvariable.envPropertyMap.get(MyDocApiConstUtils.MYDOC_BASE_URL));
        restAPIMethods.setApiEndPoint(configvariable.expandValue(MyDocApiConstUtils.MYDOC_PATIENT_VERIFY));
        Map<String, String> formData = new HashMap<>();
        formData.put("client_id", MyDocApiConstUtils.MYDOC_CLIENT_ID);
        formData.put("client_secret", MyDocApiConstUtils.MYDOC_CLIENT_SECRETID);
        formData.put("contact", configvariable.getStringVar("PATIENT_CONTACT"));
        formData.put("email", configvariable.expandValue("${PATIENT_EMAIL}"));
        restAPIMethods.setBodyParam(formData);
        Response response = restAPIMethods.sendRequest("POST");
        logger.info(restAPIMethods.getResponseAsString());
        if (restAPIMethods.getStatusCode() != 200) {
            logger.error("Unable to hit MyDoc endpoint = " + configvariable.expandValue(MyDocApiConstUtils.MYDOC_PATIENT_VERIFY));
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "Unable to create patient using MyDoc API [{}]", configvariable.expandValue(MyDocApiConstUtils.MYDOC_PATIENT_VERIFY));
        }
    }

    public void createPatient() {
        restAPIMethods.setApiBaseUri(Configvariable.envPropertyMap.get(MyDocApiConstUtils.MYDOC_BASE_URL));
        restAPIMethods.setApiEndPoint(configvariable.expandValue(MyDocApiConstUtils.MYDOC_CREATE_PATIENT_ENDPOINT));
        Map<String, String> formData = new HashMap<>();
        formData.put("client_id", MyDocApiConstUtils.MYDOC_CLIENT_ID);
        formData.put("client_secret", MyDocApiConstUtils.MYDOC_CLIENT_SECRETID);
        formData.put("name", configvariable.expandValue("${PATIENT_NAME}"));
        formData.put("email", configvariable.expandValue("${PATIENT_EMAIL}"));
        formData.put("password", configvariable.getStringVar("PATIENT_PASSWORD"));
        formData.put("password_confirmation", configvariable.getStringVar("PATIENT_PASSWORD"));
        formData.put("birthday", configvariable.getStringVar("PATIENT_DOB"));
        formData.put("title", configvariable.getStringVar("PATIENT_TITLE"));
        formData.put("contact", configvariable.getStringVar("PATIENT_CONTACT"));
        formData.put("validation_code", configvariable.getStringVar("VALIDATION_CODE"));
        formData.put("gender", configvariable.getStringVar("PATIENT_GENDER"));
        formData.put("group_id", MyDocApiConstUtils.MYDOC_GROUPID);
        formData.put("preferred_language", configvariable.getStringVar("LANG_PREF"));
        formData.put("sendEmail", configvariable.getStringVar("SEND_EMAIL"));

        restAPIMethods.setBodyParam(formData);
        Response response = restAPIMethods.sendRequest("POST");
        logger.info(restAPIMethods.getResponseAsString());
        if (restAPIMethods.getStatusCode() != 200) {
            logger.error("Unable to hit MyDoc endpoint = " + configvariable.expandValue(MyDocApiConstUtils.MYDOC_CREATE_PATIENT_ENDPOINT));
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "Unable to create patient using MyDoc API [{}]", configvariable.expandValue(MyDocApiConstUtils.MYDOC_CREATE_PATIENT_ENDPOINT));
        }
    }

    public void getPruAccessToken() {
        restAPIMethods.setApiBaseUri(Configvariable.envPropertyMap.get(MyDocApiConstUtils.MYDOC_BASE_URL));
        restAPIMethods.setApiEndPoint(configvariable.expandValue(MyDocApiConstUtils.MYDOC_PATIENT_ACCESS_TOKEN));
        Map<String, String> formData = new HashMap<>();
        formData.put("grant_type", "password");
        formData.put("client_id", MyDocApiConstUtils.MYDOC_CLIENT_ID);
        formData.put("client_secret", MyDocApiConstUtils.MYDOC_CLIENT_SECRETID);
        formData.put("username", configvariable.expandValue("${PATIENT_EMAIL}"));
        formData.put("password", configvariable.getStringVar("PATIENT_PASSWORD"));

        restAPIMethods.setBodyParam(formData);
        Response response = restAPIMethods.sendRequest("POST");
        logger.info(restAPIMethods.getResponseAsString());
        if (restAPIMethods.getStatusCode() != 200) {
            logger.error("Unable to hit MyDoc endpoint = " + configvariable.expandValue(MyDocApiConstUtils.MYDOC_PATIENT_ACCESS_TOKEN));
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "Unable to create patient using MyDoc API [{}]", configvariable.expandValue(MyDocApiConstUtils.MYDOC_PATIENT_ACCESS_TOKEN));
        }
        String patientAccessToken = response.jsonPath().get("data.authentication.access_token");
        configvariable.setStringVariable(patientAccessToken, "patient_access_token");
        String patientRefreshToken = response.jsonPath().get("data.authentication.refresh_token");
        configvariable.setStringVariable(patientRefreshToken, "patient_refresh_token");
        String patientID = response.jsonPath().get("data.account.id").toString();
        configvariable.setStringVariable(patientID, "mydoc_patient_id");
    }

    public String getAppointmentId() {
        restAPIMethods.setApiBaseUri(Configvariable.envPropertyMap.get(MyDocApiConstUtils.MYDOC_BASE_URL));
        // DoctorId=configvariable.getStringVar("DoctorId");
        //  restAPIMethods.setApiEndPoint("/api/v2/doctors/"+DoctorId+"/appointments");
        restAPIMethods.setApiEndPoint("//api/v2/doctors/42128/appointments");
        Map<String, String> formData = new HashMap<>();
        formData.put("client_id", MyDocApiConstUtils.MYDOC_CLIENT_ID);
        formData.put("client_secret", MyDocApiConstUtils.MYDOC_CLIENT_SECRETID);
        formData.put("Authorization", "Bearer " + configvariable.getStringVar("access_token"));
        System.out.println(configvariable.getStringVar("access_token"));
        restAPIMethods.setBodyParam(formData);
        Response response = restAPIMethods.sendRequest("POST");
        logger.info(restAPIMethods.getResponseAsString());
        if (response.getStatusCode() != 200) {
            logger.error("Unable to hit MyDoc endpoint = " + configvariable.expandValue(MyDocApiConstUtils.MYDOC_LOGIN_ENDPOINT));
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "Unable to login to MyDoc using API [{}]", configvariable.expandValue(MyDocApiConstUtils.MYDOC_LOGIN_ENDPOINT));
        }

        int totalAppointments = response.jsonPath().get("total");
        for (int iCount = 0; iCount < totalAppointments; iCount++) {
            if (response.jsonPath().get("data[" + iCount + "].id")) {
                appointmentId = response.jsonPath().get("data[" + iCount + "].id").toString();
                System.out.println(appointmentId);
            }
        }
        return appointmentId;
    }

    public void acceptDoctor() {
        restAPIMethods.setApiBaseUri(Configvariable.envPropertyMap.get(MyDocApiConstUtils.MYDOC_BASE_URL));
        restAPIMethods.setApiEndPoint("/api/v2/testing/appointments/15424/accept");
        //restAPIMethods.setBasicAuthentication(myDocUsername, myDocPassword);
        Map<String, String> formData = new HashMap<>();
        formData.put("client_id", MyDocApiConstUtils.MYDOC_CLIENT_ID);
        formData.put("client_secret", MyDocApiConstUtils.MYDOC_CLIENT_SECRETID);
        formData.put("Authorization", "Bearer " + configvariable.getStringVar("access_token"));
        restAPIMethods.setBodyParam(formData);
        Response response = restAPIMethods.sendRequest("POST");
        logger.info(restAPIMethods.getResponseAsString());
        if (response.getStatusCode() != 200) {
            logger.error("Unable to hit MyDoc endpoint = " + configvariable.expandValue(MyDocApiConstUtils.MYDOC_LOGIN_ENDPOINT));
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "Unable to login to MyDoc using API [{}]", configvariable.expandValue(MyDocApiConstUtils.MYDOC_LOGIN_ENDPOINT));
        }
    }
}