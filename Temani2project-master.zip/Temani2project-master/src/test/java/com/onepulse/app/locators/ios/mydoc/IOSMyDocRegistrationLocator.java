package com.onepulse.app.locators.ios.mydoc;

import org.openqa.selenium.By;
import org.springframework.stereotype.Component;

@Component
public class IOSMyDocRegistrationLocator {

    //MyDoc Registration
    public static By alertAllowButton = By.xpath("//XCUIElementTypeButton[@name='Allow']");
    public By skipNotification = By.xpath("(//XCUIElementTypeOther[@name='skip'])[2]");
    public By allowNotification = By.xpath("//XCUIElementTypeOther[@name='Allow']");
    public By healthButton = By.xpath("//XCUIElementTypeOther[@name='Home Health Me']/*[@name='Health']");
    // public By healthButton = By.xpath("//XCUIElementTypeButton[@name='Health']");
    public By termsAndCondContinue = By.xpath("//XCUIElementTypeOther[@name='Continue']");
    public By needADoc = By.xpath("//XCUIElementTypeOther[@name=\'Need a doctor? Get a video consultation.\']");
    public By myDocGetStarted = By.xpath("//XCUIElementTypeOther[@name='Get started']");
    public By myDocOnlineConsult = By.xpath("//XCUIElementTypeStaticText[@name='Online Consultation']");
    public By myDocBeforeWeHelpText = By.xpath("//XCUIElementTypeStaticText[@name='Before we can help, we need to know some details about you.']");
    public By myDocThisHelpUsText = By.xpath("//XCUIElementTypeStaticText[@name='This helps us to give the best advice to you.']");
    public By myDocFirstName = By.xpath("//XCUIElementTypeStaticText[@name='First Name / Given Name']//following::XCUIElementTypeOther[1]/XCUIElementTypeOther/XCUIElementTypeTextField");
    public By myDocLastName = By.xpath("//XCUIElementTypeStaticText[@name='Last Name / Family Name']//following::XCUIElementTypeOther[1]/XCUIElementTypeOther/XCUIElementTypeTextField");
    public By myDocGender = By.xpath("//XCUIElementTypeStaticText[@name=\"Last Name / Family Name\"]/following::XCUIElementTypeOther[4]");
    public By myDocEmail = By.xpath("//XCUIElementTypeStaticText[@name='Email']//following::XCUIElementTypeOther[1]/XCUIElementTypeOther/XCUIElementTypeTextField");
    public By myDocCountry = By.xpath("//XCUIElementTypeStaticText[@name='Country of Residence']//following::XCUIElementTypeOther[1]/XCUIElementTypeOther/XCUIElementTypeTextField");
    public By myDocDOB = By.xpath("//XCUIElementTypeStaticText[@name='Country of Residence']/following::XCUIElementTypeOther[4]");
    public By myDocCity = By.xpath("//XCUIElementTypeStaticText[@name='Address (city)']//following::XCUIElementTypeOther[1]/XCUIElementTypeOther/XCUIElementTypeTextField");
    public By myDocAddress = By.xpath("//XCUIElementTypeStaticText[@name='Address (e.g. street, apartment name, etc)']//following::XCUIElementTypeOther[1]/XCUIElementTypeOther/XCUIElementTypeTextField");
    public By myDocZipCode = By.xpath("//XCUIElementTypeStaticText[@name='Address (zipcode)']//following::XCUIElementTypeOther[1]/XCUIElementTypeOther/XCUIElementTypeTextField");
    public By myDocNRIC = By.xpath("//XCUIElementTypeStaticText[@name='NRIC/FIN']//following::XCUIElementTypeOther[1]/XCUIElementTypeOther/XCUIElementTypeTextField");
    public By myDocNricUpload = By.xpath("(//XCUIElementTypeOther[@name='Upload'])[2]");
    public By myDocPhone = By.xpath("//XCUIElementTypeStaticText[@name='Phone']//following::XCUIElementTypeOther[1]/XCUIElementTypeOther/XCUIElementTypeTextField");
    public By myDocVerify = By.xpath("//XCUIElementTypeOther[@name='Verify']");
    public By myDocVerifiedBtn = By.xpath("//XCUIElementTypeOther[@name='Verified']");
    public By myDocTermsAndAggrement = By.xpath("(//XCUIElementTypeOther[@name='By keeping this checkbox clicked, you consent to your consultation data to be shared with the Ministry of Health (Singapore) Health Database. Your privacy is protected as the data will be anonymised and aggregated.'])[2]");
    public By myDocProceed = By.xpath("(//XCUIElementTypeOther[@name='Proceed'])[2]");
    public By myDocOtpResend = By.xpath("//XCUIElementTypeOther[@name='Resend']");
    public By myDocOtpInvalid = By.xpath("//XCUIElementTypeStaticText[@name='Invalid Code']");
    public By myDocOTP = By.xpath("(//XCUIElementTypeOther[contains(@name,'Resend')])[2]/XCUIElementTypeOther[2]/XCUIElementTypeOther[1]/XCUIElementTypeTextField");
    public By editProfile = By.xpath("//XCUIElementTypeOther[@name='Edit Profile']");
    public By saveButton = By.xpath("(//XCUIElementTypeOther[@name=\'Save\'])[4]\n");
    public By address = By.xpath("//XCUIElementTypeStaticText[@name='Address']//following::XCUIElementTypeOther[1]/XCUIElementTypeOther/XCUIElementTypeTextField");
    public By genderDoneBtn = By.xpath("(//XCUIElementTypeOther[@name=\"Done\"])[2]");
    public By consentTxt = By.xpath("(//XCUIElementTypeOther[@name=\"By keeping this checkbox clicked, you consent to your consultation data to be shared with the Ministry of Health (Singapore) Health Database. Your privacy is protected as the data will be anonymised and aggregated.\"])[2]");

    //MyDoc start of journey
    public By myDocSOJBeforeWeConnect = By.xpath("//XCUIElementTypeStaticText[contains(@name,'Before we can connect you to a doctor we need to check if you have any emergency symptoms')]");
    public By myDocSOJBackArrow = By.xpath("(//XCUIElementTypeOther[@name='home'])[1]/XCUIElementTypeOther[1]");

    public By selectText = By.xpath("//XCUIElementTypeStaticText[@name='Gender']/following-sibling::XCUIElementTypeOther[1]");
    public By dOBEditableText = By.xpath("//XCUIElementTypeStaticText[@name='Date of Birth']/following-sibling::XCUIElementTypeOther[1]");
    public By doneBtn = By.xpath("(//XCUIElementTypeOther[@name='Done'])[2]");
    public By doneBtnForGenderInMyDoc = By.xpath("(//XCUIElementTypeOther[@name='Done Male Female Male Female Male'])[3]");

    public static String MYDOC_ERROR_MESSAGE = "//XCUIElementTypeStaticText[@name=\"%s\"]";
    public By myDocGenderErrorMessageLocator = By.xpath("//XCUIElementTypeStaticText[@name=\"Last Name / Family Name\"]/following::XCUIElementTypeOther[contains(@name,'Gender is required')][1]");
    public By myDocDOBErrorMessageLocator = By.xpath("//XCUIElementTypeStaticText[@name=\"Country of Residence\"]/following::XCUIElementTypeOther[contains(@name,'DOB is required')][1]");
    public By backButton = By.xpath("(//XCUIElementTypeOther[@name='home'])[1]/XCUIElementTypeOther[1]");
    public static String MYDOC_FIELD_LABEL = "//XCUIElementTypeStaticText[@name=\"%s\"]";

    public By otpInvalidMsg = By.xpath("//XCUIElementTypeStaticText[@name=\"Invalid Code\"]");
    public By crossBtnOTPAlert = By.xpath("(//XCUIElementTypeOther[@name=\"Enter OTP Invalid Code Resend\"])[2]/XCUIElementTypeOther[1]");
    public By generalTextClass = By.xpath("//XCUIElementTypeStaticText");
}
