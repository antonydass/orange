package com.onepulse.app.stepdefinitions.mobilesteps;

import com.onepulse.app.cucumberhooks.CucumberHook;
import com.onepulse.app.screens.Contactusscreen;
import com.onepulse.app.screens.PulseLoginScreen;
import com.onepulse.app.screens.PulseRegistrationScreen;
import com.onepulse.app.screens.TestBasePage;
//import com.product.genericcomponents.config.Configvariable;

import com.onepulse.app.utils.HRMalinatorUi;
import com.prod.tap.config.Configvariable;
import com.prod.tap.config.TapBeansLoad;
import com.prod.tap.cucumberUtils.SalesFileHelper;
import com.prod.tap.cucumberUtils.ScenarioUtils;
import com.prod.tap.database.DatabaseMethods;
import com.prod.tap.exception.TapException;
import com.prod.tap.exception.TapExceptionType;
import com.prod.tap.filehandling.ExcelUtils;
import com.prod.tap.filehandling.FileReaderUtil;
import cucumber.api.DataTable;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.apache.commons.io.FileUtils;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import java.io.File;
import java.io.IOException;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ContactUs {

    private DatabaseMethods databaseMethods = (DatabaseMethods)TapBeansLoad.getBean(DatabaseMethods.class);

    private Connection connection = null;


    //  private AzureStorageUtils azureStorageUtils = (AzureStorageUtils)TapBeansLoad.getBean(AzureStorageUtils.class);

    private ExcelUtils excelUtils = (ExcelUtils)TapBeansLoad.getBean(ExcelUtils.class);

    private PulseLoginScreen pulseLoginScreen = CucumberHook.context.getBean(PulseLoginScreen.class);

    private PulseRegistrationScreen pulseregistrationscreen = CucumberHook.context.getBean(PulseRegistrationScreen.class);

    private Contactusscreen Contactusscreens = CucumberHook.context.getBean(Contactusscreen.class);

    private SalesFileHelper salesFileHelper = (SalesFileHelper) TapBeansLoad.getBean(SalesFileHelper.class);

    private QuotesPage quotesPage = (QuotesPage)TapBeansLoad.getBean(QuotesPage.class);



    private Configvariable configvariable = CucumberHook.context.getBean(Configvariable.class);

    private TestBasePage testBasePage = CucumberHook.context.getBean(TestBasePage.class);

    private ScenarioUtils scenarioUtils = (ScenarioUtils)TapBeansLoad.getBean(ScenarioUtils.class);

    private HRMalinatorUi hrMalinatorUi = (HRMalinatorUi) TapBeansLoad.getBean(HRMalinatorUi.class);

   // private HRMailsacApi hrMailsacApi = (HRMailsacApi) TapBeansLoad.getBean(HRMailsacApi.class);


    @Given("^I Launch the Application \"([^\"]*)\"$")
    public void i_Launch_the_Application(String url) throws Throwable {

        testBasePage.launchApp();
        testBasePage.waitTime(3);
        Contactusscreens.navigateToUrl(configvariable.expandValue(url));
        testBasePage.waitTime(3);

    }

//    @When("^I write the Data in Excel file \"([^\"]*)\"$")
//    public void i_write_the_Data_in_Excel_file(String arg1) throws Throwable {
//       // Contactusscreens.writeExcelSheel(configvariable.expandValue(arg1));
//    }

    @When("^I write the Data in Excel file \"([^\"]*)\" and sheetName is \"([^\"]*)\"$")
    public void i_write_the_Data_in_Excel_file_and_sheetName_is(String filepath, String sheetName) throws Throwable {
        Contactusscreens.writeExcelSheel(configvariable.expandValue(filepath),configvariable.expandValue(sheetName)) ;
    }

    @When("^I read the data from Excel file \"([^\"]*)\" and sheetName is \"([^\"]*)\"$")
    public void i_read_the_data_from_Excel_file_and_sheetName_is(String filepath, String sheetName) throws Throwable {
        Contactusscreens.ReadExcelSheel(configvariable.expandValue(filepath),configvariable.expandValue(sheetName)) ;
    }

    @Then("^I write to excel file \"([^\"]*)\" into below rows for column \"([^\"]*)\" and search column name \"([^\"]*)\"$")
    public void writeToGivenRowsForGivenColumn(String filePath, String columnName, String columnNameToSearch, DataTable rowData) {
        Map<String, String> rowDataMap = rowData.asMap(String.class, String.class);
        this.excelUtils.writeToRowsForGivenColumn(this.configvariable.expandValue(filePath), 0, this.configvariable.expandValue(columnName), columnNameToSearch, rowDataMap);
    }



    @Then("^I verify downloaded file name is \"([^\"]*)\"$")
    public void verifyDownloadedFileInEmployeePage(String fileName) {
        ScenarioUtils var10000 = this.scenarioUtils;
        String var10001 = this.configvariable.expandValue(fileName);
        var10000.write("Downloaded file name=" + var10001);
        Assert.assertTrue(this.Contactusscreens.isEmployeeFileDownloaded(this.configvariable.expandValue(fileName)), "File downloaded successfully.");
    }

    @When("^I get the reference number for searched quote in variable \"([^\"]*)\"$")
    public void getRefNumberInVariable(String refNumberVar) {
        String refNumber = this.quotesPage.getReferenceNumberForSearchedQuote();
        this.scenarioUtils.write("Reference number is: " + refNumber);
        this.configvariable.setStringVariable(refNumber.trim(), refNumberVar);
    }

    @Then("^I download azure storage file \"([^\"]*)\" from storage folder \"([^\"]*)\" to location \"([^\"]*)\"$")
    public void downloadAzureFile(String fileName, String folderName, String downloadFilePath) {
        String formattedFileName = this.configvariable.expandValue(fileName);
        String formattedFolderName = this.configvariable.expandValue(folderName);
        String formattedFilePath = this.configvariable.expandValue(downloadFilePath);
        this.scenarioUtils.write("Azure storage file name is " + formattedFileName);
        this.scenarioUtils.write("Azure storage folder name is " + formattedFolderName);
        this.scenarioUtils.write("File Download Path is " + formattedFilePath);
        //this.azureStorageUtils.downloadFileFromAzureStorageToLocal(formattedFolderName, formattedFileName, formattedFilePath);
    }

    @When("^I verify \"([^\"]*)\" pdf file is matching with \"([^\"]*)\" pdf file and exceptions are written in folder \"([^\"]*)\"$")
    public void verifyPDFDocuments(String pdfFile1, String pdfFile2, String outfile1Path) {
        boolean match = this.testBasePage.pdfImageCompareAndWriteDifferenceInPDF(this.configvariable.expandValue(pdfFile1), this.configvariable.expandValue(pdfFile2), this.configvariable.expandValue(outfile1Path));
        Assert.assertTrue(match, "PDF files are matched");
    }

    @Then("^I verify searched claim count is (.*)$")
    public void verifyClaimCount(int searchedVal) {
        Assert.assertEquals(Contactusscreens.getSearchedRowCount(), searchedVal, "Searched claim count=" + searchedVal);
    }

    @When("^I verify search count is (.*) search table$")
    public void verifySearchCount(int count) {
        List<String> docNameFromTable = Contactusscreens.getSearchList();

        Assert.assertEquals(docNameFromTable.size(), count, "Search count is as expected");
    }

    @Then("^I wait (.*) sec in the HR portal page$")
    public void waitTime(int time) throws InterruptedException {
        Thread.sleep(time * 1000);
    }

    @Given("^I read hr registration email from \"([^\"]*)\" in Mailinator and get \"([^\"]*)\" link value in global variable$")
    public void readRegistrationLinkFromEmail(String emailAddress, String linkName) {
        testBasePage.launchApp();
     //   WebDriver driver = this.testBasePage.getDriver();
        this.testBasePage.waitTime(10);
        try {
            hrMalinatorUi.navigateToMailinatorUI(configvariable.expandValue(configvariable.expandValue(emailAddress)));
            hrMalinatorUi.clickEmailWithFromAndSubject("${EMAIL_FROM}", "${EMAIL_SUBJECT}");
            hrMalinatorUi.readRegistrationEmailFromMailBody(configvariable.expandValue(linkName));
        } finally {
            testBasePage.closeBrowser();
       //     testBasePage.setDriver(driver);
        }

    }

    @When("^I generate date \"([^\"]*)\" and assign to variable \"([^\"]*)\" in \"([^\"]*)\" format on HR Portal$")
    public void generateDateForCoverageDate(String dateType, String varName, String dateFormat) {
        String date = null;
        LocalDateTime today = LocalDateTime.now();
        if (dateType.equalsIgnoreCase("current date")) {
            date = configvariable.formatDateAndTime(dateFormat, today);
            scenarioUtils.write("current date is "+date);
        } else if (dateType.equalsIgnoreCase("past date")) {
            int minusDays = 1;
            date = configvariable.formatDateAndTime(dateFormat, today.minusDays(minusDays));
            scenarioUtils.write("past date is "+date);
        } else if (dateType.equalsIgnoreCase("future date")) {
            int plusDays = 2;
            date = configvariable.formatDateAndTime(dateFormat, today.plusDays(plusDays));
            scenarioUtils.write("future date is "+date);
            System.out.println("Future Date is  "+date);
        }
        configvariable.setStringVariable(date, varName);
    }

    @Then("^I enter following details on \"([^\"]*)\" screen on HR Portal$")
    public void enterEmployeeDetails(String pageName, DataTable dt) {
        Map<String, String> fieldValueList;
        fieldValueList = dt.asMap(String.class, String.class);
        for (String key : fieldValueList.keySet()) {
            Contactusscreens.enterEmployeeDetails(configvariable.expandValue(key), configvariable.expandValue(fieldValueList.get(key)));
        }
    }

    @Then("^I get the project directory path to variable \"([^\"]*)\"$")
    public void getProjectPath(String variable) {
        String fileAbsPath = System.getProperty("user.dir");
        this.configvariable.setStringVariable(fileAbsPath, variable);
    }


    @Given("^I click button in application")
    public void i_Launch_the_Application() throws Throwable {

        Contactusscreens.GetText(TestBasePage.platform);
    }

    @And("I click the Contact icon in menu")
    public void clickSignInButton() {

        Contactusscreens.clickbutoonsd(TestBasePage.platform);
    }

    @And("Handle the Frame in web application")
    public void Handle_FrameApplication() {

        Contactusscreens.clickSwitchFrame();
    }
    @And("I click the new Tab icon in windows screen")
    public void NewTabIcons() {

        Contactusscreens.NeWtabWindowsIcons();
    }

    @Given("^I connect to \"([^\"]*)\" database$")
    public void connectToDBType(String dbType)  {
     //   logger.info("Setting up connection to DB " + dbType);
    //    this.connection = this.databaseMethods.connectToPostgresQLDB(dbType);

            this.connection=this.Contactusscreens.connectToPostgresQLDB(dbType);
   //     logger.info("DB connection established");
        this.scenarioUtils.write("DB connection established");


//        Connection conn = null;
//        String dbName = "master";
//        String serverip="localhost";
//        String serverport="1433";
//        String url = "jdbc:sqlserver://"+serverip+"\\SQLEXPRESS:"+serverport+";databaseName="+dbName+"";
//        Statement stmt = null;
//        ResultSet result = null;
//        int result1 ;
//        String driver = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
//        String databaseUserName = "sa";
//        String databasePassword = "Manivannan@238";
//        try {
//            Class.forName(driver).newInstance();
//            conn = DriverManager.getConnection(url, databaseUserName, databasePassword);
//            stmt = conn.createStatement();
//            result = null;
//            String pa,us,Address;
//            // result = stmt.executeQuery("select * from Persons ");
//            //result=stmt.executeQuery("INSERT INTO Persons " + "VALUES (12, 'panneer', 'susaritha', 'orathanadu', 'Thanjavur')");
//            //  result1 =stmt.executeUpdate("INSERT INTO Persons " + "VALUES (222, 'panneer', 'susaritha', 'orathanadu', 'Thanjavur')");
//            // result = stmt.executeQuery("INSERT INTO Persons (PersonID, LastName,FirstName,Address,city) VALUES('11','Panneerselvam','susaritha','pinnaiyur','orathanadu' ");
//
//            result = stmt.executeQuery("select * from Persons ");
//            while (result.next()) {
//                us=result.getString("lastName");
//                pa = result.getString("FirstName");
//
//                Address = result.getString("Address");
//
//                if(us.equals("Panneerselvam"))
//                {
//                    System.out.println(us);
//                }
//                else
//                {
//                    System.out.println(pa);
//
//
//                }
//
//                // System.out.println(us+"  "+pa + Address);
//            }
//
//            conn.close();
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
    }


    @Given("^I execute below DB query and get value into the same variables$")
    public void executeDBQuery(String dbQuery) {
        ResultSet resultSet = this.databaseMethods.getResultSet(this.connection, this.configvariable.expandValue(dbQuery));
     //   logger.info(resultSet);

        try {
            ResultSetMetaData columns = resultSet.getMetaData();

            while(resultSet.next()) {
                for(int iCount = 1; iCount <= columns.getColumnCount(); ++iCount) {
                    String columnName = columns.getColumnName(iCount);
                    String value = resultSet.getString(columnName);
                    this.scenarioUtils.write("Value for column " + columnName + " is " + value);
                    this.configvariable.setStringVariable(value, columnName.toUpperCase());
                    System.out.println("the column name is  "+columnName);
                    System.out.println("the value is   "+value);

                }
            }

        } catch (SQLException var7) {
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "Please check your query to execute[{}]", new Object[]{var7.getMessage()});
        }
    }


    @Then("I verify vas \"([^\"]*)\" link is opened in new browser tab")
    public void verifyLinkOpenedInNewTab(String docName) {
        Contactusscreens.verifyLinkOpenedInNewTab(configvariable.expandValue(docName));
    }

    @Then("^I switch to HR Portal parent window$")
    public void switchToParentWindow() {
        this.testBasePage.switchToParentWindow();
    }


    @And("User click the Resource icon")
    public void clickResourceIcon() {

        Contactusscreens.clickResourceIocn(TestBasePage.platform);
    }

    @Then("^I verify \"([^\"]*)\" modal comes up on HR Portal$")
    public void iVerifyAddEmployeeModal(String value) {
        String modalTitle = configvariable.expandValue(value);
        Assert.assertEquals(Contactusscreens.getAddEmployeeModalTitle(modalTitle), modalTitle, configvariable.expandValue(value) + " modal is present");
    }

    @Given("^I Login to Sales Portal with below details$")
    public void iLoginToSalesPortal(DataTable loginDetails) {
        Map<String, String> loginMap = loginDetails.asMap(String.class, String.class);
        this.Contactusscreens.enterUserName(this.configvariable.expandValue((String)loginMap.get("UserName")));
        String decodedPass = this.salesFileHelper.decodePass(this.configvariable.expandValue((String)loginMap.get("Password")));
        this.Contactusscreens.enterPassword(decodedPass);
       // this.Contactusscreens.clickLogIn();
        this.testBasePage.waitTime(2);
        if (this.configvariable.getStringVar("web.browser.type").equalsIgnoreCase("safari")) {
      //      this.testBasePage.sendKeyBoardKeysUsingAction();
        }

    }


    @Given("^I copy the xls template \"([^\"]*)\" and replace following variables in output path \"([^\"]*)\" for column \"([^\"]*)\"$")
    public void replaceParamsInXLSFileAndGenerateOutputFile(String inputPath, String outputPath, String columnName, DataTable variables) {
        Map<String, String> variableMap = variables.asMap(String.class, String.class);
        this.configvariable.assignValueToVarMap(variableMap);
        String var10000 = this.configvariable.getBaseDirectory();
        String inPath = var10000 + this.configvariable.expandValue(inputPath);
        String[] fileParts = inPath.split("/");
        var10000 = this.configvariable.getBaseDirectory();
        String outPath = var10000 + this.configvariable.expandValue(outputPath);
        String outFile = "/" + fileParts[fileParts.length - 1];
        FileReaderUtil.deleteFile(outPath + outFile);

        File srcDir = new File(inPath);
        File desDir = new File(outPath);

        try {
            FileUtils.copyFileToDirectory(srcDir, desDir);
        } catch (IOException var13) {
            throw new TapException(TapExceptionType.IO_ERROR, "Not able to copy file from directory [{}] to directory [{}]", new Object[]{inPath, outPath});
        }

        this.excelUtils.writeToAllRowsForGivenColumn(outPath + outFile, 0, this.configvariable.expandValue(columnName));
    }

    @Then("I upload the employee csv file \"([^\"]*)\"")
    public void uploadEmployeeCSVFile(String filePath) {
        this.Contactusscreens.uploadEmployeeCSVFile(filePath);
    }

    @Then("I upload the Signed Proposal file \"([^\"]*)\"")
    public void uploadSignedProposalFile(String filePath) throws InterruptedException {
        String var10000 = System.getProperty("user.dir");
        String path = var10000 + "/src/test/resources" + this.configvariable.expandValue(filePath);
        Contactusscreens.uploadProposalFormFile(path);

        Thread.sleep(8000);
    }


    @Given("^I verify following text are displayed on \"([^\"]*)\" contact us Screen$")
    public void verifyfollowingtextdisplayedonScreen(String screenName, DataTable texts) throws InterruptedException {
        List<String> textMessages;
        textMessages = texts.asList(String.class);
        SoftAssert softAssert = new SoftAssert();
        for (String key : textMessages) {
            softAssert.assertTrue(Contactusscreens.isStaticTextRCCDisplayed(configvariable.expandValue(key)), configvariable.expandValue(key) + " text is displayed on page " + screenName);
        }
        softAssert.assertAll();
    }

    @Given("^I verify following text are displayed on \"([^\"]*)\" after submit$")
    public void verifySubmitmessage(String screenName, DataTable texts)  {
        List<String> textMessages;
        textMessages = texts.asList(String.class);
        SoftAssert softAssert = new SoftAssert();
        for (String key : textMessages) {
            softAssert.assertTrue(Contactusscreens.verifyText(configvariable.expandValue(key)), configvariable.expandValue(key) + " text is displayed on page " + screenName);
        }
        softAssert.assertAll();
    }


    @Given("^I verify following text are displayed on \"([^\"]*)\" Alert meessage in contactscreen$")
    public void VerifylastName_AlertMessage(String screenName, DataTable texts)  {
        List<String> textMessages;
        textMessages = texts.asList(String.class);
        SoftAssert softAssert = new SoftAssert();
        for (String key : textMessages) {
            softAssert.assertTrue(Contactusscreens.VerifyLastNameText(configvariable.expandValue(key)), configvariable.expandValue(key) + " text is displayed on page " + screenName);
        }
        softAssert.assertAll();
    }

    @Given("^I verify following text are displayed on \"([^\"]*)\" Alert meessage should be displayed$")
    public void VerifyValidAlertmessage(String screenName, DataTable texts)  {
        List<String> textMessages;
        textMessages = texts.asList(String.class);
        SoftAssert softAssert = new SoftAssert();
        for (String key : textMessages) {
            softAssert.assertTrue(Contactusscreens.validDuplicateAlertmessage(configvariable.expandValue(key)), configvariable.expandValue(key) + " text is displayed on page " + screenName);
        }
        softAssert.assertAll();
    }


//
//    @When("user enters credentials")
//    public void userEntersCredentials(DataTable userDetails) throws InterruptedException {
//        Map<String, String> registrationDetails;
//        registrationDetails = userDetails.asMap(String.class, String.class);
//        Contactusscreens.enterLoginCredentials(testBasePage.platform, configvariable.expandValue(registrationDetails.get("UserName")), configvariable.expandValue(registrationDetails.get("Password")));
//
//    }

    @And("user enters contact us details in healthaccess screen")
    public void enterRegistrationDetails(DataTable userDetails) {
        testBasePage.waitTime(4);
        Map<String, String> registrationDetails;
        registrationDetails = userDetails.asMap(String.class, String.class);
        Contactusscreens.enterRegistrationDetails(registrationDetails);
    }

    @And("I click the submit button in contact us screen")
    public void clickSubmitbutton() {
        Contactusscreens.click_SubmitButton(TestBasePage.platform);


//        ArrayList list = new ArrayList();
//        list.add(10);
//        list.add(20);
//        list.add(70);
//
//        System.out.println("-------->  "+list);
      
    }

    @When("verify the response in get method")
    public void verifyGetMethod() throws IOException, ParseException {
        //  myDocApi.loginToPulseTES();
        Contactusscreens.getApppointmentIdForPatient();
        Contactusscreens.doctorAcceptAppointment();
        Contactusscreens.Arrvaluejsonvalue();

      //  Contactusscreens.myComments();
        // acceptAppointmentDetails = myDocApi.doctorAcceptAppointment();
    }

    @When("Verify the github login username")
    public void verifyGetMethod_GITHUB() throws IOException, ParseException {
        //  myDocApi.loginToPulseTES();
        Contactusscreens.getApppointmentIdForGithub();

    }

    @When("Verify the githubs login usernames")
    public void verifyGet_GITHUB() throws IOException, ParseException {
        //  myDocApi.loginToPulseTES();
        Contactusscreens.getAppId();

    }

    @When("i Select the language ane verify the language")
    public void VerifyWikipidia() throws IOException, ParseException {
        //  myDocApi.loginToPulseTES();
        Contactusscreens.wikipedia();

    }

//    @Given("^user click on \"([^\"]*)\" with Email button$")
//    public void clickRegisterWithEmail(String buttonText) throws Throwable {
//        Contactusscreens.clickRegisterButton(configvariable.expandValue(buttonText));
//    }



    @Given("^I click the \"([^\"]*)\" in wikipedia screen$")
    public void i_click_the_in_wikipedia_screen(String arg1) throws Throwable {
        Contactusscreens.clickRegisterButton(configvariable.expandValue(arg1));
    }

    @Given("^Verify the \"([^\"]*)\" in wikipedia screen$")
    public void verify_the_in_wikipedia_screen(String language_name) throws Throwable {
        String welcomePage = Contactusscreens.getWelcomePageTextsss(TestBasePage.platform);
        System.out.println(welcomePage);
       // softAssert.assertTrue(welcomePage.contains(screenVar));
       Assert.assertEquals(welcomePage,language_name);

       TestBasePage.driver.navigate().back();
    }

    @Given("^I Enter the Name \"([^\"]*)\" in wikipedia screen$")
    public void i_Enter_the_Name_in_wikipedia_screen(String arg1) throws Throwable {

        Contactusscreens.EnterNames(configvariable.expandValue(arg1));
    }

    @Given("^Verify the Name \"([^\"]*)\" in wikipedia screen$")
    public void verify_the_Name_in_wikipedia_screen(String hoolywoordNames) throws Throwable {

        String welcomePages = Contactusscreens.getHollyWoodNames(TestBasePage.platform);
        System.out.println(welcomePages);
        Assert.assertEquals(welcomePages,hoolywoordNames);


    }

    @Given("^Verify the Date of Birth \"([^\"]*)\" in wikipedia screen$")
    public void verify_the_Date_of_Birth_in_wikipedia_screen(String ExpectedDate) throws Throwable {

    //    Contactusscreens.getHollywooddisplayed(TestBasePage.platform);
        String Dates = Contactusscreens.getHollywooddisplayed(TestBasePage.platform);
      //  System.out.println("DATES ---- "+Dates.substring(0,12).trim());

        String[] terms = Dates.split("[(@&.?$+]+");
        System.out.println(terms.length);

        for(int i=0;i<terms.length;i++)
        {
            if(i==0) {
                System.out.println(i   +terms[i]);
                Assert.assertEquals(ExpectedDate,terms[i].trim());
            }
        }
    }


    @Given("^Verify the spouse name \"([^\"]*)\" in wikipedia screen$")
    public void verify_the_spouse_name_in_wikipedia_screen(String arg1) throws Throwable {
        String welcomePages = Contactusscreens.GetspouseDetails(TestBasePage.platform);
        System.out.println(welcomePages);

    }

    @Given("^Verify the \"([^\"]*)\" repository name in Github screen$")
    public void verify_the_repository_name_in_Github_screen(String ActualRepoName) throws Throwable {
        String ExpectedRepoName= Contactusscreens.GetRepositoryName();
        System.out.println("Repository Name is   "+ ExpectedRepoName);

        Assert.assertEquals(ExpectedRepoName,ActualRepoName);

    }
    @Given("^Verify the \"([^\"]*)\" Numberofstars in Github screen$")
    public void verify_the_Numberofstars_in_Github_screen(String ActualRepoName) throws Throwable {
        String ExpectedRepoNameS= Contactusscreens.GetStarValuesName();
        System.out.println("STAR Name is   "+ ExpectedRepoNameS);

        Assert.assertEquals(ExpectedRepoNameS,ActualRepoName);
    }


    @Given("^Verify Number of Branch in one Repository$")
    public void verify_Number_of_Branch_in_one_Repository() throws Throwable {
        Contactusscreens.BranchNames();

    }

    @When("^Verify Release coount in one Repository$")
    public void verify_Release_coount_in_one_Repository() throws Throwable {
        Contactusscreens.ReleaseCount();
    }

    @When("^Verify the githubs second repository in github screen$")
    public void verify_the_githubs_second_repository_in_github_screen() throws Throwable {
        Contactusscreens.GetSecondRepoEndPoint();
    }

    @Given("^I click the language in wikipedia screen$")
    public void i_click_the_language_in_wikipedia_screen() throws Throwable {

    }


}
