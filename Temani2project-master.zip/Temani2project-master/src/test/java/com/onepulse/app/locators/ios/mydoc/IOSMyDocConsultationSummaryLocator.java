package com.onepulse.app.locators.ios.mydoc;

import org.openqa.selenium.By;
import org.springframework.stereotype.Component;

@Component
public class IOSMyDocConsultationSummaryLocator {
    public By consultationSummary = By.xpath("//XCUIElementTypeOther[@name='Consultation Summary']");
    public By consultationHistory = By.xpath("//XCUIElementTypeOther[@name='Consultation History']/XCUIElementTypeOther");
    public By consultationAllMyFiles = By.xpath("(//XCUIElementTypeOther[@name='All my files'])[2]");
    public By completeMedicalProfile = By.xpath("//XCUIElementTypeOther[@name='Complete your Medical Profile Such as your allergies and Medical conditions and your emergency contacts']");
    public By doctorsName = By.xpath("//XCUIElementTypeScrollView/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther");
    public By doctorChat = By.xpath("(//XCUIElementTypeOther[@name='Doctor's Chat'])[4]");
    //    public By backToHome = By.xpath("(//XCUIElementTypeOther[@name='home'])[1]/XCUIElementTypeOther[1]");
    public By backToHome = By.xpath("(//XCUIElementTypeOther[@name='home'])/preceding-sibling::XCUIElementTypeOther[1]");
    //    public By backToHome = By.xpath("(//XCUIElementTypeOther[@name='home'])[2]/XCUIElementTypeOther[1]");
    public By appointmentConfirmation = By.xpath("//XCUIElementTypeScrollView/XCUIElementTypeOther[contains(@name,'Your appointment request has been confirmed.')]");
    public By joinCall = By.xpath("//XCUIElementTypeScrollView/XCUIElementTypeOther[contains(@name,'Join call')]");
    public By doctorAppointmentText = By.xpath("//XCUIElementTypeStaticText[@name='Doctor Appointment']");
    public By alertOK = By.xpath("//XCUIElementTypeButton[@name='OK']");
    public By outOfAppNotification = By.xpath("(//XCUIElementTypeCell[@name=\"NotificationCell\"])[1]//XCUIElementTypeButton[@name=\"notification-action-button\"][1]");
    public By notificationOpen = By.xpath("(//XCUIElementTypeButton[@name=\"notification-action-button\"])[1]");
    public By nricTextField = By.xpath("(//XCUIElementTypeOther[@name='NRIC / FIN'])[2]/XCUIElementTypeTextField");
    public By uploadNRIC = By.xpath("(//XCUIElementTypeOther[@name='Upload'])[4]");
    public By cameraRoll = By.xpath("//XCUIElementTypeStaticText[@name='Camera Roll']");
    public By photosList = By.xpath("//XCUIElementTypeImage");
    public By changeButton = By.xpath("(//XCUIElementTypeOther[@name='Change'])[4]");
    public By nextButton = By.xpath("(//XCUIElementTypeOther[@name='Next'])[2]");
    public By allergies = By.xpath("//XCUIElementTypeStaticText[@name='Allergies']//following::XCUIElementTypeOther[3]/XCUIElementTypeTextField");
    public By medicalCondition = By.xpath("//XCUIElementTypeStaticText[@name='Medical Condition']//following::XCUIElementTypeOther[3]/XCUIElementTypeTextField");
    public By medication = By.xpath("//XCUIElementTypeStaticText[@name='Active Medications']//following::XCUIElementTypeOther[3]/XCUIElementTypeTextField");
    public By emergencyContactName = By.xpath("//XCUIElementTypeStaticText[@name='Emergency Contact']//following::XCUIElementTypeOther[3]/XCUIElementTypeTextField");
    public By doneButton = By.xpath("(//XCUIElementTypeOther[@name='Done'])[2]");
    public static String CONSULTATION_OPTION = "//XCUIElementTypeOther[contains(@name,\"%s\")]";
    public static String CONSULTATION_SCREEN = "//XCUIElementTypeStaticText[@name=\"%s\"]";
    public By seeButtonAlert = By.xpath("//XCUIElementTypeButton[@name=\"See\"]");
    public By ignoreButtonAlert = By.xpath("//XCUIElementTypeButton[@name=\"Ignore\"]");
    public By conciergeAlertMessage = By.xpath("//XCUIElementTypeStaticText[@name=\"Your concierge has a message for you!!\"]");
    public static String CONCIERGE_MESSAGE = "//XCUIElementTypeStaticText[contains(@name,\"%s\")]";
    public By doctorAttachment = By.xpath("//XCUIElementTypeStaticText[@name=\"Attachments\"]");
    public By medicationCertificate = By.xpath("(//XCUIElementTypeOther[@name=\"Medication Certificate\"])[3]");
    public By allAttachments = By.xpath("//XCUIElementTypeScrollView/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther");
    public By okButtonAlert = By.xpath("//XCUIElementTypeButton[@name=\"OK\"]");
    public By caseNotes = By.xpath("(//XCUIElementTypeOther[@name=\"Case Notes\"])[2]");
    public By closeCaseNote = By.xpath("//XCUIElementTypeScrollView");
    public By prescription = By.xpath("(//XCUIElementTypeOther[@name=\"Prescription\"])[1]");
    public By consultationHistoryScreen = By.xpath("//XCUIElementTypeStaticText[@name='Consultation History']");
    public By doctorChatLink = By.xpath("(//XCUIElementTypeOther[@name=\"Doctor's Chat\"])[3]");
    public By referral = By.xpath("(//XCUIElementTypeOther[@name=\"Referral Letter\"])[1]");
    public By sentToMyDocTeamMsg = By.xpath("(//XCUIElementTypeOther[@name=\" We've sent your request to the MyDoc team. We will notify you as soon as your doctor confirms the request. \"])[4]");
    public static String MYDOC_ATTACHMENTS = "//XCUIElementTypeOther[@name=\"%s\"]";
    public By fileDownloadButtonLocator = By.xpath("(//XCUIElementTypeOther[@name=\"home\"])[1]/following-sibling:: XCUIElementTypeOther/XCUIElementTypeOther[2]");
    public By clickCancelButton = By.xpath("//XCUIElementTypeButton[@name=\"Cancel\"]");
    public By appointmentDetailsOnJoinCallTile = By.xpath("//XCUIElementTypeStaticText[@label='Join call']/preceding::XCUIElementTypeOther[1]");
    public By mcrLocatorDoctorProfilePage = By.xpath("//XCUIElementTypeStaticText[contains(@name,'MCR:')]");
    public By docNameDoctorProfilePage = By.xpath("//XCUIElementTypeStaticText[contains(@name,'Name:')]");
    public By docProfilePageLocator = By.xpath("//XCUIElementTypeStaticText[@name='Doctor']");
}
