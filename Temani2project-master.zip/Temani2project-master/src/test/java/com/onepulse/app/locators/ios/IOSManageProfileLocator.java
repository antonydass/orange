package com.onepulse.app.locators.ios;


import org.openqa.selenium.By;
import org.springframework.stereotype.Component;

@Component
public class IOSManageProfileLocator {
    // Locators on the registration screen
    public By changePhoto = By.xpath("(//XCUIElementTypeOther[@name='Save'])[2]/XCUIElementTypeOther[2]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeImage");
    public By editProfileLink = By.xpath("//XCUIElementTypeStaticText/following::XCUIElementTypeOther[@name='Edit Profile']");
    public By firstName = By.xpath("//XCUIElementTypeStaticText[@name='First Name / Given Name']//following::XCUIElementTypeOther[1]/XCUIElementTypeOther/XCUIElementTypeTextField");
    public By lastName = By.xpath("//XCUIElementTypeStaticText[@name='Last Name / Family Name']//following::XCUIElementTypeOther[1]/XCUIElementTypeOther/XCUIElementTypeTextField");
    public By genderDropdown = By.xpath("//XCUIElementTypeStaticText[@name='Gender']//following::XCUIElementTypeOther[1]");
    public By DOB = By.xpath("//XCUIElementTypeStaticText[@name='Date of Birth']//following::XCUIElementTypeOther[1]");
    public By phoneNumber = By.xpath("//XCUIElementTypeStaticText[@name='Phone Number']//following::XCUIElementTypeOther[1]/XCUIElementTypeOther/XCUIElementTypeTextField");
    public By email = By.xpath("//XCUIElementTypeStaticText[@name='Email']//following::XCUIElementTypeOther[1]/XCUIElementTypeOther/XCUIElementTypeTextField");
    public By countryOfResidence = By.xpath("//XCUIElementTypeStaticText[@name='Country of Residence']/following-sibling::XCUIElementTypeOther[1]");
    //By.xpath("(//XCUIElementTypeStaticText[@name='Singapore'])[1]");
    // public By countryOfResidence = By.xpath("/XCUIElementTypeStaticText[@name='Country of Residence']//following::XCUIElementTypeOther[1]//XCUIElementTypeOther");
    public By address = By.xpath("//XCUIElementTypeStaticText[@name='Address']//following::XCUIElementTypeOther[1]/XCUIElementTypeOther/XCUIElementTypeTextField");
    public By city = By.xpath("//XCUIElementTypeStaticText[@name=\"City\"]/following-sibling:: XCUIElementTypeOther[1]");
    //(//XCUIElementTypeStaticText[@name='Singapore'])[2]
    //public By city = By.xpath("//XCUIElementTypeStaticText[@name='City']//following::XCUIElementTypeOther[1]//XCUIElementTypeOther");
    public By postalCode = By.xpath("//XCUIElementTypeStaticText[@name='Postal code']//following::XCUIElementTypeOther[1]/XCUIElementTypeOther/XCUIElementTypeTextField");
    public By saveButton = By.xpath("(//XCUIElementTypeOther[@name='Save'])[4]");
    public By closeButton = By.xpath("(//XCUIElementTypeOther[@name='Save'])[3]/XCUIElementTypeOther[1]");

    //security Page
    public By security = By.xpath("(//XCUIElementTypeOther[@name='Security'])[2]");
    public By changePassword = By.xpath("(//XCUIElementTypeOther[@name='Change Password'])[1]");

    //provideFeedback
    public By provideFeedbackLink = By.xpath("(//XCUIElementTypeOther[@name='Provide Feedback'])[2]");

    //Legal & Privacy

    public By legalAndPrivacyLink = By.xpath("(//XCUIElementTypeOther[@name='Legal & Privacy'])[2]");
    public By tncLink = By.xpath("(//XCUIElementTypeOther[@name='Terms & Conditions'])[2]");
    public By pulseTnCLink = By.xpath("(//XCUIElementTypeOther[@name='Pulse by Prudential'])[2]");
    public By tncCloseBtn = By.xpath("//XCUIElementTypeApplication[@name=\"Pulse\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther[2]/XCUIElementTypeOther[1]/XCUIElementTypeOther[1]/XCUIElementTypeOther/XCUIElementTypeOther[2]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther[1]/XCUIElementTypeOther");
    public By tncBackBtn = By.xpath("//XCUIElementTypeStaticText[@name='Terms & Conditions']/preceding::XCUIElementTypeOther[1]");
    public By privacyNoticeLink = By.xpath("(//XCUIElementTypeOther[@name='Privacy Notice'])[2]");
    public By pulsePrivacyNoticeLink = By.xpath("(//XCUIElementTypeOther[@name='Pulse by Prudential'])[2]");
    public By privacyNoticeCloseBtn = By.xpath("//XCUIElementTypeApplication[@name='Pulse']/XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther[2]/XCUIElementTypeOther[1]/XCUIElementTypeOther[1]/XCUIElementTypeOther/XCUIElementTypeOther[2]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther[1]/XCUIElementTypeOther");
    public By privacyNoticeBackBtn = By.xpath("//XCUIElementTypeStaticText[@name='Privacy Notice']/preceding::XCUIElementTypeOther[1]");
    public By legalAndPrivacyBackBtn = By.xpath("(//XCUIElementTypeOther[@name='Terms & Conditions'])[1]/preceding::XCUIElementTypeOther[1]");
    public By pulseByPrudentialTnCText = By.xpath("//XCUIElementTypeOther[@name='Pulse by Prudential Terms & Conditions']");
    public By privacyNoticeTnCText = By.xpath("//XCUIElementTypeOther[@name='Pulse by Prudential Privacy Notice']");
    public By changePasswordCloseBtn = By.xpath("//XCUIElementTypeStaticText[@name='Security']/preceding::XCUIElementTypeOther[1]");
    //SignOut
    public By signOutBtn = By.xpath("(//XCUIElementTypeOther[@name='Sign out'])[2]");

    //EditProfile verifyExisting User
    public By existCustomerVerify = By.xpath("//XCUIElementTypeOther[@name='Verify']");
    public By existCustomerField = By.xpath("(//XCUIElementTypeOther[@name='Exist Customer?'])[2]/XCUIElementTypeTextField");
    public By existCustomerConfirmIdentityText = By.xpath("//XCUIElementTypeStaticText[@name='Confirm your identity']");
    public By nricNumbertext = By.xpath("//XCUIElementTypeStaticText[@name='NRIC Number.']");
    public By existCustomerNRICNumber = By.xpath("//XCUIElementTypeStaticText[@name='NRIC Number']/following::XCUIElementTypeTextField");
    public By alertMeg = By.xpath("//XCUIElementTypeStaticText[@name='No unique customer found for this NRIC and date of birth']");
    public By existCustomerContinueButton = By.xpath("//XCUIElementTypeOther[@name='home']");
    public By alertBox = By.xpath("//XCUIElementTypeAlert[@name='Message']");
    public By newsAndUpdate = By.xpath("//XCUIElementTypeStaticText[@name='News & Updates']");
    public By completeYourProfileOption = By.xpath("//XCUIElementTypeOther[@name='Prudential Customer?']");
    public By messageAlertOK = By.xpath("//XCUIElementTypeButton[@name='ok']");
    public By crossButton = By.xpath("//XCUIElementTypeScrollView[1]/preceding:: XCUIElementTypeOther[2]/XCUIElementTypeOther");
    public String screenText = "//XCUIElementTypeStaticText[@name=\"%s\"]";


    public By agentReferralCodeFieldLabel = By.xpath("//XCUIElementTypeStaticText[@name='Agent Referral Code']");
    public By agentReferralCodeFieldTextField = By.xpath("//XCUIElementTypeStaticText[@name='Agent Referral Code']/following::XCUIElementTypeTextField");
    public By submitBtnForAgentReferralCode = By.xpath("//XCUIElementTypeStaticText[@name='Agent Referral Code']/following::XCUIElementTypeOther[@name='Verify']");
    public By referralCodeScreen = By.xpath("//XCUIElementTypeStaticText[@name='Have a referral code?']");
    public By submitBtnOnAgentReferralCodeScreen = By.xpath("//XCUIElementTypeOther[@name='home']");
    public By errorMessageLocatorOnReferralCodeScreen = By.xpath("//XCUIElementTypeStaticText[@name='Referral code required']");
    public By willDoButtonReferralCodeScreen = By.xpath("//XCUIElementTypeOther[@name='home']");
    public By closeBtnReferralCodeScreen = By.xpath("//XCUIElementTypeStaticText[@name='Have a referral code?']/preceding::XCUIElementTypeOther[2]");
    public By verifyBtnAfterSuccessfulReferralCodeAddition = By.xpath("//XCUIElementTypeOther[@name='Verified']");

    public static String EDIT_PROFILE_ERROR_MESSAGE = "//XCUIElementTypeStaticText[@name=\"%s\"]";

    public By consentManagementLink = By.xpath("(//XCUIElementTypeOther[@name='Consent Management'])[2]");
    public By marketingCheckbox = By.xpath("//XCUIElementTypeOther[@name=\"Marketing\"]");
    public By closeConsentManagementButton = By.xpath("//XCUIElementTypeStaticText[@name='Consent Management']/preceding::XCUIElementTypeOther[1]");
    public By saveConsentManageButton = By.xpath("(//XCUIElementTypeOther[@name=\"Save\"])[2]");
    public By nonPrudentialCustomerLink = By.xpath("//XCUIElementTypeOther[@name=\"I'm not a Prudential customer\"]");

    public By newsAndUpdateCarouselLink = By.xpath("//XCUIElementTypeStaticText[@name=\"News & Updates\"]/following::XCUIElementTypeOther[1]");
    public By phoneNumberLabelLocator = By.xpath("//XCUIElementTypeStaticText[@name=\"Phone Number\"]");

}

