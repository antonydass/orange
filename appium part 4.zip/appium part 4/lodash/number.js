module.exports = {
  'clamp': require('./clamp'),
  'inRange': require('./inRange'),
  'random': require('./random')
};
