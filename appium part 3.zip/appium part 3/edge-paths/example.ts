// Replace following line "." with "edge-paths" if you are using it as package
import { getEdgeBetaPath, getEdgeCanaryPath, getEdgeDevPath, getEdgePath, getAnyEdgeStable, getAnyEdgeLatest } from "."

console.log(getEdgeBetaPath())
console.log(getEdgeCanaryPath())
console.log(getEdgeDevPath())
console.log(getEdgePath())
console.log(getAnyEdgeLatest())
console.log(getAnyEdgeLatest())
