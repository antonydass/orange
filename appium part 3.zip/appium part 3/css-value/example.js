
var parse = require('./');
var str = "14px 1.5 'proxima-nova', 'Helvetica Neue', Arial, Helvetica, sans-serif";

console.log(parse(str));

