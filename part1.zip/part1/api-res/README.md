# API Res
## Node.js HTTP(S) Request Library intended for Nodal API Services

Simple HTTP Request library to query Nodal API services in Node.js.

Plays well with [CMND](http://github.com/keithwhor/cmnd)

## About

Follow me on Twitter, [@keithwhor](http://twitter.com/keithwhor).

Feel free to check out more of [my GitHub projects](http://github.com/keithwhor).
