const Base64Encode = require('./lib/encode');
const Base64Decode = require('./lib/decode');

module.exports = {
    Base64Encode,
    Base64Decode
};
