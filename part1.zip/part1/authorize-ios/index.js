#!/usr/bin/env node
// transpile:main

import authorize from './lib/authorize';

export default authorize;

