#!/usr/bin/env node
'use strict';

const authorize = require('./build/index.js');

authorize();
