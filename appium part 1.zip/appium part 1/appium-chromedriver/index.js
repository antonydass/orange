import { default as chromedriver } from './lib/chromedriver';
import ChromedriverStorageClient from './lib/storage-client';

export { ChromedriverStorageClient };
export default chromedriver;
