/**
 * @module 101/noop
 */

/**
 * Does nothing - no operation
 */
module.exports = function () {};