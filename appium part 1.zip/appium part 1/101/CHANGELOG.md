# Change Log
All notable changes to this project will be documented in this file.
This project adheres to [Semantic Versioning](http://semver.org/).

## [0.18.0] - 2015-05-09
### Added
- [`indexBy`](https://github.com/tjmehta/101#indexBy) module

## [0.17.0] - 2015-05-07
### Added
- [`bindAll`](https://github.com/tjmehta/101#bindAll) module
- [`keysIn`](https://github.com/tjmehta/101#keysIn) module
- This CHANGELOG file

[0.17.0]: https://github.com/tjmehta/101/compare/v0.16.1...v0.17.0
