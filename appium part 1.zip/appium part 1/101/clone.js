/**
 * @module 101/clone
 */

/** Just exporting https://www.npmjs.org/package/clone */
// Only bc 101 uses it internally and it is a nice util
module.exports = require('clone');
