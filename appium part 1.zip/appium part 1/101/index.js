throw new Error('you should require a method of 101, just like require("101/<util>")');
exports = module.exports = function(){};
