/** 
 * @module 101/is-integer
 */ 

/**
 * Returns true if n is an integer.
 * @function module:101/is-integer
 * @param {*} val - value checked to be a string
 * @return {boolean} Whether the value is an integer or not
 */

module.exports = isInteger;

function isInteger (val) {
  return typeof val === 'number' && isFinite(val) && Math.floor(val) === val;
}
