appium-fake-driver
===================

[![Greenkeeper badge](https://badges.greenkeeper.io/appium/appium-fake-driver.svg)](https://greenkeeper.io/)

Issues for this repo are disabled. Log any issues at the [main Appium repo's issue tracker](https://github.com/appium/appium/issues).

Work in progress, stay tuned!

## Watch

```
npm run watch
```

## Test

```
npm test
```
