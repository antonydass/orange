# @babel/runtime

> babel's modular runtime helpers

See our website [@babel/runtime](https://babeljs.io/docs/en/babel-runtime) for more information.

## Install

Using npm:

```sh
npm install --save @babel/runtime
```

or using yarn:

```sh
yarn add @babel/runtime 
```
