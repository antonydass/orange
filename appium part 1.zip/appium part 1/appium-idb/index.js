// transpile:main

import * as idb from './lib/idb';


const { IDB } = idb;

export default IDB;
export { IDB };
