// Type definitions for puppeteer-core 5.4
// Project: https://github.com/GoogleChrome/puppeteer#readme
// Definitions by: Fumiaki Matsushima <https://github.com/mtsmfm>
//                 Tymur Kubai <https://github.com/sirdir>
// Definitions: https://github.com/DefinitelyTyped/DefinitelyTyped
// TypeScript Version: 3.0

export * from 'puppeteer';
