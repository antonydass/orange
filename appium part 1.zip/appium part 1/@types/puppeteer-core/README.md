# Installation
> `npm install --save @types/puppeteer-core`

# Summary
This package contains type definitions for puppeteer-core (https://github.com/GoogleChrome/puppeteer#readme).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/puppeteer-core.

### Additional Details
 * Last updated: Wed, 23 Dec 2020 21:10:00 GMT
 * Dependencies: [@types/puppeteer](https://npmjs.com/package/@types/puppeteer)
 * Global values: none

# Credits
These definitions were written by [Fumiaki Matsushima](https://github.com/mtsmfm), and [Tymur Kubai](https://github.com/sirdir).
