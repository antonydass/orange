# Installation
> `npm install --save @types/tough-cookie`

# Summary
This package contains type definitions for tough-cookie (https://github.com/salesforce/tough-cookie).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/tough-cookie.

### Additional Details
 * Last updated: Fri, 02 Jul 2021 19:37:15 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by [Leonard Thieu](https://github.com/leonard-thieu), [LiJinyao](https://github.com/LiJinyao), and [Michael Wei](https://github.com/no2chem).
