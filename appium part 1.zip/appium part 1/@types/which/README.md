# Installation
> `npm install --save @types/which`

# Summary
This package contains type definitions for which (https://github.com/isaacs/node-which).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/which

Additional Details
 * Last updated: Wed, 09 Oct 2019 23:22:48 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by vvakame <https://github.com/vvakame>, and cspotcode <https://github.com/cspotcode>.
