module.exports = require('./lib/apkreader')
