WDIO Configurations Utility
===========================

> A helper utility to parse and validate WebdriverIO options
