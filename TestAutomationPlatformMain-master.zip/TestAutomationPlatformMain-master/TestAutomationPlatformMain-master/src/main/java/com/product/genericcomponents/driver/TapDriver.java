package com.product.genericcomponents.driver;

import com.product.genericcomponents.config.Configvariable;
import com.product.genericcomponents.exception.TapException;
import com.product.genericcomponents.exception.TapExceptionType;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.remote.MobileCapabilityType;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.apache.commons.exec.CommandLine;
import org.apache.commons.exec.DefaultExecuteResultHandler;
import org.apache.commons.exec.DefaultExecutor;
import org.apache.commons.exec.ExecuteException;
import org.apache.log4j.Logger;
import org.openqa.selenium.PageLoadStrategy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.phantomjs.PhantomJSDriver;
import org.openqa.selenium.phantomjs.PhantomJSDriverService;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.safari.SafariDriver;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.FileInputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.TimeUnit;


/**
 * contains all the methods to create a new session and destroy the
 * session after the test(s) execution is over. Each test extends
 * this class.
 */
@Component
public class TapDriver {
    private static final Logger LOGGER = Logger.getLogger(TapDriver.class);
    @Autowired
    Configvariable configvariable;
    public WebDriver driver = null;
    protected static Properties lobConfigProp = new Properties();
    public static Properties localeConfigProp = new Properties();
    protected FileInputStream configFis;
    protected FileInputStream lobConfigFis;
    protected FileInputStream localeConfigFis;
    private Properties configProp = new Properties();
    private String OS;
    public DesiredCapabilities capabilities = new DesiredCapabilities();
    private static String APPIUM_SERVER_URL = "http://127.0.0.1:4723/wd/hub";
    private static int DEFAULT_IMPLICIT_WAIT = 2;
    public static boolean NO_RESET = false;
    private static String APP_LANGUAGE = System.getProperty("pulse.language");
    private static String APP_COUNTRY = System.getProperty("pulse.country");
    private static String PROXY_USER = System.getProperty("proxy.user");
    private static String PROXY_PASS = System.getProperty("proxy.pass");
    private static String PROXY_URL = "http://10.163.39.77:8080";

    public TapDriver() {
    }

    public void invokeAppium() throws Exception {
        String OS = System.getProperty("os.name").toLowerCase();

        try {
            this.startAppiumServer(OS);
            LOGGER.info("Appium server started successfully");
        } catch (Exception var3) {
            LOGGER.warn("Unable to start appium server");
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "Unable to start appium server", new Object[0]);
        }
    }

    public void stopAppium() throws Exception {
        String OS = System.getProperty("os.name").toLowerCase();

        try {
            this.stopAppiumServer(OS);
            LOGGER.info("Appium server stopped successfully");
        } catch (Exception var3) {
            LOGGER.warn("Unable to stop appium server");
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "Unable to stop appium server", new Object[0]);
        }
    }

    public void teardown() {
        LOGGER.info("Shutting down driver");
        this.driver.quit();
    }

    public void androidDriver(String buildPath, String appPkg, String appAct) throws MalformedURLException {
        this.capabilities.setCapability("deviceName", "Android-Test");
        this.capabilities.setCapability("platformName", "Android");
        this.capabilities.setCapability("appPackage", appPkg);
        this.capabilities.setCapability("appActivity", appAct);
        this.capabilities.setCapability("newCommandTimeout", 10000);
        this.capabilities.setCapability("noReset", NO_RESET);
        this.capabilities.setCapability("automationName", "UiAutomator2");
        this.capabilities.setCapability("language", APP_LANGUAGE);
        this.capabilities.setCapability("locale", APP_COUNTRY);
        if (System.getProperty("device.udid") != null) {
            this.capabilities.setCapability("udid", System.getProperty("device.udid"));
        }

        this.driver = new AndroidDriver(new URL(APPIUM_SERVER_URL), this.capabilities);
        ((AndroidDriver)this.driver).resetApp();
        this.driver.manage().timeouts().implicitlyWait((long)DEFAULT_IMPLICIT_WAIT, TimeUnit.SECONDS);
    }

    public void iOSDriver(String buildPath, String iosBundleId, String iosUDID, String iosPlatform) throws MalformedURLException {
        this.capabilities.setCapability("deviceName", "iOS-Test");
        this.capabilities.setCapability("platformName", "iOS");
        this.capabilities.setCapability("bundleId", iosBundleId);
        this.capabilities.setCapability("automationName", "XCUITest");
        this.capabilities.setCapability("noReset", false);
        this.capabilities.setCapability("language", APP_LANGUAGE);
        this.capabilities.setCapability("locale", APP_COUNTRY);
        if (System.getenv("DEVICEFARM_LOG_DIR") == null && System.getProperty("device.udid") == null) {
            if (iosUDID.isEmpty() || iosPlatform.isEmpty()) {
                throw new TapException(TapExceptionType.PROCESSING_FAILED, "Please supply ios udid and platform version to move forward", new Object[0]);
            }

            this.capabilities.setCapability("udid", iosUDID);
            this.capabilities.setCapability("platformVersion", iosPlatform);
        } else if (System.getProperty("device.udid") != null) {
            this.capabilities.setCapability("udid", System.getProperty("device.udid"));
            this.capabilities.setCapability("platformVersion", System.getProperty("device.version"));
        }

        this.driver = new IOSDriver(new URL(APPIUM_SERVER_URL), this.capabilities);
        ((IOSDriver)this.driver).resetApp();
        this.driver.manage().timeouts().implicitlyWait((long)DEFAULT_IMPLICIT_WAIT, TimeUnit.SECONDS);
    }

    public WebDriver chromeBrowserDriver() {
        WebDriverManager.chromedriver().setup();
        WebDriver driver = null;
        DesiredCapabilities capabilities = new DesiredCapabilities();
        capabilities.setCapability("deviceName", "chrome-Test");
        capabilities.setCapability("platformName", "Android");
        capabilities.setCapability("browserName", "Chrome");
        capabilities.setCapability("chromedriverExecutable", WebDriverManager.chromedriver().getBinaryPath());

        try {
            driver = new RemoteWebDriver(new URL(APPIUM_SERVER_URL), capabilities);
            driver.manage().timeouts().implicitlyWait(20L, TimeUnit.SECONDS);
            return driver;
        } catch (MalformedURLException var4) {
            throw new TapException(TapExceptionType.PROCESSING_FAILED, "Not able to create driver", new Object[0]);
        }
    }

    public WebDriver createHTMLUnitDriver(String Url) {
        WebDriver driver = new HtmlUnitDriver();
        driver.get(Url);
        driver.manage().timeouts().implicitlyWait(10L, TimeUnit.SECONDS);
        driver.manage().window().maximize();
        return driver;
    }

    public WebDriver createPhantomJsDriver() {
        if (this.configvariable.isProxyRequired()) {
            WebDriverManager.phantomjs().proxyUser(PROXY_USER).proxyPass(PROXY_PASS).proxy(PROXY_URL).setup();
        } else {
            WebDriverManager.phantomjs().setup();
        }

        DesiredCapabilities caps = new DesiredCapabilities();
        caps.setJavascriptEnabled(true);
        caps.setCapability("locationContextEnabled", true);
        caps.setCapability("applicationCacheEnabled", true);
        caps.setCapability("browserConnectionEnabled", true);
        caps.setCapability("localToRemoteUrlAccessEnabled", true);
        caps.setCapability("locationContextEnabled", true);
        String[] phantomArgs = new String[]{"--webdriver-loglevel=NONE"};
        caps.setCapability("phantomjs.cli.args", phantomArgs);
        WebDriver driver = new PhantomJSDriver(caps);
        driver.manage().timeouts().implicitlyWait((long)Integer.parseInt(this.configvariable.getStringVar("web.implicit.wait")), TimeUnit.SECONDS);
        driver.manage().window().maximize();
        return driver;
    }

    public WebDriver createChromeDriver() {
        if (this.configvariable.isProxyRequired()) {
            WebDriverManager.chromedriver().proxyUser(PROXY_USER).proxyPass(PROXY_PASS).proxy(PROXY_URL).setup();
        } else {
            WebDriverManager.chromedriver().setup();
        }

        Map<String, Object> prefs = new HashMap();
        prefs.put("profile.default_content_setting_values.notifications", 1);
        prefs.put("profile.default_content_settings.popups", 0);
        prefs.put("download.default_directory", this.configvariable.getStringVar("web.browser.download"));
        ChromeOptions options = new ChromeOptions();
        options.setExperimentalOption("prefs", prefs);
        if ("true".equalsIgnoreCase(this.configvariable.getStringVar("web.driver.headless"))) {
            LOGGER.debug("Running in headless mode");
            options.addArguments(new String[]{"--headless"});
            options.addArguments(new String[]{"--disable-gpu"});
            options.addArguments(new String[]{"--verbose"});
            options.addArguments(new String[]{"--no-sandbox"});
            options.addArguments(new String[]{"--window-size=1920,1080"});
        }

        options.addArguments(new String[]{"--allow-running-insecure-content"});
        options.addArguments(new String[]{"--allow-insecure-localhost"});
        options.addArguments(new String[]{"--ignore-certificate-errors"});
        options.addArguments(new String[]{"--start-maximized"});
        options.setPageLoadStrategy(PageLoadStrategy.NONE);
        options.setCapability("acceptInsecureCerts", true);
        options.setCapability("acceptSslCerts", true);
        WebDriver driver = new ChromeDriver(options);
        driver.manage().timeouts().implicitlyWait((long)Integer.parseInt(this.configvariable.getStringVar("web.implicit.wait")), TimeUnit.SECONDS);
        driver.manage().window().maximize();
        return driver;
    }

    public void startAppiumServer(String os) throws ExecuteException, IOException, InterruptedException {
        CommandLine command;
        DefaultExecuteResultHandler resultHandler;
        DefaultExecutor executor;
        if (os.contains("windows")) {
            command = new CommandLine("cmd");
            command.addArgument("/c");
            command.addArgument("C:/Program Files/nodejs/node.exe");
            command.addArgument("C:/Appium/node_modules/appium/bin/appium.js");
            command.addArgument("--address", false);
            command.addArgument("127.0.0.1");
            command.addArgument("--port", false);
            command.addArgument("4723");
            command.addArgument("--full-reset", false);
            resultHandler = new DefaultExecuteResultHandler();
            executor = new DefaultExecutor();
            executor.setExitValue(1);
            executor.execute(command, resultHandler);
            Thread.sleep(5000L);
        } else if (os.contains("mac")) {
            command = new CommandLine("/Applications/Appium.app/Contents/Resources/node/bin/node");
            command.addArgument("/Applications/Appium.app/Contents/Resources/node_modules/appium/bin/appium.js", false);
            command.addArgument("--address", false);
            command.addArgument("127.0.0.1");
            command.addArgument("--port", false);
            command.addArgument("4723");
            command.addArgument("--full-reset", false);
            resultHandler = new DefaultExecuteResultHandler();
            executor = new DefaultExecutor();
            executor.setExitValue(1);
            executor.execute(command, resultHandler);
            Thread.sleep(5000L);
        } else if (os.contains("linux")) {
            System.out.println("ANDROID_HOME : ");
            System.getenv("ANDROID_HOME");
            command = new CommandLine("/bin/bash");
            command.addArgument("-c");
            command.addArgument("~/.linuxbrew/bin/node");
            command.addArgument("~/.linuxbrew/lib/node_modules/appium/lib/appium.js", true);
            resultHandler = new DefaultExecuteResultHandler();
            executor = new DefaultExecutor();
            executor.setExitValue(1);
            executor.execute(command, resultHandler);
            Thread.sleep(5000L);
        } else {
            LOGGER.info(os + "is not supported yet");
        }

    }

    public void stopAppiumServer(String os) throws ExecuteException, IOException {
        if (os.contains("windows")) {
            CommandLine command = new CommandLine("cmd");
            command.addArgument("/c");
            command.addArgument("Taskkill /F /IM node.exe");
            DefaultExecuteResultHandler resultHandler = new DefaultExecuteResultHandler();
            DefaultExecutor executor = new DefaultExecutor();
            executor.setExitValue(1);
            executor.execute(command, resultHandler);
        } else if (os.contains("mac os x")) {
            String[] command = new String[]{"/usr/bin/killall", "-KILL", "node"};
            Runtime.getRuntime().exec(command);
            LOGGER.info("Appium server stopped");
        }

    }

    public WebDriver getWebDriver() {
        return this.driver;
    }

    public WebDriver createIEDriver() {
        if (this.configvariable.isProxyRequired()) {
            WebDriverManager.iedriver().proxyUser(PROXY_USER).proxyPass(PROXY_PASS).proxy(PROXY_URL).setup();
        } else {
            WebDriverManager.iedriver().setup();
        }

        InternetExplorerOptions options = new InternetExplorerOptions();
        options.setCapability("acceptSslCerts", true);
        options.setCapability("initialBrowserUrl", "");
        WebDriver driver = new InternetExplorerDriver(options);
        driver.manage().timeouts().implicitlyWait((long)Integer.parseInt(this.configvariable.getStringVar("web.implicit.wait")), TimeUnit.SECONDS);
        driver.manage().window().maximize();
        return driver;
    }

    public WebDriver createFirefoxDriver() {
        if (this.configvariable.isProxyRequired()) {
            WebDriverManager.firefoxdriver().proxyUser(PROXY_USER).proxyPass(PROXY_PASS).proxy(PROXY_URL).setup();
        } else {
            WebDriverManager.firefoxdriver().setup();
        }

        WebDriver driver = new FirefoxDriver();
        driver.manage().timeouts().implicitlyWait((long)Integer.parseInt(this.configvariable.getStringVar("web.implicit.wait")), TimeUnit.SECONDS);
        driver.manage().window().maximize();
        return driver;
    }

    public WebDriver createSafariDriver() {
        WebDriver driver = new SafariDriver();
        driver.manage().timeouts().implicitlyWait((long)Integer.parseInt(this.configvariable.getStringVar("web.implicit.wait")), TimeUnit.SECONDS);
        driver.manage().window().maximize();
        return driver;
    }

    public WebDriver createEdgeDriver() {
        if (this.configvariable.isProxyRequired()) {
            WebDriverManager.edgedriver().proxyUser(PROXY_USER).proxyPass(PROXY_PASS).proxy(PROXY_URL).setup();
        } else {
            WebDriverManager.edgedriver().setup();
        }

        WebDriver driver = new EdgeDriver();
        driver.manage().timeouts().implicitlyWait((long)Integer.parseInt(this.configvariable.getStringVar("web.implicit.wait")), TimeUnit.SECONDS);
        driver.manage().window().maximize();
        return driver;
    }

}

