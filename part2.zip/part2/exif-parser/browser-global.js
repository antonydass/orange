var api = require('./index');
var global = (1,eval)('this');
global.ExifParser = api;
