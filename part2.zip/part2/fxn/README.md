# fxn
![Build Status](https://api.travis-ci.org/poly/fxn.svg)

## About fxn

fxn is the base Routing and Controller layer for
[Nodal](http://github.com/keithwhor/nodal) and related projects.

Documentation is available at [DOCS.md](DOCS.md)
