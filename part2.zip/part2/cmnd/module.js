module.exports = (() => {

  return {
    Command: require('./lib/command.js'),
    CommandLineInterface: require('./lib/command_line_interface.js')
  };

})();
