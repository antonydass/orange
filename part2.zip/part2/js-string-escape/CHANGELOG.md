# master

# 1.0.1

* Exclude unused files from npm distribution

# 1.0.0

* No change; version bumped to indicate that this package is considered stable

# 0.0.1

* Initial release
