declare module 'core-js/features/*';
