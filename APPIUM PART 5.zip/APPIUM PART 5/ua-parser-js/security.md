# Security Policy

## Reporting a Vulnerability

Please report security issues to `f@faisalman.com`
